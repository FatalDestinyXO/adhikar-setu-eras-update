"""Backend API tests for Samvidhan Saga"""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    # Fallback: read frontend env directly since backend tests use the public URL
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.strip().split("=", 1)[1]
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def username():
    return f"test_{uuid.uuid4().hex[:8]}"


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ---- Health ----
def test_root(session):
    r = session.get(f"{API}/")
    assert r.status_code == 200
    assert "message" in r.json()


# ---- Profile create + defaults ----
def test_create_profile_defaults(session, username):
    r = session.post(f"{API}/profile", json={"username": username})
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["username"] == username.lower()
    assert data["reputation"] == 3
    assert data["max_reputation"] == 5
    assert data["cash"] == 0
    assert data["days_played"] == 0
    assert data["badges"] == []
    assert data["completed_articles"] == []


# ---- Idempotent create ----
def test_create_profile_idempotent(session, username):
    r1 = session.post(f"{API}/profile", json={"username": username})
    r2 = session.post(f"{API}/profile", json={"username": username})
    assert r1.status_code == 200 and r2.status_code == 200
    assert r1.json()["id"] == r2.json()["id"]


# ---- GET profile ----
def test_get_profile_success(session, username):
    r = session.get(f"{API}/profile/{username}")
    assert r.status_code == 200
    assert r.json()["username"] == username.lower()


def test_get_profile_404(session):
    r = session.get(f"{API}/profile/nonexistent_{uuid.uuid4().hex[:6]}")
    assert r.status_code == 404


# ---- PUT profile ----
def test_update_profile(session, username):
    r = session.put(f"{API}/profile/{username}", json={
        "display_name": "Updated Name",
        "reputation": 4,
        "cash": 250,
    })
    assert r.status_code == 200
    data = r.json()
    assert data["display_name"] == "Updated Name"
    assert data["reputation"] == 4
    assert data["cash"] == 250

    # verify via GET
    r2 = session.get(f"{API}/profile/{username}")
    d2 = r2.json()
    assert d2["display_name"] == "Updated Name"
    assert d2["cash"] == 250


# ---- Day result ----
def test_day_result_updates(session, username):
    before = session.get(f"{API}/profile/{username}").json()
    payload = {
        "username": username,
        "day_cash": 300,
        "day_correct": 4,
        "day_wrong": 1,
        "reputation": 3,
        "max_reputation": 5,
        "articles_covered": ["Article 17", "Article 19"],
        "scenarios_seen": ["s01", "s03"],
        "badges_earned": ["First Day"],
    }
    r = session.post(f"{API}/profile/{username}/day-result", json=payload)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["days_played"] == before["days_played"] + 1
    assert d["cash"] == before["cash"] + 300
    assert d["correct_count"] == before["correct_count"] + 4
    assert d["wrong_count"] == before["wrong_count"] + 1
    assert d["best_day_cash"] >= 300
    assert "Article 17" in d["completed_articles"]
    assert "Article 19" in d["completed_articles"]
    assert "First Day" in d["badges"]
    assert "s01" in d["scenarios_seen"]

    # Idempotent unioning: sending same articles again shouldn't duplicate
    r2 = session.post(f"{API}/profile/{username}/day-result", json={**payload, "day_cash": 50, "day_correct": 1, "day_wrong": 0})
    d2 = r2.json()
    # Articles should not be duplicated
    assert d2["completed_articles"].count("Article 17") == 1
    assert d2["badges"].count("First Day") == 1


# ---- Leaderboard ----
def test_leaderboard_sorted(session, username):
    r = session.get(f"{API}/leaderboard")
    assert r.status_code == 200
    entries = r.json()["entries"]
    assert isinstance(entries, list)
    cashes = [e["cash"] for e in entries]
    assert cashes == sorted(cashes, reverse=True)
    # our test user should be in there
    usernames = [e["username"] for e in entries]
    # limit=10 default so may not be there if many; try with larger
    r2 = session.get(f"{API}/leaderboard?limit=50")
    usernames = [e["username"] for e in r2.json()["entries"]]
    assert username.lower() in usernames


# ---- Validation ----
def test_create_profile_short_username(session):
    r = session.post(f"{API}/profile", json={"username": "a"})
    assert r.status_code == 400


# =========================
# P1 iteration new coverage
# =========================

@pytest.fixture(scope="module")
def p1_user(session):
    """Dedicated user for iteration_2 (P1) tests."""
    u = f"p1_{uuid.uuid4().hex[:8]}"
    r = session.post(f"{API}/profile", json={"username": u})
    assert r.status_code == 200
    return u


def test_new_profile_has_p1_defaults(session, p1_user):
    """New profile must expose best_combo=0 and daily_challenges_won=0."""
    r = session.get(f"{API}/profile/{p1_user}")
    assert r.status_code == 200
    d = r.json()
    assert "best_combo" in d, "best_combo field missing"
    assert "daily_challenges_won" in d, "daily_challenges_won field missing"
    assert d["best_combo"] == 0
    assert d["daily_challenges_won"] == 0


def test_existing_profile_backcompat(session, username):
    """A profile created before P1 (module-scope 'username' fixture) still loads and
    exposes new fields with default 0. This validates backwards compatibility."""
    r = session.get(f"{API}/profile/{username}")
    assert r.status_code == 200
    d = r.json()
    assert d.get("best_combo", None) == 0 or isinstance(d.get("best_combo"), int)
    assert d.get("daily_challenges_won", None) == 0 or isinstance(d.get("daily_challenges_won"), int)


def test_day_result_tracks_best_combo_and_daily_wins(session, p1_user):
    """Multiple day-result calls: best_combo tracked via max(), daily_challenges_won increments."""
    base_payload = {
        "username": p1_user,
        "day_cash": 100,
        "day_correct": 2,
        "day_wrong": 0,
        "reputation": 5,
        "max_reputation": 5,
        "articles_covered": [],
        "scenarios_seen": [],
        "badges_earned": [],
    }

    # Day 1: combo 3, daily challenge won
    r1 = session.post(f"{API}/profile/{p1_user}/day-result", json={
        **base_payload, "day_best_combo": 3, "daily_challenge_won": True,
    })
    assert r1.status_code == 200
    d1 = r1.json()
    assert d1["best_combo"] == 3
    assert d1["daily_challenges_won"] == 1

    # Day 2: lower combo (2), NOT won -> best_combo stays 3, daily wins unchanged
    r2 = session.post(f"{API}/profile/{p1_user}/day-result", json={
        **base_payload, "day_best_combo": 2, "daily_challenge_won": False,
    })
    d2 = r2.json()
    assert d2["best_combo"] == 3, f"best_combo should stay at max, got {d2['best_combo']}"
    assert d2["daily_challenges_won"] == 1

    # Day 3: higher combo (5), won -> best_combo bumps to 5, wins becomes 2
    r3 = session.post(f"{API}/profile/{p1_user}/day-result", json={
        **base_payload, "day_best_combo": 5, "daily_challenge_won": True,
    })
    d3 = r3.json()
    assert d3["best_combo"] == 5
    assert d3["daily_challenges_won"] == 2

    # Persistence check via GET
    g = session.get(f"{API}/profile/{p1_user}").json()
    assert g["best_combo"] == 5
    assert g["daily_challenges_won"] == 2


def test_day_result_defaults_when_p1_fields_omitted(session, p1_user):
    """Omitting day_best_combo & daily_challenge_won should default to 0/False and NOT decrement."""
    before = session.get(f"{API}/profile/{p1_user}").json()
    r = session.post(f"{API}/profile/{p1_user}/day-result", json={
        "username": p1_user,
        "day_cash": 50,
        "day_correct": 1,
        "day_wrong": 0,
        "reputation": 5,
        "max_reputation": 5,
        "articles_covered": [],
        "scenarios_seen": [],
        "badges_earned": [],
        # omit day_best_combo, daily_challenge_won
    })
    assert r.status_code == 200
    after = r.json()
    assert after["best_combo"] == before["best_combo"], "best_combo shouldn't drop when omitted"
    assert after["daily_challenges_won"] == before["daily_challenges_won"], "wins shouldn't increment when omitted"


def test_leaderboard_shape_and_sort(session, p1_user):
    """Leaderboard entries must include display_name, cash, correct_count, days_played
    and be sorted by cash desc."""
    r = session.get(f"{API}/leaderboard?limit=50")
    assert r.status_code == 200
    payload = r.json()
    assert "entries" in payload
    entries = payload["entries"]
    assert isinstance(entries, list) and len(entries) > 0

    required = {"display_name", "cash", "correct_count", "days_played", "username"}
    for e in entries:
        missing = required - set(e.keys())
        assert not missing, f"Leaderboard entry missing fields: {missing}"

    cashes = [e["cash"] for e in entries]
    assert cashes == sorted(cashes, reverse=True), "Leaderboard not sorted by cash desc"

    # p1_user should appear (it accumulated cash)
    usernames = [e["username"] for e in entries]
    assert p1_user.lower() in usernames
