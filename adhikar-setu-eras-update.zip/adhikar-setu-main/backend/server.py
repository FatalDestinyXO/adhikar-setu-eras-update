from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI(title="Samvidhan Saga API")
api_router = APIRouter(prefix="/api")


# ---------- Models ----------
def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Profile(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    display_name: str = ""
    avatar_id: str = "civic-1"
    reputation: int = 3
    max_reputation: int = 5
    cash: int = 0
    days_played: int = 0
    badges: List[str] = Field(default_factory=list)
    completed_articles: List[str] = Field(default_factory=list)
    scenarios_seen: List[str] = Field(default_factory=list)
    correct_count: int = 0
    wrong_count: int = 0
    best_day_cash: int = 0
    best_combo: int = 0
    daily_challenges_won: int = 0
    settings: Dict[str, Any] = Field(default_factory=dict)
    created_at: str = Field(default_factory=_now_iso)
    updated_at: str = Field(default_factory=_now_iso)


class ProfileUpsertRequest(BaseModel):
    username: str
    display_name: Optional[str] = None
    avatar_id: Optional[str] = None


class ProfileUpdateRequest(BaseModel):
    display_name: Optional[str] = None
    avatar_id: Optional[str] = None
    reputation: Optional[int] = None
    max_reputation: Optional[int] = None
    cash: Optional[int] = None
    days_played: Optional[int] = None
    badges: Optional[List[str]] = None
    completed_articles: Optional[List[str]] = None
    scenarios_seen: Optional[List[str]] = None
    correct_count: Optional[int] = None
    wrong_count: Optional[int] = None
    best_day_cash: Optional[int] = None
    best_combo: Optional[int] = None
    daily_challenges_won: Optional[int] = None
    settings: Optional[Dict[str, Any]] = None


class DayResultRequest(BaseModel):
    username: str
    day_cash: int
    day_correct: int
    day_wrong: int
    reputation: int
    max_reputation: int
    articles_covered: List[str] = Field(default_factory=list)
    scenarios_seen: List[str] = Field(default_factory=list)
    badges_earned: List[str] = Field(default_factory=list)
    day_best_combo: int = 0
    daily_challenge_won: bool = False


def _normalize_username(username: str) -> str:
    return username.strip().lower()


# ---------- Routes ----------
@api_router.get("/")
async def root():
    return {"message": "Samvidhan Saga API is running"}


@api_router.post("/profile", response_model=Profile)
async def create_or_load_profile(payload: ProfileUpsertRequest):
    username = _normalize_username(payload.username)
    if not username or len(username) < 2:
        raise HTTPException(status_code=400, detail="Username must be at least 2 characters")
    if len(username) > 24:
        raise HTTPException(status_code=400, detail="Username must be at most 24 characters")

    existing = await db.profiles.find_one({"username": username}, {"_id": 0})
    if existing:
        return Profile(**existing)

    profile = Profile(
        username=username,
        display_name=(payload.display_name or payload.username).strip(),
        avatar_id=payload.avatar_id or "civic-1",
    )
    await db.profiles.insert_one(profile.model_dump())
    return profile


@api_router.get("/profile/{username}", response_model=Profile)
async def get_profile(username: str):
    username = _normalize_username(username)
    doc = await db.profiles.find_one({"username": username}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Profile not found")
    return Profile(**doc)


@api_router.put("/profile/{username}", response_model=Profile)
async def update_profile(username: str, payload: ProfileUpdateRequest):
    username = _normalize_username(username)
    update = {k: v for k, v in payload.model_dump().items() if v is not None}
    if not update:
        raise HTTPException(status_code=400, detail="No fields to update")
    update["updated_at"] = _now_iso()

    result = await db.profiles.update_one({"username": username}, {"$set": update})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Profile not found")

    doc = await db.profiles.find_one({"username": username}, {"_id": 0})
    return Profile(**doc)


@api_router.post("/profile/{username}/day-result", response_model=Profile)
async def record_day_result(username: str, payload: DayResultRequest):
    username = _normalize_username(username)
    doc = await db.profiles.find_one({"username": username}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Profile not found")

    prof = Profile(**doc)
    prof.cash = max(0, prof.cash + payload.day_cash)
    prof.reputation = max(0, min(payload.max_reputation, payload.reputation))
    prof.max_reputation = payload.max_reputation
    prof.days_played += 1
    prof.correct_count += payload.day_correct
    prof.wrong_count += payload.day_wrong
    prof.best_day_cash = max(prof.best_day_cash, payload.day_cash)
    prof.best_combo = max(prof.best_combo, payload.day_best_combo)
    if payload.daily_challenge_won:
        prof.daily_challenges_won += 1

    for a in payload.articles_covered:
        if a and a not in prof.completed_articles:
            prof.completed_articles.append(a)
    for s in payload.scenarios_seen:
        if s and s not in prof.scenarios_seen:
            prof.scenarios_seen.append(s)
    for b in payload.badges_earned:
        if b and b not in prof.badges:
            prof.badges.append(b)

    prof.updated_at = _now_iso()

    await db.profiles.update_one(
        {"username": username},
        {"$set": prof.model_dump()},
    )
    return prof


@api_router.get("/leaderboard")
async def leaderboard(limit: int = 10):
    limit = max(1, min(50, int(limit)))
    cursor = (
        db.profiles
        .find(
            {},
            {"_id": 0, "username": 1, "display_name": 1, "cash": 1, "reputation": 1, "days_played": 1, "correct_count": 1},
        )
        .sort([("cash", -1), ("correct_count", -1)])
        .limit(limit)
    )
    docs = await cursor.to_list(limit)
    return {"entries": docs}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger(__name__)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
