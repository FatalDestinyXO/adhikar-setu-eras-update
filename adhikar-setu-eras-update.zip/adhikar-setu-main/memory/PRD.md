# Samvidhan Saga — PRD

## Original Problem Statement
Build a web app called **Samvidhan Saga** — an educational game that teaches the Indian Constitution's Fundamental Rights to players of all ages (kids through adults), styled like a retro 16-bit pixel-art video game. Main mini-game: **Adhikar Setu (Bridge of Rights)** — the player is the Advocate running a pixel-art Legal Aid clinic; pixel-art clients walk in with a problem in a retro dialogue box; the player answers Yes/No; correct answers reveal the matching Article scroll and let the player click the right Advocate specialist; Reputation & Cash update; day ends on a summary screen.

## User Choices (locked in Feb 2026)
1. **Persistence:** Backend + username-based profile (MongoDB).
2. **Audio:** Chiptune SFX via Web Audio API (off by default).
3. **Pixel art:** CSS + inline SVG (`shape-rendering="crispEdges"`) — no external images.
4. **Advanced scenario #5:** Toggleable in Settings (`advancedMode`).
5. **Answer Key:** Simple toggle in Settings (no PIN).

## User Personas
- **Kids (10–14):** Read short scenario text; play for badges; simple language.
- **Teens/Adults:** Toggle "Learn More" for full legal framing; try Advanced mode.
- **Teachers/Parents:** Flip on Answer Key to co-play or quiz a classroom.

## Core Static Requirements
- Retro 16-bit RPG aesthetic: warm terracotta palette, thick pixel borders, "Press Start 2P" (headings) + "VT323" (body).
- 10 seed scenarios with **short + full legal versions**; #5 flagged advanced; each has an Article, one-liner explanation, and Advocate specialist.
- HUD meters: Reputation (hearts), Cash (₹), Round timer, Day badge.
- Article card reveal with stamp + advocate picker.
- Extensible profile (badges, articles unlocked, correct/wrong count, best day cash) — ready to share across future games.
- Full responsive layout (desktop, tablet, phone).
- All interactive elements have unique `data-testid` attributes.

## What's Been Implemented (2026-02-14 — MVP)
- **Backend** (`/app/backend/server.py`, FastAPI + Motor + MongoDB):
  - `POST /api/profile` (create-or-load)
  - `GET /api/profile/{username}`
  - `PUT /api/profile/{username}`
  - `POST /api/profile/{username}/day-result` (accumulates cash, days_played, articles, badges)
  - `GET /api/leaderboard`

## P1 Iteration (2026-02-14)
- **3 new scenarios**: s11 Article 25 (Freedom of Religion — Meena Bai / community festival), s12 Article 14 (Equality / arbitrary state action — Harpreet Singh / tiny-shop tax), s13 Directive Principles preview (Prof. Iyer / Article 44 UCC — NOT enforceable). Priya's advocate portfolio extended to include Article 25.
- **Combo / Streak multipliers**: consecutive correct answers escalate cash reward via `comboMultiplier` (x2 = ×1.25, x3 = ×1.50, x4+ = ×2.0). Wrong answer resets combo. New `ComboMeter` HUD widget.
- **Daily Challenge**: one random scenario per day marked with pixel-gold star badge; correct answer awards flat +₹200 bonus + Daily Challenge Champion badge. Backend counts wins in `daily_challenges_won`.
- **Leaderboard screen** (`/leaderboard`): top-20 by cash desc; highlights current player. Reachable from Start (both existing-player & new-player), Day Summary, Profile.
- **New badges**: Faithful Advocate (Art 25), Equality Warrior (Art 14), Combo King (≥4 combo), Daily Challenge Champion.
- **Backend schema extension**: `Profile.best_combo`, `Profile.daily_challenges_won`; `DayResultRequest.day_best_combo`, `DayResultRequest.daily_challenge_won`. Fully backwards-compatible with existing profiles (defaults=0).
- **Tested**: iteration_2 pytest 14/14 pass; frontend P1 flows 100%.
- **Frontend** (`/app/frontend/src/…`, React 19 + Tailwind + shadcn):
  - Pages: Start (`/`), Game (`/play`), Day Summary (`/summary`), Settings (`/settings`), Answer Key (`/answer-key`), Profile (`/profile`).
  - Components: `PixelSprite`, `PixelIcons`, `RetroButton`, `PixelFrame`, `DialogueBox` (with typewriter + Learn More), `ArticleCard` (stamp + advocate picker), `RetroMeter` (Reputation/Cash/Timer/RoundBadge).
  - Game data: 10 scenarios (`game/scenarios.js`), 5 Advocate specialists (`game/advocates.js`), humanoid pixel map + player avatars (`game/spriteData.js`).
  - `game/audio.js`: Web Audio API SFX (click, textBlip, correct arpeggio, wrong sawtooth sweep, coin, stamp, levelup jingle).
  - Profile context (`game/useProfile.js`): localStorage-backed username, backend sync, settings.
  - Day loop: 6 scenarios per day, 75 s timer, +₹100 correct / −₹40 wrong / +₹50 advocate bonus; reputation drops on wrong; day ends when timer=0, reputation=0, or 6 scenarios done.
  - Badges: Perfect Docket (≥5 correct), Heart & Soul (Article 32), Child Champion (Article 21A), Prosperous Clinic (≥₹300), Flawless Advocate (no wrong).
- **Tested end-to-end** by `testing_agent_v3`: backend 9/9 pytest pass, all frontend flows verified.

## Prioritized Backlog

### P0 — Nice-to-have polish (deferred from MVP)
- Sound-on-first-interaction unlock overlay (currently a manual toggle on Start).
- Migrate from `@app.on_event('shutdown')` to FastAPI lifespan handler.

### P1 — Content & Depth
- Add 10 more scenarios (Directive Principles preview, Article 25 freedom of religion, Article 14 arbitrary State action, etc.) — same schema, drop into `scenarios.js`.
- Difficulty ramp: earlier days pull only easy scenarios; later days unlock trickier ones.
- Streaks & combo multipliers (visual retro combo bar).
- Weekly leaderboard screen (route already backed by `/api/leaderboard`).

### P2 — Second game & shared profile
- New mini-game slot ("Preamble Puzzle" or "Constitutional Timeline") sharing the same profile — profile schema already supports it (`badges`, `completed_articles`, `scenarios_seen`, `settings` dict).
- Multi-language toggle (English / हिंदी) — text data structure supports i18n keys.
- Classroom Mode: launch a "session" and let 20 kids join with a code; teacher sees an aggregate dashboard.

## Next Task List
1. Add more scenarios (P1).
2. Build second mini-game sharing the profile schema (P2).
3. Add streak/combo mechanic and daily challenge (P1).
