import React from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { ProfileProvider } from "@/game/useProfile";
import StartScreen from "@/pages/StartScreen";
import EraSelectScreen from "@/pages/EraSelectScreen";
import EraScreen from "@/pages/EraScreen";
import GameScreen from "@/pages/GameScreen";
import DaySummaryScreen from "@/pages/DaySummaryScreen";
import SettingsScreen from "@/pages/SettingsScreen";
import AnswerKeyScreen from "@/pages/AnswerKeyScreen";
import ProfileScreen from "@/pages/ProfileScreen";
import LeaderboardScreen from "@/pages/LeaderboardScreen";

function App() {
  return (
    <ProfileProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<StartScreen />} />
          <Route path="/eras" element={<EraSelectScreen />} />
          <Route path="/era/:eraId" element={<EraScreen />} />
          <Route path="/play" element={<GameScreen />} />
          <Route path="/summary" element={<DaySummaryScreen />} />
          <Route path="/settings" element={<SettingsScreen />} />
          <Route path="/answer-key" element={<AnswerKeyScreen />} />
          <Route path="/profile" element={<ProfileScreen />} />
          <Route path="/leaderboard" element={<LeaderboardScreen />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
      <Toaster />
    </ProfileProvider>
  );
}

export default App;
