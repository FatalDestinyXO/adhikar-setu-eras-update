// -------- Era Engine (Adhikar Setu: Through the Ages) --------
// Central place mapping an era id to its scenario bank + display info.
// Keeps EraScreen.js and EraSelectScreen.js from duplicating imports.

import { ANCIENT_SCENARIOS } from "@/game/ancientScenarios";
import { MEDIEVAL_SCENARIOS } from "@/game/medievalScenarios";
import { COLONIAL_SCENARIOS } from "@/game/colonialScenarios";
import { ERA_COSTUMES } from "@/game/spriteData";

export const ERA_ORDER = ["ancient", "medieval", "colonial", "constitution"];

export const ERA_INFO = {
  ancient: {
    id: "ancient",
    label: "Ancient Era",
    subtitle: "Prehistoric – c. 700 CE",
    blurb: "Indus Valley towns, Vedic assemblies, and the Maurya & Gupta empires.",
    wallLabel: "ANCIENT\nBHARAT",
    bg: "#E8D9B5",
  },
  medieval: {
    id: "medieval",
    label: "Medieval Era",
    subtitle: "c. 700 CE – 1857 CE",
    blurb: "Regional kingdoms, the Delhi Sultanate, and the Mughal Empire.",
    wallLabel: "MEDIEVAL\nDARBAR",
    bg: "#F5DEB3",
  },
  colonial: {
    id: "colonial",
    label: "Colonial Era",
    subtitle: "1857 CE – 1947 CE",
    blurb: "From the Revolt of 1857 through British rule to Independence.",
    wallLabel: "COLONIAL\nINDIA",
    bg: "#DCD6C9",
  },
  constitution: {
    id: "constitution",
    label: "Constitution Era",
    subtitle: "1950 CE – Present",
    blurb: "The Fundamental Rights that protect every citizen today.",
    wallLabel: "LEGAL\nAID",
    bg: "#F5E6D3",
  },
};

export function getScenarioBank(eraId) {
  if (eraId === "ancient") return ANCIENT_SCENARIOS;
  if (eraId === "medieval") return MEDIEVAL_SCENARIOS;
  if (eraId === "colonial") return COLONIAL_SCENARIOS;
  return [];
}

export function getEraScenariosForRound(eraId, count = 6) {
  const pool = getScenarioBank(eraId);
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

export function getEraCostume(eraId, gender = "male") {
  return ERA_COSTUMES[eraId]?.[gender] || null;
}

// -------- Progress tracking (client-side for now; will move to backend) --------
const STORAGE_KEY = "adhikarSetu.erasCompleted";

export function getCompletedEras() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function markEraCompleted(eraId) {
  const done = getCompletedEras();
  if (!done.includes(eraId)) {
    done.push(eraId);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(done));
  }
}

export function isEraUnlocked(eraId) {
  const idx = ERA_ORDER.indexOf(eraId);
  if (idx <= 0) return true; // Ancient always unlocked
  const done = getCompletedEras();
  return done.includes(ERA_ORDER[idx - 1]);
}
