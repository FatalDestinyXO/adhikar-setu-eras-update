// -------- Medieval Era Scenarios (Adhikar Setu: Through the Ages) --------
// One scenario per Fundamental Rights article (14–32), reframed into a
// Medieval India (c. 700 CE – 1857 CE) setting: regional kingdoms, the
// Delhi Sultanate, and the Mughal Empire.
//
// IMPORTANT: These are illustrative composites for educational gameplay.
// Practices, especially around religious policy, varied significantly by
// ruler, region, and period across seven centuries — scenarios are written
// to reflect general, broadly-supported patterns, explicitly noting
// variation rather than presenting one ruler or faith as representative
// of the whole era.
//
// Same schema as ancientScenarios.js.

export const MEDIEVAL_SCENARIOS = [
  {
    id: "m14",
    article: "Article 14",
    articleTitle: "Equality Before Law",
    clientName: "Hamid",
    clientRole: "Merchant in dispute with a local noble",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#8B4513", pants: "#F5F5DC", shoes: "#3C2A1A" },
    accessories: ["pagdi"],
    sceneText:
      "A powerful noble owes me a debt from a trade deal and refuses to pay. I want to bring this before the Qazi's court, but he says his rank places him above such proceedings.",
    choices: [
      { id: "qazi", text: "Qazi courts did formally apply to disputes involving nobles too, though a commoner's practical ability to enforce a ruling against a powerful noble was often limited" },
      { id: "exempt", text: "Nobles were formally exempt from all court proceedings" },
    ],
    correctChoice: "qazi",
    explanation:
      "Qazi courts formally had jurisdiction regardless of rank, but in practice, enforcing a ruling against a powerful noble depended heavily on the noble's cooperation and the court's real political leverage.",
    historicalNote:
      "Formal legal equality existing on paper, but not reliably in practice, is a recurring theme across pre-constitutional history.",
    mature: false,
  },
  {
    id: "m15",
    article: "Article 15",
    articleTitle: "Prohibition of Discrimination",
    clientName: "Zainab",
    clientRole: "Widow seeking her share of family land",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#C2185B", pants: "#AD1457", shoes: "#3C2A1A" },
    accessories: ["pallu"],
    sceneText:
      "My husband has passed away. Under the customary practice followed in my family and region, sons inherit the land — I am told, simply because I am a daughter-in-law, not a son.",
    choices: [
      { id: "customary", text: "Inheritance customs across most medieval Indian communities, regardless of faith, generally favoured male heirs over women" },
      { id: "equalRights", text: "Women had guaranteed, equal inheritance rights alongside men in this period" },
    ],
    correctChoice: "customary",
    explanation:
      "Across most communities and legal traditions of the period, customary and religious inheritance practices generally gave preference to male heirs, leaving women's property rights significantly limited.",
    historicalNote:
      "Gender-equal inheritance rights are a comparatively recent legal development, reinforced strongly by modern constitutional equality principles.",
    mature: false,
  },
  {
    id: "m16",
    article: "Article 16",
    articleTitle: "Equality of Opportunity in Public Employment",
    clientName: "Iqbal",
    clientRole: "Skilled administrator seeking a court appointment",
    palette: { hair: "#2C1810", skin: "#C68642", shirt: "#8B4513", pants: "#F5F5DC", shoes: "#3C2A1A" },
    accessories: ["pagdi"],
    sceneText:
      "I have the skills for a mansab (administrative rank) at court, but such appointments tend to go to those with existing family connections or a particular background.",
    choices: [
      { id: "connections", text: "Access to higher administrative ranks like the mansabdari system was significantly shaped by lineage, existing court connections, and the ruler's personal favour" },
      { id: "openMerit", text: "All administrative appointments were awarded through fully open, merit-based competition" },
    ],
    correctChoice: "connections",
    explanation:
      "While talented individuals from varied backgrounds did rise in some courts, administrative appointment across most medieval kingdoms was significantly shaped by lineage, existing connections, and personal favour, not open competitive merit alone.",
    historicalNote:
      "Guaranteed equality of opportunity in public employment, regardless of background, is a modern constitutional standard.",
    mature: false,
  },
  {
    id: "m17",
    article: "Article 17",
    articleTitle: "Abolition of Untouchability",
    clientName: "Tuka",
    clientRole: "Follower of a Bhakti saint-poet",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: ["tilak"],
    sceneText:
      "Our Bhakti saint teaches that all devotees are equal before God. Yet when we try to enter the main temple to worship together, some of us are still turned away because of caste.",
    choices: [
      { id: "gap", text: "Bhakti and Sufi movements preached spiritual equality, but that ideal frequently did not translate into equal access to temples or shared spaces in everyday practice" },
      { id: "achieved", text: "Bhakti-era preaching fully ended caste-based exclusion from temples across the region" },
    ],
    correctChoice: "gap",
    explanation:
      "Bhakti and Sufi saints were genuinely radical voices for spiritual equality — but their teachings frequently did not translate into actually ending caste-based exclusion from temples and shared spaces in daily practice.",
    historicalNote:
      "The gap between powerful egalitarian preaching and enforced legal equality lasted for centuries after this period too.",
    mature: false,
  },
  {
    id: "m18",
    article: "Article 18",
    articleTitle: "Abolition of Titles",
    clientName: "Faizan",
    clientRole: "Son of a jagirdar (land-grant holder)",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#8B4513", pants: "#F5F5DC", shoes: "#3C2A1A" },
    accessories: ["pagdi"],
    sceneText:
      "My father holds a jagir (land grant with a noble title) from the emperor. Our family's status and land now pass down automatically, generation after generation, regardless of our own merit.",
    choices: [
      { id: "jagir", text: "The jagirdari and mansab systems created lasting hereditary privilege tied to land and title, largely independent of the next generation's own merit" },
      { id: "temporary", text: "All noble titles and land grants ended with the original holder and could never be inherited" },
    ],
    correctChoice: "jagir",
    explanation:
      "While jagirs were technically often tied to service and not always automatically hereditary in Mughal administrative theory, in practice family status, wealth, and influence built through such grants frequently persisted across generations.",
    historicalNote:
      "Constitutional abolition of hereditary titles was a direct response to this kind of entrenched, birth-based privilege.",
    mature: false,
  },
  {
    id: "m19",
    article: "Article 19(1)(d)",
    articleTitle: "Freedom of Movement",
    clientName: "Ganga",
    clientRole: "Peasant tied to a zamindar's land by debt",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: [],
    sceneText:
      "I want to move to another village where wages are better, but I owe my zamindar a debt tied to this land, and he will not let me leave until it is repaid.",
    choices: [
      { id: "bound", text: "Debt obligations to a zamindar frequently restricted a peasant's real freedom to move or seek work elsewhere" },
      { id: "free", text: "Peasants could freely move between villages at any time regardless of debt" },
    ],
    correctChoice: "bound",
    explanation:
      "Debt owed to a landholder was a common and effective way of restricting a peasant's real freedom of movement, even without formal legal bondage — a pattern that persisted well into the colonial period too.",
    historicalNote:
      "Guaranteed freedom of movement, regardless of debt to a private party, is a modern constitutional right.",
    mature: false,
  },
  {
    id: "m20",
    article: "Article 20",
    articleTitle: "Protection Against Arbitrary Punishment",
    clientName: "Devendra",
    clientRole: "Villager accused under a newly-imposed local rule",
    palette: { hair: "#3C2A1A", skin: "#D4A574", shirt: "#8B4513", pants: "#F5F5DC", shoes: "#3C2A1A" },
    accessories: [],
    sceneText:
      "The local zamindar has just introduced a harsher local rule. He now wants to punish me for something I did before this rule even existed, and punish me twice for good measure.",
    choices: [
      { id: "risk", text: "Without a fixed, uniformly enforced legal code, local rulers could realistically impose punishment for acts committed before a rule existed, or punish repeatedly for the same act" },
      { id: "protected", text: "A guaranteed legal protection against this existed and applied uniformly across all medieval kingdoms" },
    ],
    correctChoice: "risk",
    explanation:
      "Legal codes varied by kingdom, region, and ruler, and a commoner generally had no guaranteed, enforceable protection against retroactive or repeated punishment imposed by local authority.",
    historicalNote:
      "This is precisely the vulnerability Article 20 was written to close for every citizen, everywhere, uniformly.",
    mature: false,
  },
  {
    id: "m21",
    article: "Article 21",
    articleTitle: "Right to Life and Personal Liberty",
    clientName: "Yusuf",
    clientRole: "Person of enslaved status serving a noble household",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: [],
    sceneText:
      "I was brought into this household's service through means I had no say in. Even skilled and educated people of my status could rise to real positions — but our personal liberty was never fully our own to begin with.",
    choices: [
      { id: "reality", text: "Various forms of servitude and enslaved status existed across medieval Indian society (including, notably, enslaved administrators and soldiers who sometimes rose to great power) — but personal liberty was not a guaranteed right for such individuals" },
      { id: "none", text: "No forms of servitude or bondage existed anywhere in medieval India" },
    ],
    correctChoice: "reality",
    explanation:
      "Various forms of servitude existed across the period and across communities — notably including cases where individuals of enslaved origin (such as Sultan Iltutmish) rose to great power, showing status could change, even though guaranteed personal liberty as a right did not yet exist for anyone.",
    historicalNote:
      "The idea that liberty is an inherent right belonging to every person, not something granted or withheld by status, is a modern constitutional principle.",
    mature: false,
  },
  {
    id: "m21a",
    article: "Article 21A",
    articleTitle: "Right to Education",
    clientName: "Rukmini",
    clientRole: "Girl from an artisan family",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#C2185B", pants: "#AD1457", shoes: null },
    accessories: [],
    sceneText:
      "I want to attend the local pathshala or madrasa to learn to read, but formal schooling in our region generally goes to boys, and mainly from certain families.",
    choices: [
      { id: "limited", text: "Formal education through pathshalas and madrasas was generally more accessible to boys and certain social groups, with girls and lower-status families having far more limited access" },
      { id: "equal", text: "Formal education was equally accessible to all children regardless of gender or family background" },
    ],
    correctChoice: "limited",
    explanation:
      "Formal education across medieval India — whether through pathshalas, madrasas, or other institutions — was generally more accessible to boys and to families of higher social standing, leaving girls and poorer families with far more limited access.",
    historicalNote:
      "Universal, guaranteed education for every child regardless of gender or background is a modern constitutional commitment.",
    mature: false,
  },
  {
    id: "m22",
    article: "Article 22",
    articleTitle: "Protection Against Arbitrary Arrest",
    clientName: "Sultana",
    clientRole: "Woman accused by a local noble's steward",
    palette: { hair: "#1A1A1A", skin: "#D4A574", shirt: "#C2185B", pants: "#AD1457", shoes: null },
    accessories: ["pallu"],
    sceneText:
      "A noble's steward has accused me of theft and confined me within the estate. I have not been told the exact charge, nor given a chance to defend myself before any judge.",
    choices: [
      { id: "private", text: "A powerful noble's private authority over their estate could realistically override an ordinary person's access to a formal Qazi court or fair hearing" },
      { id: "guaranteed", text: "Every accused person had a guaranteed right to be informed of charges and produced before a judge promptly" },
    ],
    correctChoice: "private",
    explanation:
      "While formal Qazi courts existed, a powerful noble's private authority within their own estate could realistically override an ordinary person's practical access to that formal process.",
    historicalNote:
      "Article 22's guarantee applies regardless of who is holding a person — a private landholder cannot substitute for the law.",
    mature: false,
  },
  {
    id: "m23",
    article: "Article 23",
    articleTitle: "Prohibition of Forced Labour & Trafficking",
    clientName: "Balwant",
    clientRole: "Peasant subject to begar (forced unpaid labour)",
    palette: { hair: "#3C2A1A", skin: "#8D5524", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: [],
    sceneText:
      "The zamindar's men come each season demanding unpaid labour (begar) from our village for his personal projects, on top of the regular land revenue we already owe.",
    choices: [
      { id: "begar", text: "The demand for begar — unpaid, compulsory labour extracted by local landholders — was a widely documented practice across medieval and later Indian society" },
      { id: "paid", text: "All labour demanded by zamindars was fairly compensated" },
    ],
    correctChoice: "begar",
    explanation:
      "Begar — compulsory, unpaid labour demanded by landholders from peasants — is a well-documented practice that continued across medieval India and persisted well into the colonial era.",
    historicalNote:
      "This exact practice is part of why Article 23 explicitly names 'begar' when prohibiting forced labour.",
    mature: false,
  },
  {
    id: "m24",
    article: "Article 24",
    articleTitle: "Prohibition of Child Labour",
    clientName: "Chhotu",
    clientRole: "Child working in a textile workshop",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: [],
    sceneText:
      "I work long hours in a textile workshop weaving fine cloth for the court, alongside adults, because my family's income depends on it.",
    choices: [
      { id: "worked", text: "Children from artisan and labouring families commonly worked in craft production, including fine textile weaving, alongside adults" },
      { id: "protected", text: "Children were legally protected from work in craft production during this period" },
    ],
    correctChoice: "worked",
    explanation:
      "Children from artisan and labouring families commonly contributed to craft production, including India's famous fine textile industries, as there was no protective legal framework preventing this.",
    historicalNote:
      "Legal protection against child labour, especially in hazardous conditions, is a comparatively recent development.",
    mature: false,
  },
  {
    id: "m25",
    article: "Article 25",
    articleTitle: "Freedom of Religion",
    clientName: "Bijoy",
    clientRole: "Devotee of a regional temple tradition",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#8B4513", pants: "#F5F5DC", shoes: "#3C2A1A" },
    accessories: ["tilak"],
    sceneText:
      "Whether I can freely practice and fund my faith's traditions seems to depend heavily on which ruler is currently in power — some are tolerant, others far less so.",
    choices: [
      { id: "varied", text: "Religious policy varied substantially by ruler and period — some rulers (such as Akbar) actively pursued broad religious tolerance, while others imposed more restrictive policies at different times" },
      { id: "uniform", text: "Every ruler across this seven-century period followed the exact same, uniformly tolerant religious policy" },
    ],
    correctChoice: "varied",
    explanation:
      "Religious policy across medieval India varied significantly by ruler, region, and period — for example, Akbar pursued notably broad tolerance and even abolished the jizya tax, while other rulers at other times imposed more restrictive policies — there was no single uniform approach across seven centuries.",
    historicalNote:
      "A guaranteed freedom of conscience for every individual, not dependent on which ruler happens to be in power, is a core modern constitutional idea.",
    mature: false,
  },
  {
    id: "m26",
    article: "Article 26",
    articleTitle: "Freedom to Manage Religious Affairs",
    clientName: "Mahant Anand",
    clientRole: "Administrator of a temple's endowed lands",
    palette: { hair: null, skin: "#8D5524", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: ["tilak"],
    sceneText:
      "Our temple has its own endowed lands and funds to manage. Increasingly, court-appointed officials want a say in how these resources are administered.",
    choices: [
      { id: "oversight", text: "Both temple endowments and waqf (religious endowment) properties across medieval India were frequently subject to some degree of state oversight or interference" },
      { id: "fullyAutonomous", text: "Religious institutions across the period always retained complete, unrestricted control over their own resources" },
    ],
    correctChoice: "oversight",
    explanation:
      "Religious endowments of various faiths — including temple lands and waqf properties — were frequently subject to varying degrees of state oversight across medieval Indian kingdoms, rather than being left entirely autonomous.",
    historicalNote:
      "A protected, guaranteed autonomy for religious institutions to manage their own affairs is a later constitutional safeguard.",
    mature: false,
  },
  {
    id: "m27",
    article: "Article 27",
    articleTitle: "Freedom from Taxes for a Religion",
    clientName: "Prithvi",
    clientRole: "Non-Muslim subject under a jizya-collecting administration",
    palette: { hair: "#3C2A1A", skin: "#D4A574", shirt: "#8B4513", pants: "#F5F5DC", shoes: "#3C2A1A" },
    accessories: [],
    sceneText:
      "Under some administrations, I am required to pay a special tax (jizya) simply because I follow a different faith than the ruler — though I've heard other rulers in other periods abolished this entirely.",
    choices: [
      { id: "varied", text: "The jizya tax on non-Muslim subjects was imposed by some rulers during some periods, notably abolished by Akbar, and later reimposed by Aurangzeb — reflecting real variation, not one constant policy" },
      { id: "constant", text: "This tax was applied identically and continuously by every ruler throughout the entire medieval period" },
    ],
    correctChoice: "varied",
    explanation:
      "The jizya tax's history is a clear example of real policy variation across the era — imposed under some administrations, notably abolished by Akbar in 1564, and later reimposed under Aurangzeb — rather than one constant, uniform practice.",
    historicalNote:
      "The constitutional principle that no citizen should be taxed to fund or based on a religion they don't follow addresses this exact category of historical practice.",
    mature: false,
  },
  {
    id: "m28",
    article: "Article 28",
    articleTitle: "Freedom from Religious Instruction in State Institutions",
    clientName: "Karim",
    clientRole: "Student at a state-funded madrasa",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: ["pagdi"],
    sceneText:
      "I attend a state-funded madrasa mainly to learn mathematics and administration, but religious instruction is a required part of the curriculum for every student, regardless of their own family's beliefs.",
    choices: [
      { id: "required", text: "State-funded educational institutions of the period were generally built around a particular religious curriculum, without a formal opt-out for students of other beliefs" },
      { id: "optOut", text: "Students always had a guaranteed right to opt out of religious instruction at state-funded institutions" },
    ],
    correctChoice: "required",
    explanation:
      "Educational institutions funded by the state during this period were generally organized around a particular religious tradition and curriculum, without a formal, guaranteed right for students of other beliefs to opt out.",
    historicalNote:
      "The right to be exempt from religious instruction at a state-funded institution is a modern constitutional protection.",
    mature: false,
  },
  {
    id: "m29",
    article: "Article 29",
    articleTitle: "Protection of Minority Culture & Language",
    clientName: "Lakshmi",
    clientRole: "Speaker of a regional vernacular language",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#C2185B", pants: "#AD1457", shoes: null },
    accessories: ["pallu"],
    sceneText:
      "All formal court records and administration are conducted in Persian, the court language. My own community's language has no official standing at all in this system.",
    choices: [
      { id: "dominant", text: "Persian generally served as the formal administrative and court language across much of medieval India, with regional vernacular languages having little official status" },
      { id: "equalStatus", text: "Every regional language had guaranteed equal official status alongside the court language" },
    ],
    correctChoice: "dominant",
    explanation:
      "Persian generally functioned as the administrative and court language across much of medieval India, while regional vernacular languages — though flourishing in literature and daily life — had little formal, official administrative status.",
    historicalNote:
      "Explicit constitutional protection for minority language and culture directly addresses this historical imbalance.",
    mature: false,
  },
  {
    id: "m30",
    article: "Article 30",
    articleTitle: "Minority Right to Establish Educational Institutions",
    clientName: "Elder Simran",
    clientRole: "Leader of a smaller religious community",
    palette: { hair: null, skin: "#8D5524", shirt: "#8B4513", pants: "#F5F5DC", shoes: null },
    accessories: ["pagdi"],
    sceneText:
      "Our community wishes to establish our own place of learning, teaching in our own tradition. We must first seek the ruling court's individual permission and patronage before we can even begin.",
    choices: [
      { id: "permission", text: "Establishing a minority community's own educational institution generally depended on securing the ruler's individual permission and patronage, not a standing guaranteed right" },
      { id: "automaticRight", text: "Every community had an automatic, guaranteed right to establish its own institutions without seeking permission" },
    ],
    correctChoice: "permission",
    explanation:
      "Whether a minority community could establish its own institution generally depended on the ruling power's individual discretion and patronage during this period, not a standing right belonging to the community itself.",
    historicalNote:
      "A guaranteed right for minorities to establish and administer their own educational institutions is a specific, deliberate constitutional protection introduced after independence.",
    mature: false,
  },
];
