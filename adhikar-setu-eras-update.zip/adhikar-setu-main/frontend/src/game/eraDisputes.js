// -------- Era Disputes (Adhikar Setu: Through the Ages) --------
// Each "dispute" is ONE recurring conflict, judged differently across
// Ancient -> Medieval -> Colonial -> Constitution (modern) eras.
// This is the DRAFT for dispute #1 (land/property). We'll add 3 more
// once you approve the format.

export const ERAS = [
  {
    id: "ancient",
    label: "Ancient Era",
    subtitle: "Prehistoric – c. 700 CE",
    blurb:
      "Indus Valley towns, Vedic assemblies, and the great Maurya & Gupta empires.",
  },
  {
    id: "medieval",
    label: "Medieval Era",
    subtitle: "c. 700 CE – 1857 CE",
    blurb: "Regional kingdoms, the Delhi Sultanate, and the Mughal Empire.",
  },
  {
    id: "colonial",
    label: "Colonial Era",
    subtitle: "1857 CE – 1947 CE",
    blurb: "From the Revolt of 1857 through direct British rule to Independence.",
  },
  {
    id: "constitution",
    label: "Constitution Era",
    subtitle: "1950 CE – Present",
    blurb: "The Fundamental Rights that protect every citizen today.",
  },
];

export const DISPUTES = [
  {
    id: "d01_land",
    title: "The Disputed Field",
    // The SAME underlying conflict, reframed for each era's setting.
    setup:
      "A farmer's field, tended by his family for generations, is suddenly claimed by someone more powerful than him.",
    rulings: {
      ancient: {
        era: "ancient",
        clientName: "Chandra",
        clientRole: "Villager, Magadha region (c. 300 BCE)",
        sceneText:
          "A local chieftain claims my field, saying his ancestors held this land before mine did. The village elders must decide.",
        // Player picks how justice was actually administered then.
        choices: [
          { id: "sabha", text: "Let the Sabha (village assembly) decide by custom and witness testimony" },
          { id: "chief", text: "The chieftain simply takes it — might makes right" },
        ],
        correctChoice: "sabha",
        explanation:
          "In the Vedic and early historic period, local assemblies (sabha/samiti) and customary law played a real role in resolving land disputes, alongside the ruler's authority — though the powerful often still had the upper hand in practice.",
        historicalNote:
          "Justice was largely local and custom-based, with no single written code protecting the ordinary farmer against arbitrary power.",
      },
      medieval: {
        era: "medieval",
        clientName: "Rahim",
        clientRole: "Peasant farmer under Mughal rule",
        sceneText:
          "A local zamindar (landholder) seizes my field to increase his revenue quota to the Mughal court. I have farmed it for twenty years.",
        choices: [
          { id: "qazi", text: "Appeal to the local Qazi (judge) citing revenue records" },
          { id: "accept", text: "Accept the zamindar's claim — he answers only to the emperor" },
        ],
        correctChoice: "qazi",
        explanation:
          "Mughal administration did have a Qazi court system and revenue records (jama-bandi) a peasant could invoke — but access depended heavily on the peasant's ability to reach and be heard by that system.",
        historicalNote:
          "Formal courts existed, but real protection for the powerless was inconsistent — much depended on local officials' fairness.",
      },
      colonial: {
        era: "colonial",
        clientName: "Manohar",
        clientRole: "Tenant farmer under British rule",
        sceneText:
          "Under the new land revenue system, my landlord raises rent beyond what I can pay and moves to evict me. I try to petition the British magistrate.",
        choices: [
          { id: "petition", text: "Petition the colonial court — but face a system built to favor revenue collection" },
          { id: "nothing", text: "There is no real avenue for me — colonial law protects the state's revenue, not the tenant" },
        ],
        correctChoice: "nothing",
        explanation:
          "Colonial land revenue systems (like the Permanent Settlement) were primarily designed to secure steady tax revenue for the British, often at the direct expense of tenant farmers' security. Legal recourse was minimal and rarely favored the poor.",
        historicalNote:
          "This is a major reason land and economic justice became central demands of the independence movement.",
      },
      constitution: {
        // This maps to your EXISTING scenario format/engine.
        article: "Article 300A",
        articleTitle: "Right to Property",
        note:
          "Today, no person can be deprived of their property except by authority of law — and disputes go through an independent judiciary, not the landholder's word.",
      },
    },
  },
  {
    id: "d02_speech",
    title: "The Silenced Voice",
    setup:
      "A person publicly criticizes those in power — and pays a price for speaking their mind.",
    rulings: {
      ancient: {
        era: "ancient",
        clientName: "Devadatta",
        clientRole: "Wandering teacher, Mauryan era",
        sceneText:
          "I criticized a royal decree in the marketplace. Soldiers came to silence me. Ashoka's edicts speak of dhamma and tolerance — do they protect me?",
        choices: [
          { id: "edicts", text: "Ashoka's edicts promoted tolerance of differing views, but protection was the ruler's choice, not a citizen's guaranteed right" },
          { id: "silence", text: "There is no concept of a 'right' to criticize the ruler at all" },
        ],
        correctChoice: "edicts",
        explanation:
          "Emperor Ashoka's edicts famously called for tolerance of different beliefs and philosophies — a remarkable early value. But this was a policy of a benevolent ruler, not an enforceable right belonging to the people themselves.",
        historicalNote:
          "Even progressive ancient rulers offered tolerance as a gift from the throne, not as something citizens could demand or defend in court.",
      },
      medieval: {
        era: "medieval",
        clientName: "Bhanu",
        clientRole: "Poet in a regional court",
        sceneText:
          "My verses mocked a powerful noble's greed. He complains to the court and demands I be punished for insolence.",
        choices: [
          { id: "patron", text: "My fate depends entirely on whether the ruler personally values art and wit over the noble's complaint" },
          { id: "law", text: "A written law guarantees my right to satire regardless of who I offend" },
        ],
        correctChoice: "patron",
        explanation:
          "Many medieval Indian courts did celebrate poets, wit, and even sharp satire — but this depended on individual rulers' taste and patronage, not on any codified right to free expression that applied to everyone equally.",
        historicalNote:
          "Free expression could flourish under a tolerant ruler and vanish entirely under a strict one — it was never guaranteed.",
      },
      colonial: {
        era: "colonial",
        clientName: "Ganesh",
        clientRole: "Newspaper editor",
        sceneText:
          "My newspaper published an article critical of British policy. I am charged under the sedition law for 'exciting disaffection' against the government.",
        choices: [
          { id: "sedition", text: "I can be imprisoned — colonial sedition law (Section 124A) criminalized criticism of the government directly" },
          { id: "protected", text: "The colonial government fully protects press freedom" },
        ],
        correctChoice: "sedition",
        explanation:
          "Section 124A of the Indian Penal Code, introduced under British rule, was explicitly used to prosecute nationalist leaders and journalists — including Bal Gangadhar Tilak and Mahatma Gandhi — for criticizing colonial rule.",
        historicalNote:
          "Criticizing the government was treated as a crime against the state itself — a major grievance that fueled the freedom movement.",
      },
      constitution: {
        article: "Article 19(1)(a)",
        articleTitle: "Freedom of Speech and Expression",
        note:
          "Today, every citizen has a guaranteed right to freely express their views — including criticism of the government — subject only to narrow, reasonable restrictions defined by law.",
      },
    },
  },
  {
    id: "d03_equality",
    title: "The Closed Door",
    setup:
      "A person is denied access to a place or opportunity solely because of who they were born as.",
    rulings: {
      ancient: {
        era: "ancient",
        clientName: "Satya",
        clientRole: "Person born into a lower varna, Vedic period",
        sceneText:
          "I am barred from certain rituals and roles because of the family I was born into. Is there anything I can do?",
        choices: [
          { id: "varna", text: "The varna-based social order of the time largely fixed a person's role by birth, with very limited mobility" },
          { id: "equal", text: "All people were treated as fully equal regardless of birth" },
        ],
        correctChoice: "varna",
        explanation:
          "The varna system that developed in this period assigned social roles significantly by birth. While some mobility and regional variation existed, deep-rooted birth-based hierarchy was a defining and lasting feature of the era.",
        historicalNote:
          "This is one of the longest and most consequential inequalities in Indian history — one the Constitution would directly confront centuries later.",
      },
      medieval: {
        era: "medieval",
        clientName: "Imran",
        clientRole: "Trader from a marginalized community",
        sceneText:
          "Despite converting and following the faith of the ruling court, some doors remain closed to me because of my family's background and profession.",
        choices: [
          { id: "mixed", text: "Some medieval reform movements (Bhakti, Sufi) preached equality before God, but social and caste-based exclusion persisted in practice" },
          { id: "solved", text: "Caste-based exclusion had disappeared entirely by this period" },
        ],
        correctChoice: "mixed",
        explanation:
          "Bhakti and Sufi saints across medieval India preached spiritual equality and were genuinely radical for their time — but entrenched social hierarchies and caste-based exclusion continued largely unchanged in everyday life.",
        historicalNote:
          "Reform voices existed for centuries before real legal equality — showing how long the gap between preaching and law can last.",
      },
      colonial: {
        era: "colonial",
        clientName: "Kamala",
        clientRole: "Student seeking admission",
        sceneText:
          "I am denied entry to a school reserved for a particular community. Reform movements are growing, but the law does little to stop this directly.",
        choices: [
          { id: "reformers", text: "Social reformers (like Jyotirao & Savitribai Phule, later Dr. Ambedkar) fought hard for access — but colonial law offered little direct protection against discrimination" },
          { id: "banned", text: "Colonial law explicitly banned all caste-based discrimination" },
        ],
        correctChoice: "reformers",
        explanation:
          "Pioneering reformers opened schools and challenged discrimination directly through activism and education, often without meaningful legal backing — colonial law did not guarantee equality as a right.",
        historicalNote:
          "This activism laid crucial groundwork for what would become a constitutional guarantee after independence.",
      },
      constitution: {
        article: "Article 15",
        articleTitle: "Prohibition of Discrimination",
        note:
          "Today, the State cannot discriminate against any citizen on grounds of religion, race, caste, sex, or place of birth — a direct legal response to centuries of exclusion.",
      },
    },
  },
  {
    id: "d04_trial",
    title: "The Accused",
    setup:
      "A person is accused of a crime — and the question is whether they get a fair chance to defend themselves.",
    rulings: {
      ancient: {
        era: "ancient",
        clientName: "Vira",
        clientRole: "Accused of theft, Gupta period",
        sceneText:
          "I am accused of stealing from a merchant. There were no witnesses. How will my guilt or innocence be decided?",
        choices: [
          { id: "ordeal", text: "Trial could involve witness testimony and evidence, but ordeals or the accuser's social standing often weighed heavily" },
          { id: "fair", text: "A guaranteed presumption of innocence and formal legal defense, identical to a modern trial" },
        ],
        correctChoice: "ordeal",
        explanation:
          "Ancient legal texts did describe evidence and witnesses, but a formal, guaranteed 'presumption of innocence' with legal representation as we understand it today did not exist — outcomes could depend heavily on social status and circumstance.",
        historicalNote:
          "Justice existed, but consistent, universal fairness for the accused — regardless of status — was not guaranteed.",
      },
      medieval: {
        era: "medieval",
        clientName: "Farid",
        clientRole: "Accused before a Qazi's court",
        sceneText:
          "I stand accused of a crime I did not commit. The Qazi will hear the case — but I have no formal lawyer, and the process moves quickly.",
        choices: [
          { id: "qazi_court", text: "The Qazi court followed Islamic legal procedure, but the accused typically had no right to formal legal counsel as understood today" },
          { id: "full_rights", text: "I had a guaranteed right to a defense lawyer and appeal, just like today" },
        ],
        correctChoice: "qazi_court",
        explanation:
          "Qazi courts followed structured legal procedure influenced by Islamic jurisprudence — a real advance in formal process — but modern protections like guaranteed legal counsel and multi-level appeal were not standard features.",
        historicalNote:
          "Structured courts existed, but many protections we now take for granted were still centuries away.",
      },
      colonial: {
        era: "colonial",
        clientName: "Bhagat",
        clientRole: "Political prisoner",
        sceneText:
          "I am arrested and detained by colonial authorities under emergency regulations, without formal trial or charge, for suspected involvement in the independence movement.",
        choices: [
          { id: "detained", text: "Laws like the Rowlatt Act allowed detention without trial — a major and deeply resented colonial power", },
          { id: "trial_guaranteed", text: "Colonial law guaranteed a fair, prompt trial for every accused person" },
        ],
        correctChoice: "detained",
        explanation:
          "The Rowlatt Act (1919) allowed the colonial government to imprison suspects without trial, fueling massive protest — including the events leading to the Jallianwala Bagh massacre — and became a rallying symbol for the independence movement.",
        historicalNote:
          "The demand for fair trial and protection against arbitrary arrest became a core promise of independent India's Constitution.",
      },
      constitution: {
        article: "Article 21 & 22",
        articleTitle: "Protection of Life, Liberty & Against Arbitrary Arrest",
        note:
          "Today, no person can be deprived of life or liberty except by lawful procedure, and anyone arrested has the right to know the charges, consult a lawyer, and be produced before a magistrate promptly.",
      },
    },
  },
];
