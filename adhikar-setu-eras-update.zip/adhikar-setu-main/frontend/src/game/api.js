import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const http = axios.create({
  baseURL: API,
  timeout: 15000,
});

export async function createOrLoadProfile({ username, displayName, avatarId }) {
  const res = await http.post("/profile", {
    username,
    display_name: displayName,
    avatar_id: avatarId,
  });
  return res.data;
}

export async function getProfile(username) {
  const res = await http.get(`/profile/${encodeURIComponent(username)}`);
  return res.data;
}

export async function updateProfile(username, patch) {
  const res = await http.put(`/profile/${encodeURIComponent(username)}`, patch);
  return res.data;
}

export async function submitDayResult(username, payload) {
  const res = await http.post(
    `/profile/${encodeURIComponent(username)}/day-result`,
    { ...payload, username },
  );
  return res.data;
}

export async function fetchLeaderboard(limit = 10) {
  const res = await http.get(`/leaderboard`, { params: { limit } });
  return res.data.entries;
}
