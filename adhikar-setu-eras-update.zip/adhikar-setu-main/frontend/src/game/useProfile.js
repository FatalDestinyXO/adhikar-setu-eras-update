import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import {
  createOrLoadProfile,
  getProfile,
  updateProfile,
  submitDayResult,
} from "@/game/api";

const KEY_USERNAME = "samvidhan.username";
const KEY_SETTINGS = "samvidhan.settings";

const defaultSettings = {
  audioOn: false,
  useAccessibleFont: false,
  advancedMode: false,
  showAnswerKey: false,
};

const ProfileContext = createContext(null);

export function ProfileProvider({ children }) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState(defaultSettings);

  // Restore settings + attempt profile restore
  useEffect(() => {
    const raw = localStorage.getItem(KEY_SETTINGS);
    if (raw) {
      try {
        setSettings({ ...defaultSettings, ...JSON.parse(raw) });
      } catch (_) {
        // ignore malformed settings
      }
    }
    const uname = localStorage.getItem(KEY_USERNAME);
    if (!uname) {
      setLoading(false);
      return;
    }
    getProfile(uname)
      .then((p) => setProfile(p))
      .catch(() => {
        // Profile no longer exists on server, clear local
        localStorage.removeItem(KEY_USERNAME);
      })
      .finally(() => setLoading(false));
  }, []);

  const saveSettings = useCallback((next) => {
    setSettings((prev) => {
      const merged = { ...prev, ...next };
      localStorage.setItem(KEY_SETTINGS, JSON.stringify(merged));
      return merged;
    });
  }, []);

  const login = useCallback(async ({ username, displayName, avatarId }) => {
    const p = await createOrLoadProfile({ username, displayName, avatarId });
    localStorage.setItem(KEY_USERNAME, p.username);
    setProfile(p);
    return p;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(KEY_USERNAME);
    setProfile(null);
  }, []);

  const patchProfile = useCallback(async (patch) => {
    if (!profile) return null;
    const updated = await updateProfile(profile.username, patch);
    setProfile(updated);
    return updated;
  }, [profile]);

  const recordDay = useCallback(async (payload) => {
    if (!profile) return null;
    const updated = await submitDayResult(profile.username, payload);
    setProfile(updated);
    return updated;
  }, [profile]);

  const value = {
    profile,
    setProfile,
    loading,
    settings,
    saveSettings,
    login,
    logout,
    patchProfile,
    recordDay,
  };
  return <ProfileContext.Provider value={value}>{children}</ProfileContext.Provider>;
}

export function useProfile() {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error("useProfile must be used inside ProfileProvider");
  return ctx;
}
