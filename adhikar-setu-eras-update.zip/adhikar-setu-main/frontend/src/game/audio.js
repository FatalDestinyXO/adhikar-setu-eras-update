// -------- 8-bit Web Audio API SFX --------
// No external assets. Everything synthesized on demand.

let ctx = null;
let muted = true; // muted by default (per design guidelines)

function ensureCtx() {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC();
    } catch (e) {
      ctx = null;
    }
  }
  if (ctx && ctx.state === "suspended") {
    ctx.resume().catch(() => {});
  }
  return ctx;
}

export function setMuted(v) {
  muted = !!v;
}
export function isMuted() {
  return muted;
}

function playTone({
  freq = 440,
  type = "square",
  duration = 0.1,
  attack = 0.005,
  release = 0.05,
  gain = 0.08,
  startAt = 0,
}) {
  if (muted) return;
  const ac = ensureCtx();
  if (!ac) return;
  const now = ac.currentTime + startAt;
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);
  g.gain.setValueAtTime(0, now);
  g.gain.linearRampToValueAtTime(gain, now + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, now + duration + release);
  osc.connect(g).connect(ac.destination);
  osc.start(now);
  osc.stop(now + duration + release + 0.02);
}

function playSweep({ from, to, type = "sawtooth", duration = 0.2, gain = 0.08 }) {
  if (muted) return;
  const ac = ensureCtx();
  if (!ac) return;
  const now = ac.currentTime;
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(from, now);
  osc.frequency.exponentialRampToValueAtTime(to, now + duration);
  g.gain.setValueAtTime(0, now);
  g.gain.linearRampToValueAtTime(gain, now + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  osc.connect(g).connect(ac.destination);
  osc.start(now);
  osc.stop(now + duration + 0.02);
}

// ---- SFX bank ----
export const SFX = {
  click() {
    playTone({ freq: 660, type: "square", duration: 0.04, gain: 0.06 });
  },
  hover() {
    playTone({ freq: 880, type: "square", duration: 0.02, gain: 0.03 });
  },
  textBlip() {
    playTone({ freq: 320 + Math.random() * 80, type: "square", duration: 0.015, gain: 0.03 });
  },
  correct() {
    // arpeggio C-E-G-C
    playTone({ freq: 523, type: "square", duration: 0.08, gain: 0.08, startAt: 0 });
    playTone({ freq: 659, type: "square", duration: 0.08, gain: 0.08, startAt: 0.09 });
    playTone({ freq: 784, type: "square", duration: 0.08, gain: 0.08, startAt: 0.18 });
    playTone({ freq: 1046, type: "square", duration: 0.16, gain: 0.09, startAt: 0.27 });
  },
  wrong() {
    playSweep({ from: 320, to: 110, type: "sawtooth", duration: 0.3, gain: 0.09 });
  },
  stamp() {
    playTone({ freq: 90, type: "square", duration: 0.14, gain: 0.14 });
  },
  coin() {
    playTone({ freq: 988, type: "square", duration: 0.05, gain: 0.06, startAt: 0 });
    playTone({ freq: 1319, type: "square", duration: 0.1, gain: 0.06, startAt: 0.055 });
  },
  levelup() {
    const notes = [523, 659, 784, 988, 1175, 1319];
    notes.forEach((n, i) => {
      playTone({ freq: n, type: "square", duration: 0.09, gain: 0.08, startAt: i * 0.08 });
    });
  },
  tick() {
    playTone({ freq: 220, type: "square", duration: 0.02, gain: 0.03 });
  },
  buzz() {
    playTone({ freq: 140, type: "sawtooth", duration: 0.08, gain: 0.06 });
  },
};

export async function primeAudio() {
  const ac = ensureCtx();
  if (!ac) return;
  if (ac.state === "suspended") {
    try {
      await ac.resume();
    } catch (e) {
      /* ignore */
    }
  }
}
