// -------- Ancient Era Scenarios (Adhikar Setu: Through the Ages) --------
// One scenario per Fundamental Rights article (14–32), reframed into an
// Ancient India (Indus Valley – c. 700 CE) setting.
//
// IMPORTANT: These are illustrative composites for educational gameplay.
// Where specific historical practice is debated or under-documented,
// the scenario is written to reflect general, broadly-supported patterns
// of the period rather than a single precise documented case.
//
// Schema mirrors scenarios.js but uses a "choices" format (since Fundamental
// Rights did not exist yet) instead of yes/no FR-violation format.
// mature: false scenarios are always shown. mature: true scenarios are
// only shown when the player has selected Mature Mode. Both modes are
// always written non-graphically — the toggle only changes topic breadth.

export const ANCIENT_SCENARIOS = [
  {
    id: "a14",
    article: "Article 14",
    articleTitle: "Equality Before Law",
    clientName: "Kirti",
    clientRole: "Trader from a neighbouring town, Mauryan era",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#5C4033" },
    accessories: ["angavastram"],
    sceneText:
      "I am an outsider trader accused of shortchanging a local buyer. The local guild wants me punished without a hearing, since I am 'not one of them'.",
    choices: [
      { id: "hearing", text: "Local administration under Mauryan governance (per the Arthashastra) generally required disputes to go through officials, not mob judgment — even for outsiders" },
      { id: "mob", text: "As an outsider, I have no right to any hearing at all" },
    ],
    correctChoice: "hearing",
    explanation:
      "Administrative texts like the Arthashastra describe structured local dispute resolution through officials rather than pure mob rule — though how consistently 'equal' treatment for outsiders truly was in practice is debated among historians.",
    historicalNote:
      "A basic idea of process before punishment existed, but a guaranteed universal 'equality before law' applying to everyone identically was not yet a formal legal principle.",
    mature: false,
  },
  {
    id: "a15",
    article: "Article 15",
    articleTitle: "Prohibition of Discrimination",
    clientName: "Mira",
    clientRole: "Girl seeking Vedic learning, Vedic period",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#F0C987", pants: "#F0C987", shoes: "#5C4033" },
    accessories: ["tilak"],
    sceneText:
      "I want to formally study the Vedas at the learning circle, but I'm told women and certain groups are generally excluded from this formal instruction.",
    choices: [
      { id: "excluded", text: "Formal Vedic education was largely restricted along lines of gender and birth-group in the mainstream tradition of the time" },
      { id: "open", text: "Vedic learning was fully open to everyone regardless of gender or birth" },
    ],
    correctChoice: "excluded",
    explanation:
      "While a few historical exceptions and female scholars are recorded (such as some women sages mentioned in early texts), formal Vedic education was, in mainstream practice, largely restricted by gender and birth-group.",
    historicalNote:
      "This restriction on who could access knowledge is one of the clearest, longest-running inequalities in Indian history.",
    mature: false,
  },
  {
    id: "a16",
    article: "Article 16",
    articleTitle: "Equality of Opportunity in Public Employment",
    clientName: "Ratna",
    clientRole: "Skilled craftsman seeking royal service",
    palette: { hair: "#3C2A1A", skin: "#C68642", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#3C2A1A" },
    accessories: [],
    sceneText:
      "I am highly skilled, but the royal court's administrative posts are generally filled by people from certain established families and groups. Can I be considered purely on merit?",
    choices: [
      { id: "birth", text: "Access to higher administrative and priestly roles was heavily shaped by birth-group, not open merit-based competition" },
      { id: "merit", text: "All royal positions were awarded purely by open competitive merit, regardless of birth" },
    ],
    correctChoice: "birth",
    explanation:
      "Certain administrative, priestly, and advisory roles were substantially shaped by birth-group and lineage in ancient India, limiting genuinely open access based on merit alone.",
    historicalNote:
      "Skilled artisans could still rise through trade guilds, which offered somewhat more mobility than royal/priestly posts.",
    mature: false,
  },
  {
    id: "a17",
    article: "Article 17",
    articleTitle: "Abolition of Untouchability",
    clientName: "Bhima",
    clientRole: "Villager from a marginalized community",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#3C2A1A" },
    accessories: [],
    sceneText:
      "I am not permitted to draw water from the village well used by others, or enter certain parts of the settlement, because of the community I was born into.",
    choices: [
      { id: "excluded", text: "Birth-based exclusion from shared spaces and resources was a documented feature of the varna-based social order" },
      { id: "none", text: "No such exclusion existed in ancient Indian villages" },
    ],
    correctChoice: "excluded",
    explanation:
      "Exclusion of certain communities from shared resources like water sources and living spaces, based on birth, has deep and well-documented historical roots stretching back through this period.",
    historicalNote:
      "This is the same deep-rooted practice the Constitution would later explicitly abolish under Article 17.",
    mature: false,
  },
  {
    id: "a18",
    article: "Article 18",
    articleTitle: "Abolition of Titles",
    clientName: "Devraj",
    clientRole: "Village headman's son",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#5C4033" },
    accessories: [],
    sceneText:
      "My father was given a grand hereditary title by the local ruler. Now our whole family is treated as superior to our neighbours because of it, generation after generation.",
    choices: [
      { id: "hereditary", text: "Rulers commonly granted hereditary titles and honours that created lasting social hierarchy across generations" },
      { id: "meritOnly", text: "Titles could never be inherited and had no effect on social status" },
    ],
    correctChoice: "hereditary",
    explanation:
      "Hereditary titles and ranks granted by rulers were a common way lasting social hierarchies were built and reinforced across generations in ancient kingdoms.",
    historicalNote:
      "The idea that a title should NOT create a permanent hereditary elite is a distinctly modern, constitutional idea.",
    mature: false,
  },
  {
    id: "a19",
    article: "Article 19(1)(g)",
    articleTitle: "Freedom of Profession",
    clientName: "Suman",
    clientRole: "Son of a potter, wishing to become a scribe",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#3C2A1A" },
    accessories: [],
    sceneText:
      "My family has always been potters. I want to train as a scribe instead, but I'm told a person's occupation is generally expected to follow their birth-group.",
    choices: [
      { id: "fixed", text: "Occupation was substantially tied to birth-group under the varna-based social order, with limited freedom to simply choose a different trade" },
      { id: "free", text: "Anyone could freely choose any profession regardless of family background" },
    ],
    correctChoice: "fixed",
    explanation:
      "While craft guilds gave some flexibility, the broader social structure of the period substantially tied occupation to birth-group, especially for roles seen as socially significant.",
    historicalNote:
      "Free choice of profession, regardless of birth, is a right the Constitution would guarantee millennia later.",
    mature: false,
  },
  {
    id: "a20",
    article: "Article 20",
    articleTitle: "Protection Against Arbitrary Punishment",
    clientName: "Arjun",
    clientRole: "Farmer accused of a boundary violation",
    palette: { hair: "#3C2A1A", skin: "#D4A574", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#5C4033" },
    accessories: [],
    sceneText:
      "I was already punished once for this boundary dispute last season. Now the new local official wants to punish me again for the same matter, under a harsher rule made after the fact.",
    choices: [
      { id: "risk", text: "Without a fixed, written, universally-applied code, a subject could realistically face punishment again, or under a rule not in force at the time of the act" },
      { id: "protected", text: "A guaranteed protection against double punishment and after-the-fact laws existed and applied to everyone" },
    ],
    correctChoice: "risk",
    explanation:
      "Without a single fixed, universally-enforced legal code, protections like 'no punishment twice for the same act' or 'no punishment under a law made after the act' were not guaranteed the way modern constitutional protection guarantees them.",
    historicalNote:
      "This vulnerability to inconsistent or after-the-fact rulings is exactly what Article 20 was written to prevent.",
    mature: false,
  },
  {
    id: "a21",
    article: "Article 21",
    articleTitle: "Right to Life and Personal Liberty",
    clientName: "Nandini",
    clientRole: "Woman sold into household bondage after her family's debt",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#F0C987", pants: "#F0C987", shoes: "#5C4033" },
    accessories: [],
    sceneText:
      "My family could not repay a debt to a wealthy household. Now I am made to serve that household indefinitely, with little control over my own life or movement.",
    choices: [
      { id: "bondage", text: "Debt-bondage and forms of servitude, including for women and the poor, were a documented reality of the period" },
      { id: "protected", text: "Everyone's personal liberty was fully guaranteed regardless of debt or social position" },
    ],
    correctChoice: "bondage",
    explanation:
      "Debt-bondage and various forms of servitude existed across ancient Indian society, with the poor and marginalized most vulnerable — there was no guaranteed personal liberty protecting them.",
    historicalNote:
      "The idea that liberty belongs to every person, rich or poor, is one of the most hard-won constitutional guarantees.",
    mature: false,
  },
  {
    id: "a21a",
    article: "Article 21A",
    articleTitle: "Right to Education",
    clientName: "Chotu",
    clientRole: "Child of a laborer family",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: null },
    accessories: [],
    sceneText:
      "I want to learn to read and count, but children of laborer families like mine are expected to start working instead of attending any formal learning circle.",
    choices: [
      { id: "noAccess", text: "Formal education was generally limited to certain groups, with children of laboring families rarely having guaranteed access" },
      { id: "universal", text: "Every child, regardless of family occupation, had a guaranteed right to formal education" },
    ],
    correctChoice: "noAccess",
    explanation:
      "Formal education in ancient India was generally accessible mainly to certain social groups, with children of laboring and lower-status families rarely guaranteed access to it.",
    historicalNote:
      "Universal, guaranteed education for every child is a distinctly modern constitutional promise (added via the 86th Amendment in 2002).",
    mature: false,
  },
  {
    id: "a22",
    article: "Article 22",
    articleTitle: "Protection Against Arbitrary Arrest",
    clientName: "Baladeva",
    clientRole: "Villager accused by a local official",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#5C4033" },
    accessories: [],
    sceneText:
      "A local official detained me overnight on mere suspicion, without telling me the charge or letting me speak in my defence before higher authority.",
    choices: [
      { id: "arbitrary", text: "Detention by local authority, without a guaranteed right to be informed of charges or promptly heard, was a real risk for ordinary people" },
      { id: "guaranteed", text: "Every detained person had a guaranteed right to be informed of charges and heard promptly" },
    ],
    correctChoice: "arbitrary",
    explanation:
      "While rulers and administrators did hear disputes, an ordinary person had no guaranteed, enforceable right to be informed of charges or promptly produced before higher authority — much depended on the individual official's fairness.",
    historicalNote:
      "This gap is precisely what Article 22's procedural protections were designed to close.",
    mature: false,
  },
  {
    id: "a23",
    article: "Article 23",
    articleTitle: "Prohibition of Forced Labour & Trafficking",
    clientName: "Kesari",
    clientRole: "Villager conscripted for unpaid royal construction work",
    palette: { hair: "#3C2A1A", skin: "#8D5524", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: null },
    accessories: [],
    sceneText:
      "Officials came to our village demanding unpaid labour (vishti) for the king's new reservoir project. Refusal was not really an option.",
    choices: [
      { id: "vishti", text: "Forced, largely unpaid labour obligations to the state (referred to in some texts as vishti) were a documented practice under some ancient administrations" },
      { id: "voluntary", text: "All labour for royal projects was fully voluntary and fairly paid" },
    ],
    correctChoice: "vishti",
    explanation:
      "Some ancient administrative texts describe forms of compulsory, largely unpaid labour owed to the state for public works — a practice with clear echoes of what Article 23 would later prohibit.",
    historicalNote:
      "Forced labour of this kind continued in various forms for centuries after this period too.",
    mature: false,
  },
  {
    id: "a24",
    article: "Article 24",
    articleTitle: "Prohibition of Child Labour",
    clientName: "Vinay",
    clientRole: "Child working in a mining/quarrying settlement",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: null },
    accessories: [],
    sceneText:
      "I am young, but I am made to work in dangerous quarry conditions alongside adults because my family needs the income and no rule stops this.",
    choices: [
      { id: "noRule", text: "There was no protective rule preventing children from working in hazardous conditions; poor families often had little alternative" },
      { id: "protected", text: "Children were fully protected by law from hazardous work in this period" },
    ],
    correctChoice: "noRule",
    explanation:
      "No protective legal framework prevented children from hazardous labour in ancient India — poverty often left families with little choice, a pattern that persisted for millennia.",
    historicalNote:
      "Article 24's protection for children in hazardous work is a very recent legal idea by comparison.",
    mature: false,
  },
  {
    id: "a25",
    article: "Article 25",
    articleTitle: "Freedom of Religion",
    clientName: "Sanghamitra",
    clientRole: "Follower of an early heterodox ascetic sect",
    palette: { hair: null, skin: "#D4A574", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: null },
    accessories: [],
    sceneText:
      "My teacher preaches a path that questions the dominant religious establishment. Before royal patrons like Ashoka embraced tolerance, sects like ours sometimes faced real hostility from orthodox authorities.",
    choices: [
      { id: "mixed", text: "Religious tolerance varied significantly by ruler and period — some rulers (like Ashoka) actively promoted it, while heterodox sects faced hostility from orthodox establishments at other times" },
      { id: "always", text: "Complete religious freedom for all sects was guaranteed and consistent throughout this entire era" },
    ],
    correctChoice: "mixed",
    explanation:
      "Religious tolerance in ancient India varied considerably — some periods and rulers (notably Ashoka) were remarkably tolerant, while heterodox movements like early Buddhism and Jainism also faced real friction with orthodox religious establishments at various points.",
    historicalNote:
      "A guaranteed, universal freedom of conscience for every individual, protected by law, is a modern constitutional idea.",
    mature: false,
  },
  {
    id: "a26",
    article: "Article 26",
    articleTitle: "Freedom to Manage Religious Affairs",
    clientName: "Acharya Deva",
    clientRole: "Head of a small ascetic community",
    palette: { hair: null, skin: "#8D5524", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: null },
    accessories: [],
    sceneText:
      "The local ruler wants to appoint who leads our community's rituals and manage our community's resources directly, overriding our own internal decisions.",
    choices: [
      { id: "royalControl", text: "Rulers frequently exercised significant influence or control over religious institutions and their resources within their territory" },
      { id: "autonomous", text: "Religious communities always had guaranteed, unrestricted control over their own internal affairs" },
    ],
    correctChoice: "royalControl",
    explanation:
      "Royal patronage often came paired with royal influence — rulers frequently played a significant role in religious institutions' leadership and resources, rather than leaving them fully autonomous.",
    historicalNote:
      "A protected, guaranteed autonomy for religious communities to manage their own affairs is a later constitutional safeguard.",
    mature: false,
  },
  {
    id: "a27",
    article: "Article 27",
    articleTitle: "Freedom from Taxes for a Religion",
    clientName: "Ilan",
    clientRole: "Farmer of a different faith than the ruler",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: "#5C4033" },
    accessories: [],
    sceneText:
      "The king has ordered a special levy from all subjects to fund construction of a grand temple for his chosen deity — even though I follow a different faith.",
    choices: [
      { id: "levy", text: "Rulers sometimes funded favoured religious institutions through general taxation collected from all subjects, regardless of individual faith" },
      { id: "exempt", text: "Subjects of a different faith were always exempted from taxes funding another religion" },
    ],
    correctChoice: "levy",
    explanation:
      "State patronage of a favoured religion funded through general taxation, without exemption for subjects of other faiths, was a realistic feature of many ancient kingdoms.",
    historicalNote:
      "The principle that public tax money should not be used to promote one particular religion is a modern constitutional safeguard.",
    mature: false,
  },
  {
    id: "a28",
    article: "Article 28",
    articleTitle: "Freedom from Religious Instruction in State Institutions",
    clientName: "Yasho",
    clientRole: "Student at a royally-funded learning circle",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#F0C987", pants: "#F0C987", shoes: null },
    accessories: [],
    sceneText:
      "I study at a learning circle funded by the royal treasury. All students, regardless of their own family's beliefs, are required to take part in the establishment's religious instruction.",
    choices: [
      { id: "required", text: "State-funded learning circles of the period typically centred on the ruling establishment's own religious tradition, without an opt-out for students of other beliefs" },
      { id: "optional", text: "Religious instruction was always optional for students of a different faith" },
    ],
    correctChoice: "required",
    explanation:
      "Learning institutions of the period were generally built around the dominant religious tradition, without the concept of an individual student's right to opt out based on personal or family belief.",
    historicalNote:
      "The right to be exempt from religious instruction at a state-funded institution is a modern constitutional protection.",
    mature: false,
  },
  {
    id: "a29",
    article: "Article 29",
    articleTitle: "Protection of Minority Culture & Language",
    clientName: "Thara",
    clientRole: "Member of a smaller regional linguistic community",
    palette: { hair: "#3C2A1A", skin: "#8D5524", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: null },
    accessories: [],
    sceneText:
      "Our region has its own spoken tongue and customs, but the dominant power's language is what's required for all administration, trade, and formal record-keeping.",
    choices: [
      { id: "dominant", text: "The dominant power's language and script generally took precedence in administration, with smaller linguistic communities having little formal protection for their own tongue" },
      { id: "protected", text: "Every regional language had guaranteed protection and equal official status" },
    ],
    correctChoice: "dominant",
    explanation:
      "Administrative and formal life generally centred on the ruling power's language and script, with little formal protection guaranteed for smaller linguistic or cultural communities.",
    historicalNote:
      "Explicit constitutional protection for minority language and culture is a modern safeguard against this kind of dominance.",
    mature: false,
  },
  {
    id: "a30",
    article: "Article 30",
    articleTitle: "Minority Right to Establish Educational Institutions",
    clientName: "Prajna",
    clientRole: "Elder of a small religious minority community",
    palette: { hair: null, skin: "#D4A574", shirt: "#E8D9B5", pants: "#E8D9B5", shoes: null },
    accessories: [],
    sceneText:
      "Our small community wants to build and run our own learning centre, teaching in our own tradition. We need the ruler's personal permission and goodwill to do so at all.",
    choices: [
      { id: "permission", text: "Establishing a community's own institution generally depended on the ruler's discretion and goodwill, not a guaranteed right" },
      { id: "automatic", text: "Any community had an automatic, guaranteed right to establish its own institutions without needing permission" },
    ],
    correctChoice: "permission",
    explanation:
      "Whether a minority community could establish and run its own institution generally depended on the ruler's individual discretion and patronage, not a standing guaranteed right belonging to the community itself.",
    historicalNote:
      "A guaranteed right for minorities to establish and administer their own educational institutions is a specific, deliberate constitutional protection.",
    mature: false,
  },
];
