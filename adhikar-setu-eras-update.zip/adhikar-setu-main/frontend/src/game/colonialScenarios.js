// -------- Colonial Era Scenarios (Adhikar Setu: Through the Ages) --------
// One scenario per Fundamental Rights article (14–32), reframed into the
// Colonial/Modern era (1857 CE – 1947 CE): from the Revolt of 1857 through
// direct British Crown rule to Independence.
//
// Same schema as ancientScenarios.js / medievalScenarios.js.
// Real named acts, events, and reports are used where possible for
// historical grounding (Ilbert Bill, Rowlatt Act, Macaulay's Minute, etc.)

export const COLONIAL_SCENARIOS = [
  {
    id: "c14",
    article: "Article 14",
    articleTitle: "Equality Before Law",
    clientName: "Nirmal",
    clientRole: "Indian district judge",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: ["collar"],
    sceneText:
      "I have qualified as a district judge, but a proposed law would still bar me from trying cases involving European British subjects — purely because of my origin, not my qualification.",
    choices: [
      { id: "ilbert", text: "This mirrors the real 1883 Ilbert Bill controversy, where British residents in India strongly opposed allowing Indian judges to try European defendants, forcing the bill to be watered down" },
      { id: "equalTreatment", text: "Indian and British judges were treated identically under colonial law with no such controversy" },
    ],
    correctChoice: "ilbert",
    explanation:
      "The 1883 Ilbert Bill controversy is a well-documented real episode — British colonial residents in India protested fiercely against Indian judges having jurisdiction over European defendants, and the law was ultimately compromised to appease them.",
    historicalNote:
      "This episode is often cited as a turning point that galvanized Indian political consciousness ahead of the Indian National Congress's founding in 1885.",
    mature: false,
  },
  {
    id: "c15",
    article: "Article 15",
    articleTitle: "Prohibition of Discrimination",
    clientName: "Ratanlal",
    clientRole: "Railway passenger",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    sceneText:
      "I hold a valid first-class railway ticket, but I am directed to a separate compartment. Certain clubs, compartments, and public spaces are reserved for Europeans only.",
    choices: [
      { id: "segregated", text: "Racial segregation in clubs, railway compartments, and public facilities reserved for Europeans was a real, documented feature of colonial-era public life" },
      { id: "open", text: "All public facilities were equally open to Indians and Europeans alike" },
    ],
    correctChoice: "segregated",
    explanation:
      "Racially segregated clubs, railway compartments, and other public facilities — reserved for Europeans regardless of an Indian passenger's ticket class or status — were a well-documented, humiliating feature of colonial society.",
    historicalNote:
      "This lived experience of racial discrimination is a core reason Article 15's language explicitly bans discrimination based on race.",
    mature: false,
  },
  {
    id: "c16",
    article: "Article 16",
    articleTitle: "Equality of Opportunity in Public Employment",
    clientName: "Satyendranath",
    clientRole: "Aspirant to the Indian Civil Service (ICS)",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: ["collar"],
    sceneText:
      "I wish to join the prestigious Indian Civil Service, but the qualifying examination is held only in London, with an age limit that makes it extremely difficult for most Indians to even attempt it.",
    choices: [
      { id: "restricted", text: "The ICS exam being held only in England, with a low age limit, was a real, deliberate structural barrier that kept Indian representation in top administration extremely low for decades" },
      { id: "equalAccess", text: "Indians had fully equal, practical access to ICS positions alongside British candidates" },
    ],
    correctChoice: "restricted",
    explanation:
      "Holding the ICS exam exclusively in London with a restrictive age limit was a real structural barrier — though pioneers like Satyendranath Tagore (1864) did succeed, Indian representation in the top civil service remained deliberately and drastically low for decades.",
    historicalNote:
      "The demand for civil service reform and simultaneous exams in India became a major early nationalist cause.",
    mature: false,
  },
  {
    id: "c17",
    article: "Article 17",
    articleTitle: "Abolition of Untouchability",
    clientName: "Muknayak",
    clientRole: "Community member advocating for temple entry",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#FFFFFF", pants: "#37474F", shoes: null },
    accessories: [],
    sceneText:
      "Reformers are organizing temple-entry movements and demanding wells and public spaces be opened to all. Colonial law offers little direct help — change is coming through activism, not legislation.",
    choices: [
      { id: "activism", text: "Movements led by reformers like Dr. B.R. Ambedkar (e.g., the 1927 Mahad Satyagraha for water rights) drove real change through direct activism, since colonial law provided little proactive protection against untouchability" },
      { id: "lawEnded", text: "Colonial law had already fully abolished untouchability by this period" },
    ],
    correctChoice: "activism",
    explanation:
      "Movements like Dr. B.R. Ambedkar's 1927 Mahad Satyagraha, asserting the right to draw water from a public tank, show that meaningful change against untouchability during this period came primarily through direct activism and organizing, not colonial legislation.",
    historicalNote:
      "This activism directly shaped Ambedkar's later role as chief architect of the Constitution's Article 17.",
    mature: false,
  },
  {
    id: "c18",
    article: "Article 18",
    articleTitle: "Abolition of Titles",
    clientName: "Rai Bahadur Suresh",
    clientRole: "Recipient of a colonial honorary title",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: ["collar"],
    sceneText:
      "The colonial government awarded me the title 'Rai Bahadur' for my loyal service. It grants me real social standing above my neighbours — awarded not for merit alone, but largely for supporting British rule.",
    choices: [
      { id: "loyalty", text: "Colonial titles like 'Rai Bahadur' and knighthoods were frequently used as tools to reward political loyalty and create a class of local supporters, creating social hierarchy tied to allegiance to the Crown" },
      { id: "meritOnly", text: "Colonial titles were awarded purely on independent merit, unrelated to political loyalty" },
    ],
    correctChoice: "loyalty",
    explanation:
      "Colonial-era honorary titles were frequently, though not exclusively, used strategically to reward and cultivate a class of loyal local supporters — creating social hierarchy tied significantly to political allegiance rather than merit alone.",
    historicalNote:
      "Gandhi's own renunciation of his 'Kaisar-i-Hind' title after the Jallianwala Bagh massacre symbolized rejecting exactly this kind of hierarchy.",
    mature: false,
  },
  {
    id: "c19",
    article: "Article 19(1)(b)",
    articleTitle: "Freedom of Assembly",
    clientName: "Harnam",
    clientRole: "Resident of Amritsar",
    palette: { hair: "#2C1810", skin: "#C68642", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    sceneText:
      "A peaceful public gathering has been called in the city. Orders have been issued banning such assemblies. Attending one, even peacefully, carries real danger.",
    choices: [
      { id: "banned", text: "Colonial authorities frequently banned public assemblies under emergency regulations — the 1919 Jallianwala Bagh massacre occurred at exactly such a banned peaceful gathering" },
      { id: "protected", text: "Peaceful public assembly was fully protected and never restricted under colonial law" },
    ],
    correctChoice: "banned",
    explanation:
      "Colonial authorities frequently banned public assemblies under emergency regulations. The Jallianwala Bagh massacre of April 1919 occurred when British troops fired on a peaceful crowd gathered in violation of exactly such a ban — one of the most tragic episodes of the independence movement.",
    historicalNote:
      "Guaranteed freedom of peaceful assembly under Article 19(1)(b) is a direct constitutional response to this history.",
    mature: false,
  },
  {
    id: "c20",
    article: "Article 20",
    articleTitle: "Protection Against Arbitrary Punishment",
    clientName: "Gopal",
    clientRole: "Resident of a village under collective punishment",
    palette: { hair: "#3C2A1A", skin: "#D4A574", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    sceneText:
      "An act of unrest occurred somewhere in our district. Colonial authorities have imposed a collective fine on our entire village — including people who had nothing to do with the incident.",
    choices: [
      { id: "collective", text: "Colonial regulations sometimes allowed collective punishment — fines or penalties imposed on entire villages or communities for the acts of a few — a practice with no individual guilt requirement" },
      { id: "individualOnly", text: "Colonial law only ever punished the specific individual proven responsible for an act" },
    ],
    correctChoice: "collective",
    explanation:
      "Various colonial-era regulations permitted collective punishment of villages or communities, imposing fines or penalties without requiring proof of individual guilt — a practice fundamentally at odds with modern principles of individual criminal responsibility.",
    historicalNote:
      "The idea that punishment must be tied to individual, proven guilt is central to Article 20's protections.",
    mature: false,
  },
  {
    id: "c21",
    article: "Article 21",
    articleTitle: "Right to Life and Personal Liberty",
    clientName: "Munshi",
    clientRole: "Recruited indentured labourer",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#FFFFFF", pants: "#37474F", shoes: null },
    accessories: [],
    sceneText:
      "A recruiting agent promised good wages on a distant plantation overseas. I signed papers I could not fully read. Now I find the working conditions and terms are far harsher than promised, and leaving is not simple.",
    choices: [
      { id: "girmitiya", text: "The indentured labour ('girmitiya') system saw many Indians recruited, often through misleading promises, into harsh, restrictive labour contracts on plantations abroad" },
      { id: "fairContract", text: "All indentured labour contracts were transparent and fairly enforced with full worker consent" },
    ],
    correctChoice: "girmitiya",
    explanation:
      "The indentured labour system sent large numbers of Indians to plantations in places like Mauritius, Fiji, and the Caribbean, frequently through misleading recruitment practices and into working conditions with limited real personal liberty — a significant and often overlooked chapter of colonial history.",
    historicalNote:
      "This history is part of why personal liberty in Article 21 is framed as an unconditional right, not one dependent on a signed contract.",
    mature: false,
  },
  {
    id: "c21a",
    article: "Article 21A",
    articleTitle: "Right to Education",
    clientName: "Radha",
    clientRole: "Girl from a rural farming family",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#5D4E75", pants: "#3E3358", shoes: null },
    accessories: [],
    sceneText:
      "Colonial education policy focuses heavily on producing English-educated clerks for administration in cities. In my village, there is no functioning school at all, especially for girls.",
    choices: [
      { id: "macaulay", text: "Colonial education policy, shaped significantly by documents like Macaulay's 1835 Minute on Education, prioritized English-medium education for a small elite, leaving mass literacy — especially in rural areas and for girls — largely neglected" },
      { id: "universalAccess", text: "Colonial policy provided universal, free education access to all children including in rural areas" },
    ],
    correctChoice: "macaulay",
    explanation:
      "Colonial education policy, influenced by Macaulay's 1835 Minute, focused resources on producing English-educated administrators from a small elite, while mass literacy — particularly in rural areas and for girls — remained severely neglected throughout colonial rule.",
    historicalNote:
      "India's literacy rate at independence in 1947 was around 12% — a legacy the Constitution's education provisions were meant to begin reversing.",
    mature: false,
  },
  {
    id: "c22",
    article: "Article 22",
    articleTitle: "Protection Against Arbitrary Arrest",
    clientName: "Bhagat",
    clientRole: "Suspected participant in the independence movement",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    sceneText:
      "I am arrested and detained without formal trial or charge, on mere suspicion of involvement in political activity against colonial rule.",
    choices: [
      { id: "rowlatt", text: "The 1919 Rowlatt Act allowed authorities to imprison suspects without trial for up to two years, sparking massive nationwide protest" },
      { id: "trialGuaranteed", text: "Colonial law guaranteed every accused person a prompt, fair trial with legal representation" },
    ],
    correctChoice: "rowlatt",
    explanation:
      "The Rowlatt Act of 1919 permitted indefinite detention without trial and became one of the most reviled pieces of colonial legislation, triggering nationwide protests that formed the backdrop to the Jallianwala Bagh massacre soon after.",
    historicalNote:
      "Article 22's specific procedural safeguards — informing the accused of charges, prompt production before a magistrate — directly respond to this history of detention without trial.",
    mature: false,
  },
  {
    id: "c23",
    article: "Article 23",
    articleTitle: "Prohibition of Forced Labour & Trafficking",
    clientName: "Devi",
    clientRole: "Villager subject to forced wartime labour",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#5D4E75", pants: "#3E3358", shoes: null },
    accessories: [],
    sceneText:
      "During the war effort, colonial authorities have demanded unpaid or underpaid labour from our village for construction and transport work, with little say in the matter.",
    choices: [
      { id: "forcedWar", text: "Forced or underpaid labour demands on villagers for wartime infrastructure and transport needs were a documented practice, an extension of the older begar tradition under colonial administration" },
      { id: "voluntaryPaid", text: "All wartime labour was fully voluntary and fairly compensated" },
    ],
    correctChoice: "forcedWar",
    explanation:
      "Colonial administrations continued and at times intensified demands for forced or underpaid labour, particularly during wartime periods, extending older exploitative labour practices into the modern era.",
    historicalNote:
      "Article 23's explicit prohibition of both forced labour and trafficking addresses this long, continuous history stretching from ancient begar through the colonial period.",
    mature: false,
  },
  {
    id: "c24",
    article: "Article 24",
    articleTitle: "Prohibition of Child Labour",
    clientName: "Chintu",
    clientRole: "Child worker in a cotton mill",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#5D4E75", pants: "#3E3358", shoes: null },
    accessories: [],
    sceneText:
      "I work long shifts in a cotton mill alongside adults, in conditions that are genuinely dangerous for a child. Basic protections are only beginning to be discussed by lawmakers.",
    choices: [
      { id: "earlyActs", text: "Children worked extensively in colonial-era factories and mills under harsh conditions; early Factory Acts (1881, 1891) began introducing limited protections, but enforcement and coverage remained weak" },
      { id: "fullyBanned", text: "Child labour in factories was completely banned and strictly enforced throughout the colonial period" },
    ],
    correctChoice: "earlyActs",
    explanation:
      "Children worked extensively in colonial-era mills and factories. The Factory Acts of 1881 and 1891 introduced early, limited protections (such as minimum age and working hour restrictions), but coverage and enforcement remained weak for decades.",
    historicalNote:
      "Article 24's stronger, more comprehensive protection reflects lessons learned from these earlier, inadequate reforms.",
    mature: false,
  },
  {
    id: "c25",
    article: "Article 25",
    articleTitle: "Freedom of Religion",
    clientName: "Fatima",
    clientRole: "Community member observing colonial religious policy",
    palette: { hair: "#1A1A1A", skin: "#D4A574", shirt: "#5D4E75", pants: "#3E3358", shoes: null },
    accessories: [],
    sceneText:
      "The colonial government claims official religious neutrality, but its policies — like separate electorates based on religion — seem to deepen divisions between communities rather than simply staying uninvolved.",
    choices: [
      { id: "divideRule", text: "While officially declaring religious neutrality, colonial policies such as separate electorates (introduced 1909, expanded 1919) are widely seen by historians as deepening communal division, sometimes described as part of a broader 'divide and rule' approach" },
      { id: "neutral", text: "Colonial religious policy was consistently and genuinely neutral with no political effects" },
    ],
    correctChoice: "divideRule",
    explanation:
      "While the colonial government officially maintained a position of religious neutrality, policies like separate electorates are widely analyzed by historians as having deepened communal divisions — a legacy that significantly shaped the subcontinent's later history.",
    historicalNote:
      "This history is central to why the Constitution's framers deliberately built a single, unified electorate with strong individual religious freedom, rather than one organized around religious blocs.",
    mature: false,
  },
  {
    id: "c26",
    article: "Article 26",
    articleTitle: "Freedom to Manage Religious Affairs",
    clientName: "Trustee Anand",
    clientRole: "Temple trust administrator",
    palette: { hair: null, skin: "#8D5524", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    sceneText:
      "Our temple's endowed funds and lands are now subject to colonial government oversight and regulation under a new administrative act, reducing our community's independent control.",
    choices: [
      { id: "endowmentsAct", text: "Acts like the Religious Endowments Act (1863) placed temple and religious trust management under increased government oversight, reducing community-level autonomy" },
      { id: "fullAutonomy", text: "Religious institutions retained complete independent control over their endowments throughout colonial rule" },
    ],
    correctChoice: "endowmentsAct",
    explanation:
      "The Religious Endowments Act of 1863 and related legislation placed increased government oversight on the management of temple and religious trust properties, reducing the independent control communities had previously held.",
    historicalNote:
      "Article 26's guaranteed autonomy for religious denominations to manage their own affairs responds directly to this history of state oversight.",
    mature: false,
  },
  {
    id: "c27",
    article: "Article 27",
    articleTitle: "Freedom from Taxes for a Religion",
    clientName: "Pilgrim Damodar",
    clientRole: "Pilgrim visiting a major temple site",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    sceneText:
      "To visit this temple, I am required to pay a special pilgrim tax collected by the colonial administration — a levy tied directly to a religious site and practice.",
    choices: [
      { id: "pilgrimTax", text: "Pilgrim taxes at religious sites (such as historically at Jagannath Puri) were collected under early colonial administration, before later being phased out following public criticism" },
      { id: "noTax", text: "No taxation was ever connected to religious pilgrimage or sites during colonial rule" },
    ],
    correctChoice: "pilgrimTax",
    explanation:
      "Pilgrim taxes tied to specific religious sites were collected under earlier colonial administration in some regions, drawing criticism for entangling government revenue directly with religious practice, before such taxes were eventually phased out.",
    historicalNote:
      "Article 27's prohibition on taxes earmarked for religious promotion reflects a clear rejection of this kind of entanglement between state revenue and religion.",
    mature: false,
  },
  {
    id: "c28",
    article: "Article 28",
    articleTitle: "Freedom from Religious Instruction in State Institutions",
    clientName: "Student Meena",
    clientRole: "Student at a missionary-run school",
    palette: { hair: "#1A1A1A", skin: "#EFCDB0", shirt: "#5D4E75", pants: "#3E3358", shoes: null },
    accessories: [],
    sceneText:
      "The only school within reach of my village is run by a Christian mission and receives some government support. Attending means I'm required to take part in religious instruction, regardless of my own family's faith.",
    choices: [
      { id: "noChoice", text: "Where mission-run schools receiving government support were often the only accessible option in an area, students had little real choice but to attend religious instruction outside their own tradition" },
      { id: "alwaysOptional", text: "Religious instruction was always fully optional with equally accessible non-religious alternatives everywhere" },
    ],
    correctChoice: "noChoice",
    explanation:
      "In many areas, mission-run schools receiving some government support were the only realistically accessible option, meaning students often had little genuine choice but to take part in religious instruction outside their own family's tradition.",
    historicalNote:
      "Article 28's protection for students at wholly state-funded institutions directly addresses this kind of practical lack of choice.",
    mature: false,
  },
  {
    id: "c29",
    article: "Article 29",
    articleTitle: "Protection of Minority Culture & Language",
    clientName: "Professor Bose",
    clientRole: "Educator advocating for vernacular education",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: ["collar"],
    sceneText:
      "Higher education and administration are conducted almost entirely in English, following the direction set decades ago. Regional languages and their literary traditions are increasingly sidelined in formal, prestigious spaces.",
    choices: [
      { id: "englishDominant", text: "Following Macaulay's 1835 Minute on Education, English became the dominant language of higher education and administration, significantly sidelining regional languages in formal and prestigious spaces" },
      { id: "equalStanding", text: "Regional languages retained equal official standing alongside English throughout colonial administration and education" },
    ],
    correctChoice: "englishDominant",
    explanation:
      "Macaulay's 1835 Minute explicitly prioritized English-medium education, and English became the dominant language of higher administration and prestigious education, sidelining regional languages from these formal spaces even as they continued to flourish in literature and daily life.",
    historicalNote:
      "Article 29's protection of minority language and culture reflects a deliberate constitutional effort to prevent this kind of linguistic marginalization going forward.",
    mature: false,
  },
  {
    id: "c30",
    article: "Article 30",
    articleTitle: "Minority Right to Establish Educational Institutions",
    clientName: "Elder Rahim",
    clientRole: "Leader of a minority religious community",
    palette: { hair: null, skin: "#8D5524", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    sceneText:
      "Our community wishes to establish and run our own school, teaching in our own tradition and language. We must apply for government recognition and funding, which is not guaranteed and can be denied.",
    choices: [
      { id: "discretionary", text: "Establishing and receiving recognition or funding for a minority community's own educational institution was subject to colonial administrative discretion, not a guaranteed right" },
      { id: "guaranteedRight", text: "Every minority community had an automatic, guaranteed right to establish and fund its own institutions" },
    ],
    correctChoice: "discretionary",
    explanation:
      "Recognition and support for a minority community's own educational institutions depended on colonial administrative discretion during this period, rather than being a standing, guaranteed right belonging to the community.",
    historicalNote:
      "This is exactly why the Constitution's framers made Article 30 an explicit, guaranteed right rather than leaving it to administrative discretion.",
    mature: false,
  },
];
