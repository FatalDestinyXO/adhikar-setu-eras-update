// -------- Scenarios (Adhikar Setu) --------
// Fully editable. Add or remove scenarios freely.

export const SCENARIOS = [
  {
    id: "s01",
    clientName: "Ramesh Kaka",
    clientRole: "Elder from a nearby village",
    palette: {
      hair: "#B8B8B8",
      skin: "#D4A574",
      shirt: "#F5F5DC",
      pants: "#5C4033",
      shoes: "#2C1A0F",
    },
    accessories: ["beard"],
    shortText:
      "The temple guard blocked me at the door. He said people of my caste cannot enter. Is this allowed under our Constitution?",
    fullText:
      "I was denied entry to a public temple citing my caste background. The temple authority openly stated that persons of certain castes are barred from the inner sanctum. This is a form of untouchability practiced in a place of public worship.",
    correct: "yes",
    article: "Article 17",
    articleTitle: "Abolition of Untouchability",
    articleSummary:
      "'Untouchability' is abolished and its practice in any form is forbidden. Enforcement of any disability arising from untouchability is an offence punishable by law.",
    oneLiner: "Untouchability is banned in every form — even at a temple door.",
    advocateId: "priya",
    advanced: false,
  },
  {
    id: "s02",
    clientName: "Kavita Devi",
    clientRole: "Tenant",
    palette: {
      hair: "#2C1810",
      skin: "#EFCDB0",
      shirt: "#A0522D",
      pants: "#8B4513",
      shoes: "#2C1A0F",
    },
    accessories: ["bindi"],
    shortText:
      "My landlord suddenly doubled the rent last week — no notice, no reason. Can I take him to court over Fundamental Rights?",
    fullText:
      "My private landlord unilaterally doubled the rent overnight, violating our verbal agreement. He is a private individual and there is no State involvement.",
    correct: "no",
    article: null,
    articleTitle: null,
    articleSummary: null,
    oneLiner:
      "A private rent dispute is a civil matter — not a Fundamental Rights case.",
    advocateId: null,
    advanced: false,
  },
  {
    id: "s03",
    clientName: "Ali Farooqui",
    clientRole: "Journalist",
    palette: {
      hair: "#1A1A1A",
      skin: "#D4A574",
      shirt: "#2F4F4F",
      pants: "#1C1C1C",
      shoes: "#000000",
    },
    accessories: ["pressBadge"],
    shortText:
      "I wrote a newspaper article criticizing a minister's policy. The police arrested me the next morning. Is this allowed?",
    fullText:
      "I published a critical opinion piece questioning a minister's policy failures. I was arrested under a vague charge the following day, with the FIR quoting my article verbatim.",
    correct: "yes",
    article: "Article 19(1)(a)",
    articleTitle: "Freedom of Speech and Expression",
    articleSummary:
      "All citizens have the right to freedom of speech and expression, including the right to criticize the Government. Restrictions must be 'reasonable' and only for specific grounds.",
    oneLiner: "Free speech includes the right to criticize the government.",
    advocateId: "rohan",
    advanced: false,
  },
  {
    id: "s04",
    clientName: "Sunita Rao",
    clientRole: "Detained Citizen",
    palette: {
      hair: "#3D2817",
      skin: "#E5B891",
      shirt: "#556B2F",
      pants: "#2F2F2F",
      shoes: "#000000",
    },
    accessories: [],
    shortText:
      "The police picked up my brother yesterday. Nobody told us why. It has been more than 24 hours and he has not been produced before any magistrate.",
    fullText:
      "My brother was arrested without the grounds of arrest being communicated, no legal representation was permitted, and he was not produced before the nearest magistrate within twenty-four hours of arrest.",
    correct: "yes",
    article: "Article 22",
    articleTitle: "Protection Against Arbitrary Arrest",
    articleSummary:
      "Every arrested person must be informed of the grounds, allowed to consult a lawyer, and produced before a magistrate within 24 hours.",
    oneLiner: "The State can't hold you in the dark — you must be told why and produced fast.",
    advocateId: "meera",
    advanced: false,
  },
  {
    id: "s05",
    clientName: "Arjun Patel",
    clientRole: "Job Seeker",
    palette: {
      hair: "#000000",
      skin: "#C8956D",
      shirt: "#4682B4",
      pants: "#000080",
      shoes: "#2C1A0F",
    },
    accessories: [],
    shortText:
      "A private company refused to hire me — the manager admitted it was because of my community. Can the Fundamental Rights help me?",
    fullText:
      "A private, non-State employer explicitly refused my job application on grounds of my community identity. There is no State action or public authority involved. Article 15 restricts the State — Article 15(2) applies to shops and public places but Article 15 as a Fundamental Right does NOT bind private employers in hiring.",
    correct: "no",
    article: null,
    articleTitle: null,
    articleSummary:
      "Article 15 restricts the STATE from discriminating. Purely private hiring bias is not itself a Fundamental Rights violation — separate anti-discrimination statutes may apply.",
    oneLiner:
      "Article 15 binds the STATE, not private hiring bias — a teaching moment, not a Fundamental Rights case.",
    advocateId: null,
    advanced: true,
  },
  {
    id: "s06",
    clientName: "Zara Khan",
    clientRole: "School Student",
    palette: {
      hair: "#3D2817",
      skin: "#EFCDB0",
      shirt: "#4B0082",
      pants: "#000080",
      shoes: "#2C1A0F",
    },
    accessories: ["strap"],
    shortText:
      "The government school in my area refused to admit me because of my religion. The principal said 'we don't take your kind here.'",
    fullText:
      "A State-run school denied me admission openly citing my religion. The State cannot discriminate on grounds of religion, race, caste, sex or place of birth in access to public institutions.",
    correct: "yes",
    article: "Article 15",
    articleTitle: "Prohibition of Discrimination by the State",
    articleSummary:
      "The State shall not discriminate against any citizen on grounds only of religion, race, caste, sex, place of birth or any of them, including in access to public institutions like State-run schools.",
    oneLiner: "The State cannot shut a government school's gate on you for your religion.",
    advocateId: "priya",
    advanced: false,
  },
  {
    id: "s07",
    clientName: "Chotu",
    clientRole: "Child (age 12)",
    palette: {
      hair: "#1A1A1A",
      skin: "#B88A5A",
      shirt: "#8B4513",
      pants: "#5C4033",
      shoes: "#2C1A0F",
    },
    accessories: [],
    shortText:
      "I am 12. My uncle sent me to work in a fireworks factory. I want to go to school but they say I have to earn.",
    fullText:
      "A minor aged twelve is engaged in hazardous factory labour (fireworks) instead of attending school. This engages both the child-labour prohibition and the right to free & compulsory education for ages 6–14.",
    correct: "yes",
    article: "Article 24 / 21A",
    articleTitle: "Child Labour Ban + Right to Education",
    articleSummary:
      "Article 24 bans employment of children below 14 years in any factory, mine, or other hazardous employment. Article 21A guarantees free and compulsory education to all children between 6 and 14.",
    oneLiner: "No child under 14 in hazardous work — and school is a right, not a privilege.",
    advocateId: "arjun",
    advanced: false,
  },
  {
    id: "s08",
    clientName: "Ms. Fernandes",
    clientRole: "Traveller",
    palette: {
      hair: "#5C4033",
      skin: "#EFCDB0",
      shirt: "#008B8B",
      pants: "#2F2F2F",
      shoes: "#000000",
    },
    accessories: ["glasses"],
    shortText:
      "My passport was taken away by an official — no reason, no hearing, no chance to explain. Can they just do that?",
    fullText:
      "A State authority impounded my passport without offering any pre-decisional hearing, notice, or reasons. This impacts my personal liberty and freedom to travel abroad.",
    correct: "yes",
    article: "Article 21",
    articleTitle: "Right to Life and Personal Liberty",
    articleSummary:
      "No person shall be deprived of life or personal liberty except by procedure established by law — and that procedure must be fair, just and reasonable (Maneka Gandhi principle). Includes right to travel abroad and to be heard.",
    oneLiner:
      "Personal liberty needs fair procedure — silent seizure of your passport doesn't cut it.",
    advocateId: "meera",
    advanced: false,
  },
  {
    id: "s09",
    clientName: "Bunty",
    clientRole: "Cricket Kid",
    palette: {
      hair: "#B87333",
      skin: "#E5B891",
      shirt: "#FFD700",
      pants: "#0000CD",
      shoes: "#FFFFFF",
    },
    accessories: ["cap"],
    shortText:
      "My friends keep teasing me because I dropped a catch in our gully cricket match. Is this a Fundamental Rights violation?",
    fullText:
      "My peers have been mocking me for a sporting mistake. This is entirely a personal, social interaction with no State involvement and no legally protected interest at stake.",
    correct: "no",
    article: null,
    articleTitle: null,
    articleSummary: null,
    oneLiner: "Playground teasing is a personal matter — not a constitutional case.",
    advocateId: null,
    advanced: false,
  },
  {
    id: "s10",
    clientName: "Rahul Menon",
    clientRole: "Wronged Citizen",
    palette: {
      hair: "#2C1810",
      skin: "#D4A574",
      shirt: "#B22222",
      pants: "#2F4F4F",
      shoes: "#000000",
    },
    accessories: [],
    shortText:
      "Someone told me that ordinary citizens like me cannot even approach the Supreme Court for a rights violation. Is that true?",
    fullText:
      "I was told I lack any right to directly approach the Supreme Court for enforcement of my Fundamental Rights. This is factually and constitutionally incorrect.",
    correct: "yes",
    article: "Article 32",
    articleTitle: "Right to Constitutional Remedies",
    articleSummary:
      "The right to move the Supreme Court by appropriate proceedings for the enforcement of Fundamental Rights is itself a Fundamental Right — called by Dr. Ambedkar the 'heart and soul' of the Constitution.",
    oneLiner: "The Supreme Court's door is a Fundamental Right — the 'heart and soul' of it all.",
    advocateId: "sameer",
    advanced: false,
  },
  {
    id: "s11",
    clientName: "Meena Bai",
    clientRole: "Community Elder",
    palette: {
      hair: "#2C1810",
      skin: "#D4A574",
      shirt: "#DC143C",
      pants: "#4B0082",
      shoes: "#2C1A0F",
    },
    accessories: ["longHair", "bindi"],
    shortText:
      "Our community wanted to hold our traditional festival dance in the village square — like every year. The panchayat banned it this time, saying it's not 'mainstream culture'. It disturbs no one.",
    fullText:
      "A local State authority prohibited a peaceful, traditional religious festival practice of our community solely on the ground of it not being 'mainstream'. There was no threat to public order, morality, or health cited.",
    correct: "yes",
    article: "Article 25",
    articleTitle: "Freedom of Conscience & Religion",
    articleSummary:
      "All persons are equally entitled to freedom of conscience and the right freely to profess, practise and propagate religion — subject only to public order, morality and health.",
    oneLiner:
      "Your faith and its peaceful practice are protected — the State can't ban a peaceful ritual just because it seems unfamiliar.",
    advocateId: "priya",
    advanced: false,
  },
  {
    id: "s12",
    clientName: "Harpreet Singh",
    clientRole: "Shopkeeper",
    palette: {
      hair: "#000000",
      skin: "#EFCDB0",
      shirt: "#FF8C00",
      pants: "#2F4F4F",
      shoes: "#2C1A0F",
    },
    accessories: ["turban"],
    shortText:
      "The government passed a new rule: only shopkeepers with a shop-front smaller than 100 sq ft must pay a special 'tiny shop' tax. There's no revenue logic — they just picked us.",
    fullText:
      "A State enactment imposes a special tax burden exclusively on a narrow class of shopkeepers, without any rational nexus to the object sought to be achieved and without an 'intelligible differentia'. This is an arbitrary classification.",
    correct: "yes",
    article: "Article 14",
    articleTitle: "Equality Before Law",
    articleSummary:
      "The State shall not deny to any person equality before the law or the equal protection of the laws. Any classification must rest on 'intelligible differentia' with a 'rational nexus' to the law's purpose — arbitrary classifications fail Article 14.",
    oneLiner:
      "The State can't randomly single out one group for harsher treatment — every classification needs a reason.",
    advocateId: "priya",
    advanced: false,
  },
  {
    id: "s13",
    clientName: "Prof. Iyer",
    clientRole: "Retired Law Professor",
    palette: {
      hair: "#EFEFEF",
      skin: "#D4A574",
      shirt: "#4682B4",
      pants: "#2F2F2F",
      shoes: "#000000",
    },
    accessories: ["beard", "glasses"],
    shortText:
      "I've been waiting decades for Parliament to enact a Uniform Civil Code as Article 44 asks. Can I go straight to the Supreme Court under Article 32 and force them to pass the law?",
    fullText:
      "Article 44 (Uniform Civil Code) sits in Part IV — the Directive Principles of State Policy. These are 'fundamental in the governance of the country' but are expressly NOT enforceable by any court (see Article 37). A citizen cannot compel legislation itself through Article 32.",
    correct: "no",
    article: null,
    articleTitle: "Directive Principle — Not a Fundamental Right",
    articleSummary:
      "Directive Principles of State Policy (Part IV) — including Article 44 (UCC), Article 39A (free legal aid), Article 40 (village panchayats) — guide the State's policy but are NOT directly enforceable in court. They differ from Fundamental Rights (Part III), which are.",
    oneLiner:
      "Directive Principles are goals for the State — inspiring, but a court can't force Parliament to legislate them.",
    advocateId: null,
    advanced: false,
  },
  {
    id: "s14",
    clientName: "Deepa Nair",
    clientRole: "Government job applicant",
    palette: { hair: "#1A1A1A", skin: "#D4A574", shirt: "#4B0082", pants: "#2C2C2C", shoes: "#000000" },
    accessories: ["glasses"],
    shortText:
      "I scored highest in the state exam for a government post, but the offer went to a lower-scoring candidate whose family knows the recruiting officer. Is this allowed?",
    fullText:
      "A public-sector recruitment process awarded the post to a lower-scoring candidate due to personal connections with the recruiting officer, bypassing merit-based selection criteria set by the State itself.",
    correct: "yes",
    article: "Article 16",
    articleTitle: "Equality of Opportunity in Public Employment",
    articleSummary:
      "All citizens have equal opportunity in matters of public employment. The State cannot discriminate on grounds of religion, race, caste, sex, descent, place of birth, or residence — and cannot bypass its own merit criteria through favoritism.",
    oneLiner: "Public jobs must go by fair, equal process — not personal connections.",
    advocateId: "meera",
    advanced: false,
  },
  {
    id: "s15",
    clientName: "Vikram Rao",
    clientRole: "District revenue officer",
    palette: { hair: "#2C1810", skin: "#C68642", shirt: "#FFFFFF", pants: "#37474F", shoes: "#1A1A1A" },
    accessories: [],
    shortText:
      "A local landlord insists government officials address him by his family's old royal title and grants his applications faster processing because of it. Can a title still carry legal weight like this?",
    fullText:
      "A citizen holding a former princely title is receiving preferential treatment and faster processing on official government applications specifically because officials continue to formally recognize and defer to the hereditary title.",
    correct: "yes",
    article: "Article 18",
    articleTitle: "Abolition of Titles",
    articleSummary:
      "The State cannot confer titles (other than military or academic distinctions) on any person, and no citizen may derive special privilege from a title in dealings with the State — hereditary titles carry no official legal weight.",
    oneLiner: "Hereditary titles get you nothing extra from the government — everyone is processed equally.",
    advocateId: "rohan",
    advanced: false,
  },
  {
    id: "s16",
    clientName: "Farhan Sheikh",
    clientRole: "Acquitted defendant",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#2F4F4F", pants: "#1C1C1C", shoes: "#000000" },
    accessories: [],
    shortText:
      "I was tried and acquitted of theft last year. Now police want to arrest and try me again for the very same incident, using the same evidence. Can they do that?",
    fullText:
      "Police seek to re-arrest and re-prosecute a person for an offence for which they were already tried and acquitted by a competent court, based on the same facts and evidence.",
    correct: "yes",
    article: "Article 20",
    articleTitle: "Protection Against Double Jeopardy",
    articleSummary:
      "No person can be prosecuted and punished for the same offence more than once (protection against double jeopardy), nor punished under a law that did not exist when the act was committed, nor compelled to be a witness against themselves.",
    oneLiner: "Once tried and acquitted for something, you can't be tried again for the same act.",
    advocateId: "sameer",
    advanced: false,
  },
  {
    id: "s17",
    clientName: "Lakshmi Bai",
    clientRole: "Domestic worker",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#B22222", pants: "#5C4033", shoes: null },
    accessories: ["bindi"],
    shortText:
      "I took a small loan from my employer and now I'm told I must keep working for them, unpaid, until the debt is cleared — with no end date given. Is this legal?",
    fullText:
      "An employer is holding a worker in indefinite, effectively unpaid labour to work off a small debt, with no clear terms or end date — a form of bonded labour.",
    correct: "yes",
    article: "Article 23",
    articleTitle: "Prohibition of Forced Labour",
    articleSummary:
      "Traffic in human beings, begar (forced uncompensated labour), and similar forms of forced labour are prohibited, and any contravention is punishable by law — including bonded labour arrangements like debt bondage.",
    oneLiner: "A debt can't be used to trap someone in unpaid, indefinite labour.",
    advocateId: "priya",
    advanced: false,
  },
  {
    id: "s18",
    clientName: "Trust Secretary Anantha",
    clientRole: "Temple trust administrator",
    palette: { hair: null, skin: "#D4A574", shirt: "#FF8C00", pants: "#8B4513", shoes: null },
    accessories: [],
    shortText:
      "A local government body wants to directly appoint the temple's chief priest and dictate our internal rituals, overriding decisions our trust has always made ourselves. Can they do this?",
    fullText:
      "A government body is attempting to directly control internal religious/ritual decisions of a religious denomination's institution, beyond regulating its secular administrative or financial affairs.",
    correct: "yes",
    article: "Article 26",
    articleTitle: "Freedom to Manage Religious Affairs",
    articleSummary:
      "Every religious denomination has the right to manage its own affairs in matters of religion, and to own, acquire, and administer property. The State can regulate secular/financial administration, but not dictate core religious practice.",
    oneLiner: "The State can regulate temple finances, but not dictate religious practice itself.",
    advocateId: "meera",
    advanced: false,
  },
  {
    id: "s19",
    clientName: "Taxpayer Suresh",
    clientRole: "Small business owner",
    palette: { hair: "#2C1810", skin: "#D4A574", shirt: "#4682B4", pants: "#2F2F2F", shoes: "#000000" },
    accessories: ["glasses"],
    shortText:
      "My municipality introduced a special local cess specifically earmarked to fund the renovation of one particular community's religious site, and I'm required to pay it regardless of my own faith.",
    fullText:
      "A local government has levied a tax specifically earmarked to fund the promotion or maintenance of one particular religion, collected from all residents regardless of their own faith.",
    correct: "yes",
    article: "Article 27",
    articleTitle: "Freedom from Taxes for Promotion of a Religion",
    articleSummary:
      "No person can be compelled to pay any tax whose proceeds are specifically earmarked for the promotion or maintenance of any particular religion or religious denomination.",
    oneLiner: "Public tax money can't be earmarked to promote one specific religion.",
    advocateId: "rohan",
    advanced: false,
  },
  {
    id: "s20",
    clientName: "Parent Iqbal",
    clientRole: "Parent of a school student",
    palette: { hair: "#1A1A1A", skin: "#C68642", shirt: "#2F4F4F", pants: "#1C1C1C", shoes: "#000000" },
    accessories: [],
    shortText:
      "My child attends the only school in our area — a fully government-run, government-funded school. It now requires all students to take part in religious instruction of a faith we don't follow, with no opt-out offered.",
    fullText:
      "A wholly State-funded educational institution requires all students to participate in religious instruction, with no exemption offered for students of a different faith or no faith.",
    correct: "yes",
    article: "Article 28",
    articleTitle: "Freedom from Religious Instruction in State Institutions",
    articleSummary:
      "No religious instruction shall be provided in any educational institution wholly maintained by State funds, and students at State-recognized or State-aided institutions cannot be compelled to attend religious instruction without consent.",
    oneLiner: "A fully government-funded school can't mandate religious instruction on any student.",
    advocateId: "sameer",
    advanced: false,
  },
  {
    id: "s21",
    clientName: "Elder Thoiba",
    clientRole: "Member of a linguistic minority community",
    palette: { hair: "#1A1A1A", skin: "#8D5524", shirt: "#B22222", pants: "#5C4033", shoes: null },
    accessories: [],
    shortText:
      "Our community's script has been used for our language for generations. A new local policy now bans teaching it in schools, requiring only the majority script to be taught instead.",
    fullText:
      "A policy bans instruction in a minority community's traditional script and language in local schools, requiring exclusive use of the majority community's script.",
    correct: "yes",
    article: "Article 29",
    articleTitle: "Protection of Interests of Minorities",
    articleSummary:
      "Any section of citizens having a distinct language, script, or culture has the right to conserve it. The State cannot deny admission to educational institutions on grounds of religion, race, caste, or language.",
    oneLiner: "A minority's language and script are protected — the State can't erase them by policy.",
    advocateId: "priya",
    advanced: false,
  },
  {
    id: "s22",
    clientName: "Principal Noor",
    clientRole: "Head of a minority-run school",
    palette: { hair: "#1A1A1A", skin: "#D4A574", shirt: "#FF8C00", pants: "#8B4513", shoes: null },
    accessories: ["glasses"],
    shortText:
      "Our community built and has run this school for decades. The local authority now wants to take over its administration entirely, without any legal proceeding, simply because it's popular and well-funded.",
    fullText:
      "A local authority attempts to take over administrative control of a minority-run, minority-established educational institution without due legal process, undermining the community's right to administer its own institution.",
    correct: "yes",
    article: "Article 30",
    articleTitle: "Minority Right to Establish and Administer Institutions",
    articleSummary:
      "All religious and linguistic minorities have the right to establish and administer educational institutions of their choice. The State cannot arbitrarily take over such an institution's administration without due legal process.",
    oneLiner: "Minority communities have a guaranteed right to both establish AND administer their own schools.",
    advocateId: "arjun",
    advanced: false,
  },
];

export function getScenariosForRound({ includeAdvanced = false, count = 6 } = {}) {
  const pool = SCENARIOS.filter((s) => (includeAdvanced ? true : !s.advanced));
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

export function getScenarioById(id) {
  return SCENARIOS.find((s) => s.id === id) || null;
}
