// -------- Advocate Specialists --------
// Each specialist handles a set of Fundamental Rights articles.

export const ADVOCATES = [
  {
    id: "priya",
    name: "Advocate Priya",
    title: "Equality & Anti-Discrimination",
    articles: ["Article 14", "Article 15", "Article 16", "Article 17", "Article 18", "Article 25", "Article 29"],
    tagline: "Equality is the soul of the Republic.",
    palette: {
      hair: "#2C1810",
      skin: "#EFCDB0",
      shirt: "#4CAF50",
      pants: "#2F4F2F",
      shoes: "#2C1A0F",
    },
    accessories: ["longHair"],
  },
  {
    id: "rohan",
    name: "Advocate Rohan",
    title: "Free Speech & Expression",
    articles: ["Article 19", "Article 19(1)(a)", "Article 19(1)(b)", "Article 19(1)(c)"],
    tagline: "Ideas are louder than any cannon.",
    palette: {
      hair: "#1A1A1A",
      skin: "#D4A574",
      shirt: "#F44336",
      pants: "#1C1C1C",
      shoes: "#000000",
    },
    accessories: ["pressBadge"],
  },
  {
    id: "meera",
    name: "Advocate Meera",
    title: "Life, Liberty & Fair Procedure",
    articles: ["Article 20", "Article 21", "Article 22"],
    tagline: "Liberty is not the State's to gift or take.",
    palette: {
      hair: "#3D2817",
      skin: "#E5B891",
      shirt: "#2F4F4F",
      pants: "#1C1C1C",
      shoes: "#000000",
    },
    accessories: ["glasses"],
  },
  {
    id: "arjun",
    name: "Advocate Arjun",
    title: "Child Rights & Education",
    articles: ["Article 21A", "Article 23", "Article 24"],
    tagline: "A child protected today is a citizen tomorrow.",
    palette: {
      hair: "#5C3D24",
      skin: "#D4A574",
      shirt: "#F57C00",
      pants: "#4A2E15",
      shoes: "#2C1A0F",
    },
    accessories: [],
  },
  {
    id: "sameer",
    name: "Advocate Sameer",
    title: "Constitutional Remedies",
    articles: ["Article 32", "Article 226"],
    tagline: "The heart & soul of the Constitution.",
    palette: {
      hair: "#B8B8B8",
      skin: "#EFCDB0",
      shirt: "#673AB7",
      pants: "#2C1A0F",
      shoes: "#000000",
    },
    accessories: ["beard"],
  },
];

export function getAdvocateById(id) {
  return ADVOCATES.find((a) => a.id === id) || null;
}

export function getAdvocateForArticle(article) {
  if (!article) return null;
  const normalized = article.toString().toLowerCase();
  const match = ADVOCATES.find((a) =>
    a.articles.some((art) => normalized.includes(art.toLowerCase()))
  );
  return match || null;
}
