// -------- Sprite data: 12 x 19 humanoid pixel map --------
// Character chars:
//   .  transparent
//   k  outline (dark)
//   h  hair
//   s  skin
//   e  eye (dark)
//   m  mouth
//   S  shirt / dress
//   P  pants
//   B  shoes

export const HUMANOID_ROWS = [
  "..kkkkkkkk..", // 0
  ".khhhhhhhhk.", // 1
  "khhhhhhhhhhk", // 2
  "khhssssssshk", // 3
  "khsssssssshk", // 4
  ".ksessssesk.", // 5   eyes
  ".kssssssssk.", // 6
  ".kssssmmssk.", // 7   mouth
  "..ksssssssk.", // 8   chin
  "..kkSSSSkk..", // 9   shoulders
  ".kSSSSSSSSk.", // 10
  "kSSSSSSSSSSk", // 11
  "kSSSSSSSSSSk", // 12
  "kSSSSSSSSSSk", // 13
  ".kSSSSSSSSk.", // 14
  ".kPPPPPPPPk.", // 15
  ".kPPkk..PPk.", // 16   leg gap
  ".kPPk..kPPk.", // 17
  "..BBk..kBB..", // 18   shoes
];

// Optional accessory overlays — draw over the base
// Each is { rows, dy (y-shift) }
export const ACCESSORIES = {
  // Turban / topi (wraps around hair area rows 0-3)
  turban: {
    dy: 0,
    palette: { A: "#F5F5DC" },
    rows: [
      ".AAAAAAAAAA.",
      "AAAAAAAAAAAA",
      "AAAAAAAAAAAA",
      "AA........AA",
    ],
  },
  // Long hair (rows 9-14, over shoulder)
  longHair: {
    dy: 9,
    palette: { A: "#h" }, // handled specially (uses hair color)
    rows: [
      "AA......AA..",
      "AA......AA..",
      "AA......AA..",
      "AA......AA..",
    ],
  },
  // Bowtie / press badge (row 10)
  pressBadge: {
    dy: 10,
    palette: { A: "#FFD700" },
    rows: ["....AA......"],
  },
  // Bindi / dot on forehead
  bindi: {
    dy: 4,
    palette: { A: "#B22222" },
    rows: ["....AA......"],
  },
  // White beard (rows 7-8)
  beard: {
    dy: 7,
    palette: { A: "#EFEFEF" },
    rows: [".AAAAAAAAAA.", "..AAAAAAAA.."],
  },
  // Cap
  cap: {
    dy: 0,
    palette: { A: "#1E3A8A" },
    rows: ["..AAAAAAAA..", ".AAAAAAAAAA."],
  },
  // Briefcase — held to side (rows 11-14, right edge)
  briefcase: {
    dy: 11,
    palette: { A: "#5C4033", B: "#FFD700" },
    rows: [
      "...........A",
      "..........AA",
      "..........AB",
      "..........AA",
    ],
  },
  // Backpack strap
  strap: {
    dy: 10,
    palette: { A: "#8B4513" },
    rows: [".A........A."],
  },
  // Glasses (row 5)
  glasses: {
    dy: 5,
    palette: { A: "#2C1A0F" },
    rows: [".AAA..AAA..."],
  },
  // Small child head (offset lower)
  child: {
    dy: 0,
    palette: {},
    rows: [], // child handled by scale
  },
  // Tilak / sandalwood forehead mark (ancient & medieval male characters)
  tilak: {
    dy: 4,
    palette: { A: "#D2691E" },
    rows: ["....AA......"],
  },
  // Angavastram — thin cloth draped diagonally over one shoulder
  // (Ancient & Medieval era, worn over the base shirt region)
  angavastram: {
    dy: 9,
    palette: { A: "#F5DEB3" },
    rows: [
      "A...........",
      ".A..........",
      "..A.........",
      "...A........",
    ],
  },
  // Pagdi / royal turban (Medieval era — richer color than plain turban)
  pagdi: {
    dy: 0,
    palette: { A: "#B8860B", B: "#8B0000" },
    rows: [
      ".AAAAAAAAAA.",
      "AAAABAAAABAA",
      "AAAAAAAAAAAA",
      "AA........AA",
    ],
  },
  // Saree pallu — drape over shoulder (Medieval/Colonial women)
  pallu: {
    dy: 9,
    palette: { A: "#B22222" },
    rows: [
      "..........A.",
      "..........A.",
      "..........A.",
      "..........A.",
      "..........A.",
    ],
  },
  // Colonial-era shirt collar (Western-style)
  collar: {
    dy: 9,
    palette: { A: "#FFFFFF" },
    rows: [".AA......AA."],
  },
};

// -------- Era-appropriate costume presets --------
// Applies on top of a character's base skin/hair palette.
// Keeps the same 12x19 humanoid shape; changes cloth colors +
// adds period-accurate accessories rather than redesigning the sprite.
export const ERA_COSTUMES = {
  ancient: {
    male: {
      shirt: "#E8D9B5", // unbleached draped cotton (antariya/uttariya)
      pants: "#E8D9B5", // same tone so it reads as one draped garment
      accessories: ["angavastram"],
    },
    female: {
      shirt: "#F0C987",
      pants: "#F0C987",
      accessories: ["angavastram"],
    },
    note:
      "Ancient India (Indus Valley through Gupta era) had established cotton weaving — dress is a simple draped cotton wrap (antariya/uttariya), not animal hide or leaves.",
  },
  medieval: {
    male: {
      shirt: "#8B4513", // kurta tone
      pants: "#F5F5DC", // dhoti/paijama
      accessories: ["pagdi", "tilak"],
    },
    female: {
      shirt: "#C2185B", // saree blouse
      pants: "#AD1457", // saree base
      accessories: ["pallu", "tilak"],
    },
    note: "Regional royal courts: richer dyed fabric, pagdi/turban, tilak.",
  },
  colonial: {
    male: {
      shirt: "#FFFFFF", // shirt
      pants: "#37474F", // trousers
      accessories: ["collar"],
    },
    female: {
      shirt: "#5D4E75", // blouse
      pants: "#3E3358", // long skirt
      accessories: ["collar"],
    },
    note: "British-influenced Western dress: shirt-trousers for men, blouse-skirt for women.",
  },
  constitution: {
    // Uses existing modern advocate palettes already in PLAYER_AVATARS — no change needed.
    male: null,
    female: null,
    note: "Modern dress — same as existing Adhikar Setu advocate/client sprites.",
  },
};

// Common palettes
export const PLAYER_AVATARS = [
  {
    id: "civic-1",
    name: "The Advocate (Warm)",
    palette: {
      hair: "#3D2817",
      skin: "#EFCDB0",
      shirt: "#4CAF50",
      pants: "#2F4F2F",
      shoes: "#2C1A0F",
    },
    accessories: [],
  },
  {
    id: "civic-2",
    name: "The Advocate (Bold)",
    palette: {
      hair: "#1A1A1A",
      skin: "#D4A574",
      shirt: "#673AB7",
      pants: "#2C1A0F",
      shoes: "#000000",
    },
    accessories: ["glasses"],
  },
  {
    id: "civic-3",
    name: "The Advocate (Scholar)",
    palette: {
      hair: "#B8B8B8",
      skin: "#EFCDB0",
      shirt: "#009688",
      pants: "#1C1C1C",
      shoes: "#000000",
    },
    accessories: ["beard"],
  },
  {
    id: "civic-4",
    name: "The Advocate (Kind)",
    palette: {
      hair: "#2C1810",
      skin: "#E5B891",
      shirt: "#F57C00",
      pants: "#4A2E15",
      shoes: "#2C1A0F",
    },
    accessories: ["bindi"],
  },
];
