import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import { HeartFullIcon, CoinIcon, BadgeIcon, ScrollIcon, StarIcon } from "@/components/PixelIcons";
import { useProfile } from "@/game/useProfile";
import { SCENARIOS } from "@/game/scenarios";
import { SFX } from "@/game/audio";
import { toast } from "sonner";

export default function DaySummaryScreen() {
  const nav = useNavigate();
  const { profile, recordDay, loading } = useProfile();
  const [saving, setSaving] = useState(true);
  const [error, setError] = useState(null);
  const [saved, setSaved] = useState(null);

  const lastDay = useMemo(() => {
    try {
      const raw = sessionStorage.getItem("samvidhan.lastDay");
      return raw ? JSON.parse(raw) : null;
    } catch (_) {
      return null;
    }
  }, []);

  useEffect(() => {
    if (loading) return;
    if (!profile) {
      nav("/");
      return;
    }
    if (!lastDay) {
      nav("/play");
      return;
    }
    (async () => {
      try {
        const updated = await recordDay(lastDay);
        setSaved(updated);
        SFX.levelup();
      } catch (e) {
        setError("Could not save day. Progress kept locally.");
      } finally {
        setSaving(false);
      }
    })();
  }, [loading]); // intentionally minimal deps: run once when loading resolves

  if (!lastDay) return null;

  const articleObjs = SCENARIOS.filter((s) => lastDay.articles_covered.includes(s.article));

  return (
    <div className="game-root tiles-wall min-h-screen flex flex-col relative" data-testid="summary-screen">
      <div className="absolute inset-x-0 top-0 h-32 tiles-sky" aria-hidden />
      <div className="absolute inset-x-0 bottom-0 h-40 tiles-floor" aria-hidden />

      <main className="relative z-10 flex-1 flex items-center justify-center p-4 py-8">
        <PixelFrame className="w-full max-w-4xl p-6 md:p-8" bg="#F5E6D3">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading text-sm md:text-lg uppercase text-[#2C1A0F]">
              &gt; Day Report
            </h2>
            {saving ? (
              <span className="font-body text-base text-[#5C4033]">saving...</span>
            ) : error ? (
              <span className="font-body text-base text-[#C62828]">{error}</span>
            ) : (
              <span className="font-body text-base text-[#2E7D32]">Saved!</span>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mb-6">
            <StatCard
              label="Cases Won"
              value={lastDay.day_correct}
              accent="#2E7D32"
              icon={<StarIcon size={3} />}
              testId="stat-won"
            />
            <StatCard
              label="Wrong Calls"
              value={lastDay.day_wrong}
              accent="#C62828"
              icon={<HeartFullIcon size={3} />}
              testId="stat-wrong"
            />
            <StatCard
              label="Cash Earned"
              value={`₹${lastDay.day_cash}`}
              accent="#C7A600"
              icon={<CoinIcon size={3} />}
              testId="stat-cash"
            />
            <StatCard
              label="Best Combo"
              value={`x${lastDay.day_best_combo || 0}`}
              accent="#F57C00"
              icon={<StarIcon size={3} />}
              testId="stat-combo"
            />
            <StatCard
              label="Daily Challenge"
              value={lastDay.daily_challenge_won ? "★ WON" : "—"}
              accent={lastDay.daily_challenge_won ? "#2E7D32" : "#5C4033"}
              icon={<BadgeIcon size={2} color="#FFD700" />}
              testId="stat-daily-challenge"
            />
          </div>

          <div className="mb-6">
            <div className="font-heading text-[10px] md:text-xs uppercase text-[#5C4033] mb-2 flex items-center gap-2">
              <ScrollIcon size={3} /> Articles Covered Today
            </div>
            {articleObjs.length === 0 ? (
              <div className="font-body text-lg text-[#5C4033]">
                No new Articles unlocked this day. Try more &lsquo;Yes&rsquo; cases next time!
              </div>
            ) : (
              <ul className="space-y-2">
                {articleObjs.map((s) => (
                  <li
                    key={s.id}
                    className="border-[3px] border-[#2C1A0F] bg-[#FFF8E7] p-3"
                    style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.3)" }}
                    data-testid={`article-summary-${s.article}`}
                  >
                    <div className="font-heading text-[10px] uppercase text-[#2C1A0F]">
                      {s.article} — {s.articleTitle}
                    </div>
                    <div className="font-body text-lg text-[#2C1A0F] mt-1">
                      {s.oneLiner}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {lastDay.badges_earned && lastDay.badges_earned.length > 0 && (
            <div className="mb-6">
              <div className="font-heading text-[10px] md:text-xs uppercase text-[#5C4033] mb-2">
                &gt; New Badges
              </div>
              <div className="flex flex-wrap gap-3">
                {lastDay.badges_earned.map((b, i) => (
                  <div
                    key={b}
                    className="flex items-center gap-2 border-[3px] border-[#2C1A0F] px-3 py-2 bg-[#FFF3C4]"
                    style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.3)" }}
                    data-testid={`badge-earned-${i}`}
                  >
                    <BadgeIcon size={2} color={["#4CAF50","#F57C00","#673AB7","#009688","#F44336"][i % 5]} />
                    <span className="font-heading text-[9px] uppercase text-[#2C1A0F]">{b}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-wrap justify-end gap-3">
            <RetroButton variant="neutral" size="sm" onClick={() => nav("/leaderboard")} testId="btn-view-leaderboard">
              Leaderboard
            </RetroButton>
            <RetroButton variant="neutral" size="sm" onClick={() => nav("/profile")} testId="btn-view-profile">
              View Profile
            </RetroButton>
            <RetroButton variant="teal" onClick={() => nav("/")} testId="btn-back-home">
              Back to Clinic
            </RetroButton>
            <RetroButton
              variant="yes"
              onClick={() => {
                SFX.click();
                sessionStorage.removeItem("samvidhan.lastDay");
                nav("/play");
              }}
              testId="btn-next-day"
            >
              ▶ Next Day
            </RetroButton>
          </div>
        </PixelFrame>
      </main>
    </div>
  );
}

function StatCard({ label, value, accent, icon, testId }) {
  return (
    <div
      className="border-[3px] border-[#2C1A0F] bg-[#FFF8E7] p-3 flex items-center gap-3"
      style={{ boxShadow: "4px 4px 0 0 rgba(0,0,0,0.35)" }}
      data-testid={testId}
    >
      <div>{icon}</div>
      <div>
        <div className="font-heading text-[8px] uppercase text-[#5C4033]">{label}</div>
        <div className="font-heading text-base md:text-lg" style={{ color: accent }}>
          {value}
        </div>
      </div>
    </div>
  );
}
