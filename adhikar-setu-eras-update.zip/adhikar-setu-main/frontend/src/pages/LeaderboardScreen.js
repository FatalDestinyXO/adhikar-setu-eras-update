import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import { CoinIcon, StarIcon, ScrollIcon } from "@/components/PixelIcons";
import { useProfile } from "@/game/useProfile";
import { fetchLeaderboard } from "@/game/api";

export default function LeaderboardScreen() {
  const nav = useNavigate();
  const { profile, loading } = useProfile();
  const [entries, setEntries] = useState([]);
  const [loadingBoard, setLoadingBoard] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (loading) return;
    (async () => {
      try {
        const data = await fetchLeaderboard(20);
        setEntries(data || []);
      } catch (e) {
        setError("Could not load leaderboard.");
      } finally {
        setLoadingBoard(false);
      }
    })();
  }, [loading]);

  return (
    <div className="game-root min-h-screen tiles-wall p-4" data-testid="leaderboard-screen">
      <div className="max-w-3xl mx-auto py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading text-sm md:text-lg uppercase text-[#FFF8E7] flex items-center gap-2">
            <StarIcon size={4} /> Hall of Advocates
          </h2>
          <RetroButton size="sm" variant="gold" onClick={() => nav("/")} testId="btn-leaderboard-back">
            ◀ Back
          </RetroButton>
        </div>

        <PixelFrame bg="#F5E6D3" className="p-4 md:p-6">
          {loadingBoard ? (
            <div className="font-body text-lg text-[#5C4033]">Loading rankings...</div>
          ) : error ? (
            <div className="font-body text-lg text-[#C62828]" data-testid="leaderboard-error">
              {error}
            </div>
          ) : entries.length === 0 ? (
            <div className="font-body text-lg text-[#5C4033]">
              No advocates yet. Play a day to claim the top spot!
            </div>
          ) : (
            <div className="space-y-2">
              <div className="grid grid-cols-12 gap-2 font-heading text-[8px] md:text-[9px] uppercase text-[#5C4033] px-2 py-1">
                <div className="col-span-1">#</div>
                <div className="col-span-5">Advocate</div>
                <div className="col-span-2 flex items-center gap-1">
                  <CoinIcon size={2} /> Cash
                </div>
                <div className="col-span-2 flex items-center gap-1">
                  <StarIcon size={2} /> Won
                </div>
                <div className="col-span-2 flex items-center gap-1">
                  <ScrollIcon size={2} /> Days
                </div>
              </div>
              {entries.map((e, i) => {
                const isMe = profile && e.username === profile.username;
                return (
                  <div
                    key={e.username}
                    className={`grid grid-cols-12 gap-2 items-center px-2 py-2 border-[3px] font-body text-base md:text-lg ${
                      isMe ? "bg-[#FFF3C4]" : "bg-[#FFF8E7]"
                    }`}
                    style={{
                      borderColor: isMe ? "#F57C00" : "#2C1A0F",
                      boxShadow: "3px 3px 0 0 rgba(0,0,0,0.3)",
                    }}
                    data-testid={`leaderboard-row-${i + 1}`}
                  >
                    <div className="col-span-1 font-heading text-[10px] text-[#2C1A0F]">
                      {i + 1}
                    </div>
                    <div className="col-span-5 text-[#2C1A0F] break-words">
                      {isMe ? "★ " : ""}
                      {e.display_name || e.username}
                      {isMe && (
                        <span className="ml-1 font-heading text-[8px] uppercase text-[#F57C00]">
                          you
                        </span>
                      )}
                    </div>
                    <div className="col-span-2 font-heading text-[10px] text-[#C7A600]">
                      ₹{e.cash}
                    </div>
                    <div className="col-span-2 font-heading text-[10px] text-[#2E7D32]">
                      {e.correct_count || 0}
                    </div>
                    <div className="col-span-2 font-heading text-[10px] text-[#673AB7]">
                      {e.days_played || 0}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </PixelFrame>

        <div className="mt-4 flex flex-wrap justify-end gap-3">
          <RetroButton size="sm" variant="neutral" onClick={() => nav("/profile")} testId="btn-leaderboard-profile">
            My Profile
          </RetroButton>
          <RetroButton variant="yes" onClick={() => nav("/play")} testId="btn-leaderboard-play">
            ▶ Play Now
          </RetroButton>
        </div>
      </div>
    </div>
  );
}
