import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import { ScrollIcon } from "@/components/PixelIcons";
import { useProfile } from "@/game/useProfile";
import { SCENARIOS } from "@/game/scenarios";

export default function AnswerKeyScreen() {
  const nav = useNavigate();
  const { settings, loading, profile } = useProfile();

  useEffect(() => {
    if (loading) return;
    if (!profile) nav("/");
    if (!settings.showAnswerKey) nav("/settings");
  }, [loading, profile, settings.showAnswerKey, nav]);

  if (!settings.showAnswerKey) return null;

  return (
    <div className="game-root min-h-screen tiles-wall p-4" data-testid="answer-key-screen">
      <div className="max-w-5xl mx-auto py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading text-sm md:text-lg uppercase text-[#FFF8E7] flex items-center gap-2">
            <ScrollIcon size={4} /> Teacher / Parent Answer Key
          </h2>
          <RetroButton variant="gold" size="sm" onClick={() => nav("/settings")} testId="btn-answerkey-back">
            ◀ Settings
          </RetroButton>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {SCENARIOS.map((s) => (
            <PixelFrame key={s.id} bg="#F5E6D3" className="p-4" data-testid={`answer-row-${s.id}`}>
              <div className="flex items-baseline justify-between mb-1">
                <div className="font-heading text-[10px] uppercase text-[#2C1A0F]">
                  {s.id} — {s.clientName}
                </div>
                <div
                  className="font-heading text-[9px] uppercase px-2 py-1"
                  style={{
                    background: s.correct === "yes" ? "#4CAF50" : "#F44336",
                    color: "#FFF8E7",
                  }}
                  data-testid={`answer-verdict-${s.id}`}
                >
                  {s.correct === "yes" ? "RIGHT EXISTS" : "NO RIGHT"}
                </div>
              </div>
              <div className="font-body text-base md:text-lg text-[#2C1A0F] mb-2">
                <b>Scenario:</b> {s.shortText}
              </div>
              <div className="font-body text-base md:text-lg text-[#2C1A0F] mb-1">
                <b>Article:</b> {s.article || "—"}
                {s.articleTitle ? ` (${s.articleTitle})` : ""}
              </div>
              <div className="font-body text-base md:text-lg text-[#5C4033]">
                <b>Explanation:</b> {s.oneLiner}
              </div>
              {s.advanced && (
                <div className="font-heading text-[8px] uppercase text-[#F57C00] mt-2">
                  ★ ADVANCED / NUANCE SCENARIO
                </div>
              )}
            </PixelFrame>
          ))}
        </div>
      </div>
    </div>
  );
}
