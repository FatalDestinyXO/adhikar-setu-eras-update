import React from "react";
import { useNavigate } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import { ERA_ORDER, ERA_INFO, getCompletedEras, isEraUnlocked } from "@/game/eraEngine";

export default function EraSelectScreen() {
  const nav = useNavigate();
  const completed = getCompletedEras();

  const handleEnter = (eraId) => {
    if (!isEraUnlocked(eraId)) return;
    if (eraId === "constitution") {
      nav("/play");
    } else {
      nav(`/era/${eraId}`);
    }
  };

  return (
    <div className="tiles-wall min-h-screen flex flex-col items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-3xl">
        <div className="text-center mb-6">
          <h1 className="font-heading text-lg md:text-2xl text-[#FFF8E7] uppercase mb-2">
            Adhikar Setu: Through the Ages
          </h1>
          <p className="font-body text-base md:text-lg text-[#FFF8E7] opacity-80">
            Justice wasn't always guaranteed. Walk through history to see how it was
            won — chapter by chapter — before you defend it today.
          </p>
        </div>

        <div className="flex flex-col gap-4">
          {ERA_ORDER.map((eraId) => {
            const info = ERA_INFO[eraId];
            const unlocked = isEraUnlocked(eraId);
            const done = completed.includes(eraId);
            return (
              <button
                key={eraId}
                onClick={() => handleEnter(eraId)}
                disabled={!unlocked}
                data-testid={`era-card-${eraId}`}
                className={`text-left ${unlocked ? "cursor-pointer" : "cursor-not-allowed opacity-60"}`}
              >
                <PixelFrame bg={info.bg} className="p-4 md:p-5">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="font-heading text-xs md:text-sm text-[#2C1A0F] uppercase flex items-center gap-2">
                        {info.label}
                        {done && <span className="text-[#2E7D32]">✓ Complete</span>}
                        {!unlocked && <span className="text-[#8E0E3B]">🔒 Locked</span>}
                      </div>
                      <div className="font-heading text-[9px] md:text-[10px] text-[#5C4033] uppercase mt-1">
                        {info.subtitle}
                      </div>
                      <div className="font-body text-sm md:text-base text-[#2C1A0F] mt-2">
                        {info.blurb}
                      </div>
                    </div>
                    {unlocked && (
                      <RetroButton
                        variant="gold"
                        size="sm"
                        onClick={() => handleEnter(eraId)}
                        testId={`btn-enter-${eraId}`}
                      >
                        {done ? "Replay ▸" : "Enter ▸"}
                      </RetroButton>
                    )}
                  </div>
                </PixelFrame>
              </button>
            );
          })}
        </div>

        <div className="mt-6 text-center">
          <RetroButton variant="neutral" size="sm" onClick={() => nav("/")} testId="btn-back-home">
            ← Back
          </RetroButton>
        </div>
      </div>
    </div>
  );
}
