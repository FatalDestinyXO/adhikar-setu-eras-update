import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import { HumanoidSprite } from "@/components/PixelSprite";
import { IndiaFlag, StarIcon, ClinicBuilding } from "@/components/PixelIcons";
import { useProfile } from "@/game/useProfile";
import { setMuted, primeAudio, SFX, isMuted } from "@/game/audio";
import { PLAYER_AVATARS } from "@/game/spriteData";

export default function StartScreen() {
  const nav = useNavigate();
  const { profile, loading, login, logout, settings, saveSettings } = useProfile();
  const [username, setUsername] = useState("");
  const [avatarId, setAvatarId] = useState(PLAYER_AVATARS[0].id);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setMuted(!settings.audioOn);
  }, [settings.audioOn]);

  const handlePlay = async () => {
    const trimmed = username.trim();
    if (trimmed.length < 2) {
      toast.error("Enter at least 2 characters as your Advocate name");
      return;
    }
    setSubmitting(true);
    try {
      await login({ username: trimmed, displayName: trimmed, avatarId });
      SFX.levelup();
      nav("/eras");
    } catch (e) {
      toast.error("Could not create profile. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleResume = () => {
    SFX.levelup();
    nav("/eras");
  };

  const toggleAudio = async () => {
    const next = !settings.audioOn;
    saveSettings({ audioOn: next });
    setMuted(!next);
    if (next) {
      await primeAudio();
      SFX.click();
    }
  };

  const selectedAvatar = PLAYER_AVATARS.find((a) => a.id === avatarId) || PLAYER_AVATARS[0];

  return (
    <div
      className="game-root tiles-sky flex flex-col relative"
      data-testid="start-screen"
    >
      {/* Pixel stars */}
      <div
        className="absolute inset-0 pixel-stars opacity-40 pointer-events-none"
        aria-hidden
      />
      {/* Ground */}
      <div className="absolute bottom-0 left-0 right-0 h-40 tiles-floor" aria-hidden />

      {/* Building silhouette */}
      <div
        className="absolute bottom-24 left-1/2 -translate-x-1/2 opacity-90 pointer-events-none hidden md:block"
        aria-hidden
      >
        <ClinicBuilding size={4} />
      </div>

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center gap-6 py-10 px-4">
        {/* Flag + Title */}
        <div className="flex items-center gap-4">
          <IndiaFlag size={4} testId="brand-flag" />
          <div className="text-left">
            <div className="font-heading text-[10px] md:text-xs text-[#2C1A0F] uppercase">
              Samvidhan Saga
            </div>
            <h1
              className="font-heading text-2xl md:text-4xl lg:text-5xl uppercase text-[#2C1A0F] leading-tight"
              style={{ textShadow: "3px 3px 0 #FFD700, 6px 6px 0 rgba(0,0,0,0.4)" }}
            >
              Adhikar Setu
            </h1>
            <div className="font-body text-xl md:text-2xl text-[#5C4033] mt-1">
              The Bridge of Rights
            </div>
          </div>
        </div>

        {/* Card */}
        <PixelFrame className="p-6 md:p-8 max-w-xl w-full" bg="#F5E6D3">
          <div className="mb-4">
            <div className="font-heading text-[10px] uppercase text-[#5C4033]">
              &gt; New Case File
            </div>
            <p className="font-body text-lg md:text-xl text-[#2C1A0F] mt-1 leading-snug">
              You run a Legal Aid clinic. Villagers walk in with troubles — some
              constitutional, some not. Read carefully. Advise wisely.
            </p>
          </div>

          {profile ? (
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4 p-3 border-[3px] border-[#2C1A0F] bg-[#FFF8E7]">
                <HumanoidSprite
                  palette={
                    (PLAYER_AVATARS.find((a) => a.id === profile.avatar_id) ||
                      PLAYER_AVATARS[0]).palette
                  }
                  accessories={
                    (PLAYER_AVATARS.find((a) => a.id === profile.avatar_id) ||
                      PLAYER_AVATARS[0]).accessories
                  }
                  size={4}
                />
                <div className="flex-1">
                  <div className="font-heading text-[10px] uppercase text-[#2C1A0F]">
                    Welcome Back
                  </div>
                  <div className="font-body text-2xl text-[#2C1A0F]">
                    Advocate {profile.display_name || profile.username}
                  </div>
                  <div className="font-body text-base text-[#5C4033]">
                    Day {profile.days_played + 1} • ₹{profile.cash} • {profile.badges.length} badges
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-3 justify-end">
                <RetroButton variant="neutral" size="sm" onClick={() => nav("/leaderboard")} testId="btn-leaderboard">
                  Leaderboard
                </RetroButton>
                <RetroButton variant="neutral" size="sm" onClick={() => nav("/profile")} testId="btn-profile">
                  Profile
                </RetroButton>
                <RetroButton variant="neutral" size="sm" onClick={() => nav("/settings")} testId="btn-settings">
                  Settings
                </RetroButton>
                <RetroButton variant="neutral" size="sm" onClick={() => { logout(); setUsername(""); }} testId="btn-switch-user">
                  Switch User
                </RetroButton>
                <RetroButton variant="yes" onClick={handleResume} testId="btn-play">
                  ▶ Start Day
                </RetroButton>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              <div>
                <label className="font-heading text-[10px] uppercase text-[#5C4033] block mb-2">
                  &gt; Advocate name
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handlePlay()}
                  placeholder="e.g. ambedkar_fan_2010"
                  maxLength={24}
                  className="w-full font-body text-xl md:text-2xl text-[#2C1A0F] bg-[#FFF8E7] border-[3px] border-[#2C1A0F] px-3 py-2 outline-none focus:bg-[#FFF3C4]"
                  data-testid="input-username"
                />
                <div className="font-body text-sm text-[#5C4033] mt-1">
                  Progress saves to this name. Come back anytime.
                </div>
              </div>

              <div>
                <label className="font-heading text-[10px] uppercase text-[#5C4033] block mb-2">
                  &gt; Choose your look
                </label>
                <div className="grid grid-cols-4 gap-3">
                  {PLAYER_AVATARS.map((av) => (
                    <button
                      key={av.id}
                      onClick={() => {
                        SFX.click();
                        setAvatarId(av.id);
                      }}
                      className={`border-[3px] p-2 flex items-center justify-center bg-[#FFF8E7] active:translate-y-[2px]`}
                      style={{
                        borderColor: av.id === avatarId ? "#F57C00" : "#2C1A0F",
                        boxShadow: av.id === avatarId
                          ? "4px 4px 0 0 rgba(245,124,0,0.6)"
                          : "3px 3px 0 0 rgba(0,0,0,0.35)",
                      }}
                      data-testid={`avatar-${av.id}`}
                      title={av.name}
                    >
                      <HumanoidSprite palette={av.palette} accessories={av.accessories} size={3} animation="idle" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap gap-3 items-center justify-end">
                <button
                  onClick={() => nav("/leaderboard")}
                  className="border-[3px] border-[#2C1A0F] px-3 py-2 bg-[#FFF8E7] font-heading text-[10px] uppercase active:translate-y-[2px]"
                  data-testid="btn-leaderboard-guest"
                >
                  Leaderboard
                </button>
                <button
                  onClick={toggleAudio}
                  className="border-[3px] border-[#2C1A0F] px-3 py-2 bg-[#FFF8E7] font-heading text-[10px] uppercase active:translate-y-[2px]"
                  data-testid="btn-audio-toggle"
                >
                  Sound: {settings.audioOn ? "ON ♪" : "OFF ✕"}
                </button>
                <RetroButton variant="yes" onClick={handlePlay} disabled={submitting} testId="btn-start-play">
                  {submitting ? "Loading..." : "▶ Enter Clinic"}
                </RetroButton>
              </div>
            </div>
          )}
        </PixelFrame>

        <div className="flex items-center gap-2 text-[#2C1A0F] font-body text-lg">
          <StarIcon size={2} />
          <span>Teach the Fundamental Rights. Save the Republic, one case at a time.</span>
        </div>
      </main>
    </div>
  );
}
