import React, { useEffect, useRef, useState, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import DialogueBox from "@/components/DialogueBox";
import RetroButton from "@/components/RetroButton";
import ArticleCard from "@/components/ArticleCard";
import { HumanoidSprite } from "@/components/PixelSprite";
import {
  ReputationMeter,
  CashMeter,
  TimerMeter,
  RoundBadge,
  ComboMeter,
  DailyChallengeBadge,
} from "@/components/RetroMeter";
import { getScenariosForRound } from "@/game/scenarios";
import { useProfile } from "@/game/useProfile";
import { SFX, setMuted } from "@/game/audio";
import { toast } from "sonner";

const ROUND_TIME = 75; // seconds per day
const CORRECT_CASH = 100;
const WRONG_CASH_PENALTY = 40;
const ADVOCATE_BONUS_CASH = 50;
const DAILY_CHALLENGE_BONUS = 200;

function comboMultiplier(combo) {
  if (combo >= 4) return 2.0;
  if (combo >= 3) return 1.5;
  if (combo >= 2) return 1.25;
  return 1.0;
}

export default function GameScreen() {
  const nav = useNavigate();
  const { profile, settings, loading } = useProfile();

  // Redirect if no profile
  useEffect(() => {
    if (!loading && !profile) nav("/");
  }, [loading, profile, nav]);

  useEffect(() => {
    setMuted(!settings.audioOn);
  }, [settings.audioOn]);

  const [scenarios] = useState(() =>
    getScenariosForRound({ includeAdvanced: settings.advancedMode, count: 6 })
  );
  // Pick a random scenario as today's Daily Challenge (extra bonus)
  const [dailyChallengeIdx] = useState(() => Math.floor(Math.random() * 6));
  const [idx, setIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(ROUND_TIME);
  const [reputation, setReputation] = useState(profile?.reputation ?? 3);
  const [maxRep] = useState(profile?.max_reputation ?? 5);
  const [dayCash, setDayCash] = useState(0);
  const [dayCorrect, setDayCorrect] = useState(0);
  const [dayWrong, setDayWrong] = useState(0);
  const [articles, setArticles] = useState([]);
  const [seen, setSeen] = useState([]);
  const [answerState, setAnswerState] = useState("idle"); // 'idle' | 'reveal' | 'transition'
  const [lastCorrect, setLastCorrect] = useState(false);
  const [cashPulse, setCashPulse] = useState(false);
  const [screenShake, setScreenShake] = useState(false);
  const [walkoutIdx, setWalkoutIdx] = useState(null);
  const [combo, setCombo] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [dailyChallengeWon, setDailyChallengeWon] = useState(false);
  const gameEndedRef = useRef(false);

  const current = scenarios[idx];
  const isDailyChallenge = idx === dailyChallengeIdx;

  // Round timer
  useEffect(() => {
    if (answerState === "reveal") return; // pause during reveal
    if (timeLeft <= 0) return;
    const t = setInterval(() => {
      setTimeLeft((s) => {
        if (s <= 1) {
          clearInterval(t);
          return 0;
        }
        if (s <= 11) SFX.tick();
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [answerState, timeLeft]);

  const endDay = useCallback(
    (finalReputation, finalCash, finalCorrect, finalWrong, finalArticles, finalSeen, finalBestCombo, finalDailyWon) => {
      if (gameEndedRef.current) return;
      gameEndedRef.current = true;
      const badgesEarned = [];
      if (finalCorrect >= 5) badgesEarned.push("Perfect Docket");
      if (finalArticles.includes("Article 32")) badgesEarned.push("Heart & Soul");
      if (finalArticles.includes("Article 21A")) badgesEarned.push("Child Champion");
      if (finalArticles.includes("Article 25")) badgesEarned.push("Faithful Advocate");
      if (finalArticles.includes("Article 14")) badgesEarned.push("Equality Warrior");
      if (finalCash >= 300) badgesEarned.push("Prosperous Clinic");
      if (finalWrong === 0 && finalCorrect > 0) badgesEarned.push("Flawless Advocate");
      if (finalBestCombo >= 4) badgesEarned.push("Combo King");
      if (finalDailyWon) badgesEarned.push("Daily Challenge Champion");

      const summary = {
        day_cash: finalCash,
        day_correct: finalCorrect,
        day_wrong: finalWrong,
        reputation: finalReputation,
        max_reputation: maxRep,
        articles_covered: finalArticles,
        scenarios_seen: finalSeen,
        badges_earned: badgesEarned,
        day_best_combo: finalBestCombo,
        daily_challenge_won: finalDailyWon,
      };
      sessionStorage.setItem("samvidhan.lastDay", JSON.stringify(summary));
      nav("/summary");
    },
    [maxRep, nav]
  );

  // Timeout ends day
  useEffect(() => {
    if (timeLeft === 0 && answerState !== "reveal") {
      endDay(reputation, dayCash, dayCorrect, dayWrong, articles, seen, bestCombo, dailyChallengeWon);
    }
  }, [timeLeft, answerState, reputation, dayCash, dayCorrect, dayWrong, articles, seen, bestCombo, dailyChallengeWon, endDay]);

  // Handle answer
  const handleAnswer = (answer) => {
    if (answerState !== "idle" || !current) return;
    const correct = answer === current.correct;
    setSeen((s) => (s.includes(current.id) ? s : [...s, current.id]));
    if (correct) {
      // combo bump
      setCombo((prev) => {
        const next = prev + 1;
        setBestCombo((bc) => Math.max(bc, next));
        const mult = comboMultiplier(next);
        const dailyBonus = isDailyChallenge ? DAILY_CHALLENGE_BONUS : 0;
        // earned = base × combo multiplier + flat daily-challenge bonus
        // (advocate-pick bonus ₹50 is added separately in handleArticleDone)
        const earned = Math.round(CORRECT_CASH * mult) + dailyBonus;
        setDayCash((c) => c + earned);
        if (isDailyChallenge) setDailyChallengeWon(true);
        if (mult > 1) {
          toast(`x${next} combo · ×${mult.toFixed(2)} · +₹${earned}`, { duration: 1300 });
        } else if (isDailyChallenge) {
          toast(`★ Daily Challenge won! +₹${earned}`, { duration: 1400 });
        }
        return next;
      });
      SFX.correct();
      SFX.coin();
      setLastCorrect(true);
      setDayCorrect((c) => c + 1);
      setCashPulse(true);
      setTimeout(() => setCashPulse(false), 400);
      if (current.article) {
        setArticles((a) => (a.includes(current.article) ? a : [...a, current.article]));
      }
    } else {
      SFX.wrong();
      setLastCorrect(false);
      setDayWrong((c) => c + 1);
      setDayCash((c) => Math.max(0, c - WRONG_CASH_PENALTY));
      setReputation((r) => Math.max(0, r - 1));
      setCombo(0); // wrong resets combo
      setScreenShake(true);
      setTimeout(() => setScreenShake(false), 400);
    }
    setAnswerState("reveal");
  };

  const handleArticleDone = ({ advocateBonus }) => {
    if (advocateBonus) {
      setDayCash((c) => c + ADVOCATE_BONUS_CASH);
      setCashPulse(true);
      setTimeout(() => setCashPulse(false), 400);
      toast(`+ ₹${ADVOCATE_BONUS_CASH} bonus for perfect advocate assignment!`, {
        duration: 1400,
      });
    }
    // walk out animation
    setWalkoutIdx(idx);
    setAnswerState("transition");
    setTimeout(() => {
      setWalkoutIdx(null);
      if (idx + 1 >= scenarios.length) {
        // finished all scenarios early — end day
        const nextArticles = articles;
        endDay(reputation, dayCash + (advocateBonus ? ADVOCATE_BONUS_CASH : 0), dayCorrect, dayWrong, nextArticles, seen);
        return;
      }
      // Also check reputation 0 => end day
      if (reputation <= 0) {
        endDay(0, dayCash + (advocateBonus ? ADVOCATE_BONUS_CASH : 0), dayCorrect, dayWrong, articles, seen);
        return;
      }
      setIdx((i) => i + 1);
      setAnswerState("idle");
    }, 650);
  };

  const currentAnimation = walkoutIdx === idx ? "walkout" : "walkin";

  if (loading || !profile || !current) {
    return (
      <div className="tiles-wall min-h-screen flex items-center justify-center">
        <div className="font-heading text-xs text-[#FFF8E7]">Loading...</div>
      </div>
    );
  }

  return (
    <div
      className={`game-root flex flex-col relative ${screenShake ? "screen-shake" : ""}`}
      data-testid="game-screen"
    >
      {/* Background environment: sky | wall | floor */}
      <div className="absolute inset-0 flex flex-col pointer-events-none" aria-hidden>
        <div className="h-[24%] tiles-sky" />
        <div className="h-[40%] tiles-wall relative">
          {/* Wall decorations: pixel scroll & clock frames */}
          <div className="absolute top-6 left-8 hidden md:block">
            <PixelFrame bg="#F5E6D3" className="w-32 h-20 flex items-center justify-center">
              <div className="font-heading text-[8px] text-[#5C4033]">CONSTITUTION</div>
            </PixelFrame>
          </div>
          <div className="absolute top-6 right-8 hidden md:block">
            <PixelFrame bg="#F5E6D3" className="w-24 h-24 flex items-center justify-center">
              <div className="font-heading text-[10px] text-[#5C4033] text-center leading-tight">
                LEGAL <br />AID
              </div>
            </PixelFrame>
          </div>
        </div>
        <div className="flex-1 tiles-floor" />
      </div>

      {/* HUD */}
      <div className="relative z-30 flex items-start justify-between p-3 md:p-5 gap-3">
        <div className="flex items-center gap-2 md:gap-3 flex-wrap">
          <RoundBadge round={(profile.days_played || 0) + 1} />
          <TimerMeter seconds={timeLeft} total={ROUND_TIME} />
          <ComboMeter combo={combo} multiplier={comboMultiplier(combo)} />
        </div>
        <div className="flex items-center gap-2 md:gap-3 flex-wrap justify-end">
          <ReputationMeter reputation={reputation} max={maxRep} />
          <CashMeter cash={dayCash} pulse={cashPulse} />
          <button
            onClick={() => {
              if (window.confirm("Leave day? Progress this day will be lost.")) nav("/");
            }}
            className="border-[3px] border-[#2C1A0F] px-2 py-1 bg-[#FFF8E7] font-heading text-[8px] uppercase active:translate-y-[2px]"
            data-testid="btn-quit-day"
          >
            ✕ Quit
          </button>
        </div>
      </div>

      {/* Scene stage */}
      <div className="relative z-10 flex-1 flex items-end justify-center pb-72 md:pb-64 px-4">
        {/* Desk */}
        <div
          className="absolute bottom-56 md:bottom-52 left-1/2 -translate-x-1/2 w-64 md:w-96 h-10 md:h-12"
          style={{
            background: "#8B5E3C",
            border: "4px solid #2C1A0F",
            boxShadow: "0 0 0 4px #5C4033, 6px 6px 0 0 rgba(0,0,0,0.4)",
          }}
          aria-hidden
        />
        {/* Client sprite */}
        <div
          key={`client-${idx}-${walkoutIdx}`}
          className="absolute bottom-64 md:bottom-60 flex flex-col items-center"
          data-testid="client-sprite"
        >
          <HumanoidSprite
            palette={current.palette}
            accessories={current.accessories}
            size={7}
            animation={currentAnimation}
          />
          <div className="mt-2 flex items-center gap-2">
            {isDailyChallenge && <DailyChallengeBadge />}
            <div
              className="px-2 py-1 border-[3px] border-[#2C1A0F] bg-[#FFF8E7] font-heading text-[9px] uppercase text-[#2C1A0F]"
              style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)" }}
            >
              {current.clientName}
            </div>
          </div>
        </div>
      </div>

      {/* Dialogue */}
      <div className="fixed left-0 right-0 bottom-3 md:bottom-4 z-20 px-3 md:px-6">
        <div className="max-w-4xl mx-auto">
          <DialogueBox
            scenario={current}
            actions={
              <>
                <RetroButton
                  variant="yes"
                  onClick={() => handleAnswer("yes")}
                  disabled={answerState !== "idle"}
                  testId="btn-yes"
                >
                  ✓ Haan, Adhikar Hai
                </RetroButton>
                <RetroButton
                  variant="no"
                  onClick={() => handleAnswer("no")}
                  disabled={answerState !== "idle"}
                  testId="btn-no"
                >
                  ✕ Nahi, Adhikar Nahi Hai
                </RetroButton>
              </>
            }
          />
        </div>
      </div>

      {/* Reveal overlay */}
      {answerState === "reveal" && (
        <ArticleCard
          scenario={current}
          playerAnswerCorrect={lastCorrect}
          onDone={handleArticleDone}
        />
      )}
    </div>
  );
}
