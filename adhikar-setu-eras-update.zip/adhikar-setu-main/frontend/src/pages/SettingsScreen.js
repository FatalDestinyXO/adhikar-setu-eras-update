import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import { useProfile } from "@/game/useProfile";
import { setMuted, SFX, primeAudio } from "@/game/audio";

export default function SettingsScreen() {
  const nav = useNavigate();
  const { profile, settings, saveSettings, loading } = useProfile();

  useEffect(() => {
    if (!loading && !profile) nav("/");
  }, [loading, profile, nav]);

  const toggle = async (key) => {
    const next = { ...settings, [key]: !settings[key] };
    saveSettings(next);
    if (key === "audioOn") {
      setMuted(!next.audioOn);
      if (next.audioOn) {
        await primeAudio();
        SFX.click();
      }
    } else {
      SFX.click();
    }
  };

  return (
    <div className="game-root min-h-screen tiles-wall flex items-center justify-center p-4" data-testid="settings-screen">
      <PixelFrame className="w-full max-w-2xl p-6 md:p-8" bg="#F5E6D3">
        <h2 className="font-heading text-sm md:text-lg uppercase text-[#2C1A0F] mb-4">
          &gt; Settings
        </h2>

        <div className="space-y-3">
          <SettingRow
            label="Sound Effects"
            help="8-bit blips, jingles and buzzes. Off by default."
            value={settings.audioOn}
            onToggle={() => toggle("audioOn")}
            testId="setting-audio"
          />
          <SettingRow
            label="Accessible Font"
            help="Swap the pixel body font for IBM Plex Sans if it's hard to read."
            value={settings.useAccessibleFont}
            onToggle={() => toggle("useAccessibleFont")}
            testId="setting-font"
          />
          <SettingRow
            label="Advanced Scenarios"
            help="Include tricky cases (like private employer bias) that teach nuance. Turn OFF for younger players."
            value={settings.advancedMode}
            onToggle={() => toggle("advancedMode")}
            testId="setting-advanced"
          />
          <SettingRow
            label="Answer Key (Teacher/Parent)"
            help="Enables the Answer Key screen — useful for classrooms."
            value={settings.showAnswerKey}
            onToggle={() => toggle("showAnswerKey")}
            testId="setting-answer-key"
          />
        </div>

        <div className="flex flex-wrap justify-end gap-3 mt-6">
          {settings.showAnswerKey && (
            <RetroButton variant="teal" onClick={() => nav("/answer-key")} testId="btn-open-answer-key">
              Open Answer Key
            </RetroButton>
          )}
          <RetroButton variant="neutral" size="sm" onClick={() => nav("/profile")} testId="btn-goto-profile">
            View Profile
          </RetroButton>
          <RetroButton variant="gold" onClick={() => nav("/")} testId="btn-settings-back">
            ◀ Back
          </RetroButton>
        </div>
      </PixelFrame>
    </div>
  );
}

function SettingRow({ label, help, value, onToggle, testId }) {
  return (
    <div
      className="flex items-center justify-between gap-3 border-[3px] border-[#2C1A0F] bg-[#FFF8E7] px-3 py-3"
      style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.3)" }}
      data-testid={testId}
    >
      <div className="min-w-0 flex-1">
        <div className="font-heading text-[10px] uppercase text-[#2C1A0F]">{label}</div>
        <div className="font-body text-base md:text-lg text-[#5C4033]">{help}</div>
      </div>
      <button
        onClick={onToggle}
        className={`border-[3px] border-[#2C1A0F] px-4 py-2 font-heading text-[9px] uppercase active:translate-y-[2px] ${
          value ? "bg-[#4CAF50] text-[#FFF8E7]" : "bg-[#EED9B4] text-[#2C1A0F]"
        }`}
        data-testid={`${testId}-btn`}
        aria-pressed={value}
      >
        {value ? "ON" : "OFF"}
      </button>
    </div>
  );
}
