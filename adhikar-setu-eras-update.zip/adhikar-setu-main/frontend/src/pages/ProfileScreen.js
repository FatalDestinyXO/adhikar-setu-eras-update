import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import { HumanoidSprite } from "@/components/PixelSprite";
import { HeartFullIcon, CoinIcon, BadgeIcon, ScrollIcon, StarIcon } from "@/components/PixelIcons";
import { useProfile } from "@/game/useProfile";
import { PLAYER_AVATARS } from "@/game/spriteData";
import { SCENARIOS } from "@/game/scenarios";

export default function ProfileScreen() {
  const nav = useNavigate();
  const { profile, loading, logout } = useProfile();

  useEffect(() => {
    if (!loading && !profile) nav("/");
  }, [loading, profile, nav]);

  if (!profile) return null;

  const avatar = PLAYER_AVATARS.find((a) => a.id === profile.avatar_id) || PLAYER_AVATARS[0];
  const totalArticles = 10; // count of distinct articles across scenarios
  const seenScenarios = SCENARIOS.filter((s) => profile.scenarios_seen.includes(s.id));

  return (
    <div className="game-root min-h-screen tiles-wall p-4" data-testid="profile-screen">
      <div className="max-w-5xl mx-auto py-6 space-y-4">
        <PixelFrame className="p-6 flex flex-col md:flex-row items-center gap-6" bg="#F5E6D3">
          <div className="shrink-0 self-center border-[3px] border-[#2C1A0F] p-3 bg-[#FFF8E7]" style={{ boxShadow: "4px 4px 0 0 rgba(0,0,0,0.35)" }}>
            <HumanoidSprite palette={avatar.palette} accessories={avatar.accessories} size={5} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-heading text-[10px] uppercase text-[#5C4033]">Player</div>
            <h2 className="font-heading text-base md:text-2xl uppercase text-[#2C1A0F] break-words">
              Advocate {profile.display_name || profile.username}
            </h2>
            <div className="font-body text-lg md:text-2xl text-[#2C1A0F] mt-1">
              {profile.days_played} days served
            </div>
            <div className="flex flex-wrap gap-3 mt-3">
              <MiniStat icon={<HeartFullIcon size={3} />} label="Rep" value={`${profile.reputation}/${profile.max_reputation}`} testId="mini-rep" />
              <MiniStat icon={<CoinIcon size={3} />} label="Cash" value={`₹${profile.cash}`} testId="mini-cash" />
              <MiniStat icon={<StarIcon size={3} />} label="Correct" value={profile.correct_count} testId="mini-correct" />
              <MiniStat icon={<StarIcon size={3} />} label="Best Combo" value={`x${profile.best_combo || 0}`} testId="mini-combo" />
              <MiniStat icon={<BadgeIcon size={2} color="#FFD700" />} label="Daily Wins" value={profile.daily_challenges_won || 0} testId="mini-daily" />
              <MiniStat icon={<ScrollIcon size={3} />} label="Articles" value={`${profile.completed_articles.length}/${totalArticles}`} testId="mini-articles" />
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <RetroButton size="sm" variant="neutral" onClick={() => nav("/settings")} testId="btn-profile-settings">Settings</RetroButton>
            <RetroButton size="sm" variant="no" onClick={() => { logout(); nav("/"); }} testId="btn-profile-logout">Sign Out</RetroButton>
            <RetroButton variant="yes" onClick={() => nav("/play")} testId="btn-profile-play">▶ Play</RetroButton>
          </div>
        </PixelFrame>

        <PixelFrame bg="#F5E6D3" className="p-5">
          <div className="font-heading text-[10px] uppercase text-[#5C4033] mb-3 flex items-center gap-2">
            <BadgeIcon size={2} /> Badges Earned ({profile.badges.length})
          </div>
          {profile.badges.length === 0 ? (
            <div className="font-body text-lg text-[#5C4033]">
              No badges yet. Win 5 cases in a single day for &lsquo;Perfect Docket&rsquo;.
            </div>
          ) : (
            <div className="flex flex-wrap gap-3">
              {profile.badges.map((b, i) => (
                <div
                  key={b}
                  className="flex items-center gap-2 border-[3px] border-[#2C1A0F] px-3 py-2 bg-[#FFF3C4]"
                  style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.3)" }}
                  data-testid={`profile-badge-${i}`}
                >
                  <BadgeIcon size={2} color={["#4CAF50","#F57C00","#673AB7","#009688","#F44336"][i % 5]} />
                  <span className="font-heading text-[9px] uppercase text-[#2C1A0F]">{b}</span>
                </div>
              ))}
            </div>
          )}
        </PixelFrame>

        <PixelFrame bg="#F5E6D3" className="p-5">
          <div className="font-heading text-[10px] uppercase text-[#5C4033] mb-3 flex items-center gap-2">
            <ScrollIcon size={2} /> Articles Unlocked
          </div>
          {profile.completed_articles.length === 0 ? (
            <div className="font-body text-lg text-[#5C4033]">
              Not yet — play a day to start unlocking Fundamental Rights.
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {profile.completed_articles.map((a) => (
                <span
                  key={a}
                  className="border-[3px] border-[#2C1A0F] bg-[#FFF3C4] px-3 py-1 font-heading text-[10px] uppercase"
                  data-testid={`profile-article-${a}`}
                >
                  {a}
                </span>
              ))}
            </div>
          )}
        </PixelFrame>

        <PixelFrame bg="#F5E6D3" className="p-5">
          <div className="font-heading text-[10px] uppercase text-[#5C4033] mb-3">
            &gt; Case Log
          </div>
          {seenScenarios.length === 0 ? (
            <div className="font-body text-lg text-[#5C4033]">No cases logged yet.</div>
          ) : (
            <ul className="space-y-2">
              {seenScenarios.map((s) => (
                <li
                  key={s.id}
                  className="border-l-4 border-[#F57C00] bg-[#FFF8E7] px-3 py-2"
                  data-testid={`profile-case-${s.id}`}
                >
                  <div className="font-heading text-[10px] uppercase text-[#2C1A0F]">
                    {s.clientName} — {s.article || "No Right"}
                  </div>
                  <div className="font-body text-base text-[#2C1A0F]">{s.oneLiner}</div>
                </li>
              ))}
            </ul>
          )}
        </PixelFrame>
      </div>
    </div>
  );
}

function MiniStat({ icon, label, value, testId }) {
  return (
    <div
      className="flex items-center gap-2 border-[3px] border-[#2C1A0F] px-3 py-1 bg-[#FFF8E7]"
      style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.3)" }}
      data-testid={testId}
    >
      {icon}
      <div>
        <div className="font-heading text-[8px] uppercase text-[#5C4033]">{label}</div>
        <div className="font-heading text-[10px] text-[#2C1A0F]">{value}</div>
      </div>
    </div>
  );
}
