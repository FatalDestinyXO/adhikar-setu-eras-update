import React, { useEffect, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import PixelFrame from "@/components/PixelFrame";
import RetroButton from "@/components/RetroButton";
import EraRevealCard from "@/components/EraRevealCard";
import { HumanoidSprite } from "@/components/PixelSprite";
import { ReputationMeter, CashMeter, TimerMeter, RoundBadge } from "@/components/RetroMeter";
import { getEraScenariosForRound, markEraCompleted, ERA_INFO, ERA_ORDER } from "@/game/eraEngine";
import { useProfile } from "@/game/useProfile";
import { SFX, setMuted } from "@/game/audio";
import { toast } from "sonner";

const ROUND_TIME = 75;
const CORRECT_CASH = 100;
const WRONG_CASH_PENALTY = 40;
const SCENARIOS_PER_ROUND = 6;

export default function EraScreen() {
  const nav = useNavigate();
  const { eraId } = useParams();
  const { profile, settings, loading } = useProfile();
  const info = ERA_INFO[eraId];

  useEffect(() => {
    if (!loading && !profile) nav("/");
  }, [loading, profile, nav]);

  useEffect(() => {
    setMuted(!settings.audioOn);
  }, [settings.audioOn]);

  const [scenarios] = useState(() => getEraScenariosForRound(eraId, SCENARIOS_PER_ROUND));
  const [idx, setIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(ROUND_TIME);
  const [reputation, setReputation] = useState(3);
  const [dayCash, setDayCash] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [answerState, setAnswerState] = useState("idle"); // idle | reveal
  const [chosenId, setChosenId] = useState(null);
  const [lastCorrect, setLastCorrect] = useState(false);
  const [walkoutIdx, setWalkoutIdx] = useState(null);
  const [screenShake, setScreenShake] = useState(false);
  const [cashPulse, setCashPulse] = useState(false);

  const current = scenarios[idx];

  useEffect(() => {
    if (answerState === "reveal") return;
    if (timeLeft <= 0) return;
    const t = setInterval(() => {
      setTimeLeft((s) => (s <= 1 ? 0 : s - 1));
    }, 1000);
    return () => clearInterval(t);
  }, [answerState, timeLeft]);

  const finishEra = useCallback(
    (finalCorrect) => {
      markEraCompleted(eraId);
      const nextIdx = ERA_ORDER.indexOf(eraId) + 1;
      const nextEra = ERA_ORDER[nextIdx];
      toast(
        `${info?.label} complete! ${finalCorrect}/${scenarios.length} correct.`,
        { duration: 2200 }
      );
      setTimeout(() => {
        if (nextEra) {
          nav("/eras", { state: { justCompleted: eraId, unlocked: nextEra } });
        } else {
          nav("/eras");
        }
      }, 600);
    },
    [eraId, info, nav, scenarios.length]
  );

  useEffect(() => {
    if (timeLeft === 0 && answerState !== "reveal") {
      finishEra(correctCount);
    }
  }, [timeLeft, answerState, correctCount, finishEra]);

  const handleChoice = (choiceId) => {
    if (answerState !== "idle" || !current) return;
    const correct = choiceId === current.correctChoice;
    setChosenId(choiceId);
    if (correct) {
      SFX.correct();
      SFX.coin();
      setLastCorrect(true);
      setCorrectCount((c) => c + 1);
      setDayCash((c) => c + CORRECT_CASH);
      setCashPulse(true);
      setTimeout(() => setCashPulse(false), 400);
    } else {
      SFX.wrong();
      setLastCorrect(false);
      setDayCash((c) => Math.max(0, c - WRONG_CASH_PENALTY));
      setReputation((r) => Math.max(0, r - 1));
      setScreenShake(true);
      setTimeout(() => setScreenShake(false), 400);
    }
    setAnswerState("reveal");
  };

  const handleRevealDone = () => {
    setWalkoutIdx(idx);
    setAnswerState("transition");
    setTimeout(() => {
      setWalkoutIdx(null);
      if (idx + 1 >= scenarios.length || reputation <= 0) {
        finishEra(correctCount);
        return;
      }
      setIdx((i) => i + 1);
      setAnswerState("idle");
      setChosenId(null);
    }, 650);
  };

  const currentAnimation = walkoutIdx === idx ? "walkout" : "walkin";

  if (loading || !profile || !current || !info) {
    return (
      <div className="tiles-wall min-h-screen flex items-center justify-center">
        <div className="font-heading text-xs text-[#FFF8E7]">Loading...</div>
      </div>
    );
  }

  return (
    <div
      className={`game-root flex flex-col relative ${screenShake ? "screen-shake" : ""}`}
      data-testid="era-screen"
    >
      <div className="absolute inset-0 flex flex-col pointer-events-none" aria-hidden>
        <div className="h-[24%] tiles-sky" />
        <div className="h-[40%] tiles-wall relative">
          <div className="absolute top-6 left-8 hidden md:block">
            <PixelFrame bg={info.bg} className="w-32 h-20 flex items-center justify-center">
              <div className="font-heading text-[8px] text-[#5C4033] text-center whitespace-pre-line">
                {info.wallLabel}
              </div>
            </PixelFrame>
          </div>
        </div>
        <div className="flex-1 tiles-floor" />
      </div>

      <div className="relative z-30 flex items-start justify-between p-3 md:p-5 gap-3">
        <div className="flex items-center gap-2 md:gap-3 flex-wrap">
          <RoundBadge round={idx + 1} />
          <TimerMeter seconds={timeLeft} total={ROUND_TIME} />
        </div>
        <div className="flex items-center gap-2 md:gap-3 flex-wrap justify-end">
          <ReputationMeter reputation={reputation} max={3} />
          <CashMeter cash={dayCash} pulse={cashPulse} />
          <button
            onClick={() => {
              if (window.confirm("Leave this era? Progress will be lost.")) nav("/eras");
            }}
            className="border-[3px] border-[#2C1A0F] px-2 py-1 bg-[#FFF8E7] font-heading text-[8px] uppercase active:translate-y-[2px]"
            data-testid="btn-quit-era"
          >
            ✕ Quit
          </button>
        </div>
      </div>

      <div className="relative z-20 text-center">
        <div className="inline-block px-3 py-1 border-[3px] border-[#2C1A0F] bg-[#FFF8E7] font-heading text-[9px] md:text-xs uppercase text-[#2C1A0F]">
          {info.label} — {current.article}
        </div>
      </div>

      <div className="relative z-10 flex-1 flex items-end justify-center pb-72 md:pb-64 px-4">
        <div
          className="absolute bottom-56 md:bottom-52 left-1/2 -translate-x-1/2 w-64 md:w-96 h-10 md:h-12"
          style={{
            background: "#8B5E3C",
            border: "4px solid #2C1A0F",
            boxShadow: "0 0 0 4px #5C4033, 6px 6px 0 0 rgba(0,0,0,0.4)",
          }}
          aria-hidden
        />
        <div
          key={`client-${idx}-${walkoutIdx}`}
          className="absolute bottom-64 md:bottom-60 flex flex-col items-center"
          data-testid="era-client-sprite"
        >
          <HumanoidSprite
            palette={current.palette}
            accessories={current.accessories}
            size={7}
            animation={currentAnimation}
          />
          <div className="mt-2 px-2 py-1 border-[3px] border-[#2C1A0F] bg-[#FFF8E7] font-heading text-[9px] uppercase text-[#2C1A0F]"
               style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)" }}>
            {current.clientName}
          </div>
        </div>
      </div>

      <div className="fixed left-0 right-0 bottom-3 md:bottom-4 z-20 px-3 md:px-6">
        <div className="max-w-4xl mx-auto">
          <PixelFrame className="p-4 md:p-6" bg="#F5E6D3">
            <div className="font-heading text-[10px] md:text-xs text-[#2C1A0F] uppercase mb-2">
              {current.clientName}
              <span className="opacity-60"> — {current.clientRole}</span>
            </div>
            <div className="font-body text-lg md:text-2xl text-[#2C1A0F] leading-snug mb-4">
              &ldquo;{current.sceneText}&rdquo;
            </div>
            <div className="flex flex-col gap-3">
              {current.choices.map((choice) => (
                <RetroButton
                  key={choice.id}
                  variant="neutral"
                  onClick={() => handleChoice(choice.id)}
                  disabled={answerState !== "idle"}
                  testId={`btn-choice-${choice.id}`}
                  className="text-left"
                >
                  {choice.text}
                </RetroButton>
              ))}
            </div>
          </PixelFrame>
        </div>
      </div>

      {answerState === "reveal" && (
        <EraRevealCard
          scenario={current}
          chosenId={chosenId}
          wasCorrect={lastCorrect}
          onDone={handleRevealDone}
        />
      )}
    </div>
  );
}
