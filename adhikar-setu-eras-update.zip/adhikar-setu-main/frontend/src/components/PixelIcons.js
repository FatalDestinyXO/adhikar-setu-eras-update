import React from "react";
import { PixelMap } from "@/components/PixelSprite";

// -------- Pixel-art icons (inline SVG rect grids) --------

const HEART_ROWS = [
  ".rr..rr.",
  "rrrrrrrr",
  "rrrrrrrr",
  "rrrrrrrr",
  ".rrrrrr.",
  "..rrrr..",
  "...rr...",
];

const HEART_EMPTY_ROWS = [
  ".kk..kk.",
  "k..kk..k",
  "k......k",
  ".k....k.",
  "..k..k..",
  "...kk...",
  "........",
];

const COIN_ROWS = [
  "..kkkkkk..",
  ".kaaaaaak.",
  "kaayyyyaak",
  "kayyyyyyak",
  "kayyyyyyak",
  "kayyyyyyak",
  "kaayyyyaak",
  ".kaaaaaak.",
  "..kkkkkk..",
];

const CLOCK_ROWS = [
  "..kkkkkk..",
  ".kaaaaaak.",
  "kaawwwaaak",
  "kaawaaaaak",
  "kaawwwaaak",
  "kaaaaaaaak",
  "kaaaaaaaak",
  ".kaaaaaak.",
  "..kkkkkk..",
];

const BOOK_ROWS = [
  "kkkkkkkkkk",
  "kbbbbbbbbk",
  "kbwwwwwwbk",
  "kbwkkkkwbk",
  "kbwwwwwwbk",
  "kbwkkkkwbk",
  "kbwwwwwwbk",
  "kbbbbbbbbk",
  "kkkkkkkkkk",
];

const SCROLL_ROWS = [
  "..kkkkkkkkkkkk..",
  ".kaaaaaaaaaaaak.",
  "kaakkkkkkkkkkaak",
  "kakaaaaaaaaaakak",
  "kakkkkkkkkkkakak",
  "kakaaaaaaaaaakak",
  "kakkkkkkkkkkakak",
  "kakaaaaaaaaaakak",
  "kaakkkkkkkkkkaak",
  ".kaaaaaaaaaaaak.",
  "..kkkkkkkkkkkk..",
];

const STAR_ROWS = [
  "....kk....",
  "...kaak...",
  "...kaak...",
  "kkkkaakkkk",
  "kaaaaaaaak",
  ".kaaaaaak.",
  "..kaaaak..",
  ".kaakaak.",
  "kk......kk",
];

const BADGE_ROWS = [
  "..kkkkkkk..",
  ".kaaaaaaak.",
  "kaakkkkkaak",
  "kakaaaaakak",
  "kakayyyakak",
  "kakayyyakak",
  "kakaaaaakak",
  "kaakkkkkaak",
  ".kkaaaaakk.",
  "..k..k..k..",
];

export function HeartFullIcon({ size = 3, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={HEART_ROWS}
        palette={{ r: "#E91E63", k: "#2C1A0F" }}
        pixelSize={size}
      />
    </div>
  );
}

export function HeartEmptyIcon({ size = 3, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={HEART_EMPTY_ROWS}
        palette={{ k: "#2C1A0F" }}
        pixelSize={size}
      />
    </div>
  );
}

export function CoinIcon({ size = 3, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={COIN_ROWS}
        palette={{
          k: "#2C1A0F",
          a: "#C7A600",
          y: "#FFD700",
        }}
        pixelSize={size}
      />
    </div>
  );
}

export function ClockIcon({ size = 3, urgent = false, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={CLOCK_ROWS}
        palette={{
          k: "#2C1A0F",
          a: urgent ? "#F44336" : "#FFD700",
          w: "#FFF8E7",
        }}
        pixelSize={size}
      />
    </div>
  );
}

export function BookIcon({ size = 3, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={BOOK_ROWS}
        palette={{ k: "#2C1A0F", b: "#8B4513", w: "#F5E6D3" }}
        pixelSize={size}
      />
    </div>
  );
}

export function ScrollIcon({ size = 4, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={SCROLL_ROWS}
        palette={{ k: "#5C4033", a: "#F5E6D3" }}
        pixelSize={size}
      />
    </div>
  );
}

export function StarIcon({ size = 3, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={STAR_ROWS}
        palette={{ k: "#2C1A0F", a: "#FFD700" }}
        pixelSize={size}
      />
    </div>
  );
}

export function BadgeIcon({ size = 3, testId, color = "#4CAF50" }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={BADGE_ROWS}
        palette={{ k: "#2C1A0F", a: color, y: "#FFD700" }}
        pixelSize={size}
      />
    </div>
  );
}

// Simple building — Legal Aid clinic exterior (larger sprite, for start screen)
const BUILDING_ROWS = [
  "................kkkkkkkkkkkk................",
  "..............kkyyyyyyyyyyyykk..............",
  "............kkyyyyyyyyyyyyyyyykk............",
  "..........kkyyyyyyyyyyyyyyyyyyyykk..........",
  "........kkyyyyyyyyyyyyyyyyyyyyyyyykk........",
  "......kkyyyyyyyyyyyyyyyyyyyyyyyyyyyykk......",
  "....kkyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyykk....",
  "..kkyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyykk..",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kwwwwwwwwwwwwkwwkkkkkkkkkkkkkkwwkwwwwwwwwwwk",
  "kwbbbbbwwwwwwkwkbbbbbbbbbbbbkwkwwwwwwbbbbbwk",
  "kwbggbbwwwwwwkwkbggggggggggbkwkwwwwwwbggbbwk",
  "kwbggbbwwwwwwkwkbggggggggggbkwkwwwwwwbggbbwk",
  "kwbbbbbwwwwwwkwkbggggggggggbkwkwwwwwwbbbbbwk",
  "kwwwwwwwwwwwwkwkbbbbbbbbbbbbkwkwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwkwkkkkkkkkkkkkkkwkwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwkwwwwwwwwwwwwwwwwkwwwwwwwwwwwwk",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "ffffffffffffffffffffffffffffffffffffffffffff",
  "ffffffffffffffffffffffffffffffffffffffffffff",
];

export function ClinicBuilding({ size = 6, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={BUILDING_ROWS}
        palette={{
          ".": "transparent",
          k: "#2C1A0F",
          y: "#E8A87C",   // roof
          w: "#F5E6D3",   // wall
          b: "#5C4033",   // window frame
          g: "#87CEEB",   // window glass
          f: "#A65C47",   // ground
        }}
        pixelSize={size}
      />
    </div>
  );
}

// Small pixel-art "flag" of India (14x9)
const FLAG_ROWS = [
  "kkkkkkkkkkkkkk",
  "koooooooooooo k".replace(" ", ""),
  "koooooooooooo k".replace(" ", ""),
  "kwwwwwwwwwwww k".replace(" ", ""),
  "kwwwwbbwwwwwwk",
  "kwwwwwwwwwwwwk",
  "kggggggggggggk",
  "kggggggggggggk",
  "kkkkkkkkkkkkkk",
];

export function IndiaFlag({ size = 4, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={FLAG_ROWS}
        palette={{
          k: "#2C1A0F",
          o: "#FF9933",
          w: "#FFFFFF",
          b: "#1E3A8A",
          g: "#138808",
        }}
        pixelSize={size}
      />
    </div>
  );
}

// Gavel icon for advocate
const GAVEL_ROWS = [
  "..kkkkkkkkk...",
  ".kbbbbbbbbbk..",
  "kbwwwwwwwwwbk.",
  "kbwwwwwwwwwbk.",
  ".kbbbbbbbbbk..",
  "....kbbbk.....",
  "....kbbbk.....",
  "....kbbbk.....",
  "..kkbbbbbkk...",
  "kkwwwwwwwwwwk.",
  "kkkkkkkkkkkkk.",
];

export function GavelIcon({ size = 3, testId }) {
  return (
    <div data-testid={testId}>
      <PixelMap
        rows={GAVEL_ROWS}
        palette={{ k: "#2C1A0F", b: "#8B4513", w: "#D4A574" }}
        pixelSize={size}
      />
    </div>
  );
}
