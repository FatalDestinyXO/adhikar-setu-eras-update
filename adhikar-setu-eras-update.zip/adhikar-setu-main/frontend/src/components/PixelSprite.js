import React from "react";
import { HUMANOID_ROWS, ACCESSORIES } from "@/game/spriteData";

// -------- Core pixel sprite renderer --------
// rows: array of strings, palette: {char: color}
export function PixelMap({ rows, palette, pixelSize = 6, className = "" }) {
  if (!rows || !rows.length) return null;
  const width = rows[0].length;
  const height = rows.length;
  const rects = [];
  for (let y = 0; y < height; y++) {
    const row = rows[y];
    for (let x = 0; x < width; x++) {
      const ch = row[x];
      if (!ch || ch === ".") continue;
      const color = palette[ch];
      if (!color || color === "transparent") continue;
      rects.push(
        <rect key={`${x}-${y}-${ch}`} x={x} y={y} width={1} height={1} fill={color} />
      );
    }
  }
  return (
    <svg
      className={className}
      width={width * pixelSize}
      height={height * pixelSize}
      viewBox={`0 0 ${width} ${height}`}
      shapeRendering="crispEdges"
      style={{ display: "block", imageRendering: "pixelated" }}
    >
      {rects}
    </svg>
  );
}

// -------- Humanoid character (client / advocate / player) --------
export function HumanoidSprite({
  palette,
  accessories = [],
  size = 6,
  animation = "idle", // 'idle' | 'walkin' | 'walkout' | 'none'
  facing = "front",
  className = "",
  testId,
}) {
  const p = {
    ".": "transparent",
    k: "#2C1A0F",
    h: palette.hair || "#3D2817",
    s: palette.skin || "#EFCDB0",
    e: "#1a1a1a",
    m: "#8B1E1E",
    S: palette.shirt || "#4CAF50",
    P: palette.pants || "#2C1A0F",
    B: palette.shoes || "#1a1a1a",
  };

  const width = HUMANOID_ROWS[0].length;
  const height = HUMANOID_ROWS.length;

  // Build final grid pixel layers (base + accessories)
  const layers = [
    { rows: HUMANOID_ROWS, palette: p, dy: 0, dx: 0 },
  ];
  accessories.forEach((accId) => {
    const acc = ACCESSORIES[accId];
    if (!acc || !acc.rows.length) return;
    // Replace 'A' or 'B' placeholders using accessory palette
    const accPalette = { ...acc.palette };
    // longHair: A means hair color (special)
    if (accId === "longHair") accPalette.A = palette.hair || "#3D2817";
    layers.push({ rows: acc.rows, palette: { ".": "transparent", ...accPalette }, dy: acc.dy, dx: 0 });
  });

  const rects = [];
  layers.forEach((layer, li) => {
    layer.rows.forEach((row, y) => {
      for (let x = 0; x < row.length; x++) {
        const ch = row[x];
        if (!ch || ch === ".") continue;
        const color = layer.palette[ch];
        if (!color || color === "transparent") continue;
        rects.push(
          <rect
            key={`${li}-${x}-${y}`}
            x={x + layer.dx}
            y={y + layer.dy}
            width={1}
            height={1}
            fill={color}
          />
        );
      }
    });
  });

  const animClass =
    animation === "idle"
      ? "sprite-idle"
      : animation === "walkin"
      ? "sprite-walkin"
      : animation === "walkout"
      ? "sprite-walkout"
      : "";

  const scaleX = facing === "left" ? -1 : 1;

  return (
    <div className={`${animClass} ${className}`} data-testid={testId}>
      <svg
        width={width * size}
        height={height * size}
        viewBox={`0 0 ${width} ${height}`}
        shapeRendering="crispEdges"
        style={{
          display: "block",
          imageRendering: "pixelated",
          transform: `scaleX(${scaleX})`,
        }}
      >
        {rects}
      </svg>
    </div>
  );
}
