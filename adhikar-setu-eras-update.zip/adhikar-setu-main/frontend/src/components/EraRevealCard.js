import React, { useEffect, useState } from "react";
import PixelFrame from "@/components/PixelFrame";
import { ScrollIcon } from "@/components/PixelIcons";
import RetroButton from "@/components/RetroButton";
import { SFX } from "@/game/audio";

// Reveal overlay for era (Ancient/Medieval/Colonial) scenarios.
// Unlike ArticleCard (yes/no + advocate pick), this shows which of the
// two historical choices was correct, why, and how it connects to the
// modern Fundamental Right that (eventually) fixed it.
export default function EraRevealCard({ scenario, chosenId, wasCorrect, onDone }) {
  const [stampShown, setStampShown] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => {
      SFX.stamp();
      setStampShown(true);
    }, 400);
    return () => clearTimeout(t);
  }, []);

  const correctChoice = scenario.choices.find((c) => c.id === scenario.correctChoice);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70"
      data-testid="era-reveal-overlay"
    >
      <div className="w-full max-w-3xl relative">
        {stampShown && (
          <div
            className="absolute -top-8 md:-top-10 -right-4 md:right-4 z-10"
            style={{ transform: "rotate(-14deg)" }}
            data-testid="era-stamp"
          >
            <div
              className="stamp-thud font-heading text-lg md:text-3xl px-4 py-3 border-4"
              style={{
                borderColor: wasCorrect ? "#2E7D32" : "#8E0E3B",
                color: wasCorrect ? "#2E7D32" : "#8E0E3B",
                background: wasCorrect ? "#E6FFE1" : "#FFE1E1",
                boxShadow: "6px 6px 0 0 rgba(0,0,0,0.5)",
              }}
            >
              {wasCorrect ? "Sahi!" : "Galat!"}
            </div>
          </div>
        )}

        <PixelFrame bg="#FFF8E7" className="card-unfurl p-5 md:p-8">
          <div className="flex items-center gap-3 mb-4">
            <ScrollIcon size={4} />
            <h2 className="font-heading text-sm md:text-lg text-[#2C1A0F] uppercase">
              {scenario.title || scenario.articleTitle}
            </h2>
          </div>

          <div className="mb-4">
            <div className="font-heading text-[10px] md:text-xs text-[#5C4033] uppercase mb-2">
              What actually happened
            </div>
            <p className="font-body text-lg md:text-2xl text-[#2C1A0F] leading-snug">
              {correctChoice?.text}
            </p>
          </div>

          <div className="mt-2 mb-4 px-3 py-2 border-l-4 border-[#F57C00] bg-[#FFF3E0]">
            <div className="font-heading text-[8px] md:text-[10px] uppercase text-[#F57C00] mb-1">
              Why
            </div>
            <div className="font-body text-base md:text-xl text-[#2C1A0F]">
              {scenario.explanation}
            </div>
          </div>

          {scenario.historicalNote && (
            <div className="mb-4 px-3 py-2 border-l-4 border-[#5C4033] bg-[#F5E6D3]">
              <div className="font-heading text-[8px] md:text-[10px] uppercase text-[#5C4033] mb-1">
                Then vs Now
              </div>
              <div className="font-body text-sm md:text-base text-[#2C1A0F]">
                {scenario.historicalNote}
              </div>
            </div>
          )}

          {scenario.article && (
            <div className="mb-4 px-3 py-2 border-2 border-[#2C1A0F] bg-[#E6FFE1]">
              <div className="font-body text-sm md:text-base text-[#2C1A0F]">
                Today, this is protected under <b>{scenario.article}</b>
                {scenario.articleTitle ? ` — ${scenario.articleTitle}` : ""}.
              </div>
            </div>
          )}

          <div className="flex justify-end mt-4">
            <RetroButton variant="gold" onClick={onDone} testId="btn-era-continue">
              Continue ▸
            </RetroButton>
          </div>
        </PixelFrame>
      </div>
    </div>
  );
}
