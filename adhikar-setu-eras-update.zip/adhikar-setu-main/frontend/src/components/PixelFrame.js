import React from "react";

// Reusable thick pixel frame container
export default function PixelFrame({
  children,
  className = "",
  bg = "#F5E6D3",
  border = "#2C1A0F",
  frame = "#5C4033",
  shadow = true,
  testId,
}) {
  const style = {
    background: bg,
    border: `4px solid ${border}`,
    boxShadow: `0 0 0 4px ${frame}${shadow ? ", 8px 8px 0 0 rgba(0,0,0,0.5)" : ""}`,
    imageRendering: "pixelated",
  };
  return (
    <div className={className} style={style} data-testid={testId}>
      {children}
    </div>
  );
}
