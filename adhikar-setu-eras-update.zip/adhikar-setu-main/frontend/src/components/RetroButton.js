import React from "react";
import { SFX } from "@/game/audio";

// -------- Retro pixel-styled button --------
// variant: 'yes' | 'no' | 'neutral' | 'gold' | 'teal'
export default function RetroButton({
  children,
  onClick,
  variant = "neutral",
  disabled = false,
  className = "",
  size = "md",
  testId,
  type = "button",
  soundOnClick = true,
}) {
  const cls = `retro-btn retro-btn-${variant}`;
  const sizeCls =
    size === "lg"
      ? "text-sm md:text-base px-8 py-4"
      : size === "sm"
      ? "text-[10px] px-3 py-2"
      : "text-xs md:text-sm px-5 py-3";

  const handleClick = (e) => {
    if (disabled) return;
    if (soundOnClick) SFX.click();
    if (onClick) onClick(e);
  };

  return (
    <button
      type={type}
      onClick={handleClick}
      disabled={disabled}
      className={`${cls} ${sizeCls} ${className}`}
      data-testid={testId}
    >
      {children}
    </button>
  );
}
