import React from "react";
import { HeartFullIcon, HeartEmptyIcon, CoinIcon, ClockIcon } from "@/components/PixelIcons";

// -------- HUD meters --------

export function ReputationMeter({ reputation, max = 5, testId = "reputation-meter" }) {
  const hearts = [];
  for (let i = 0; i < max; i++) {
    hearts.push(
      i < reputation ? (
        <HeartFullIcon key={i} size={3} />
      ) : (
        <HeartEmptyIcon key={i} size={3} />
      )
    );
  }
  return (
    <div
      className="flex items-center gap-1 px-2 py-1 border-[3px] border-[#2C1A0F] bg-[#FFF8E7]"
      style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)" }}
      data-testid={testId}
    >
      <div
        className="font-heading text-[8px] text-[#2C1A0F] mr-1 uppercase hidden sm:block"
      >
        Rep
      </div>
      <div className="flex items-center gap-[2px]">{hearts}</div>
    </div>
  );
}

export function CashMeter({ cash, testId = "cash-meter", pulse = false }) {
  return (
    <div
      className={`flex items-center gap-2 px-2 py-1 border-[3px] border-[#2C1A0F] bg-[#FFF8E7] ${
        pulse ? "tick-pop" : ""
      }`}
      style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)" }}
      data-testid={testId}
    >
      <CoinIcon size={3} />
      <span className="font-heading text-[10px] md:text-xs text-[#2C1A0F]">
        ₹{cash}
      </span>
    </div>
  );
}

export function TimerMeter({ seconds, total, testId = "timer-meter" }) {
  const pct = Math.max(0, Math.min(1, seconds / total));
  const urgent = seconds <= 10;
  return (
    <div
      className="flex items-center gap-2 px-2 py-1 border-[3px] border-[#2C1A0F] bg-[#FFF8E7]"
      style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)" }}
      data-testid={testId}
    >
      <ClockIcon size={3} urgent={urgent} />
      <div className="flex flex-col">
        <span className="font-heading text-[10px] md:text-xs text-[#2C1A0F]">
          {seconds}s
        </span>
        <div className="w-16 md:w-24 h-2 border border-[#2C1A0F] bg-[#EED9B4] mt-1">
          <div
            className={`h-full ${urgent ? "timer-warn" : ""}`}
            style={{
              width: `${pct * 100}%`,
              background: urgent ? "#F44336" : "#4CAF50",
              transition: "width 0.2s linear",
            }}
          />
        </div>
      </div>
    </div>
  );
}

export function RoundBadge({ round, testId = "round-badge" }) {
  return (
    <div
      className="px-3 py-1 border-[3px] border-[#2C1A0F] bg-[#673AB7] text-[#FFF8E7] font-heading text-[10px] md:text-xs"
      style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)" }}
      data-testid={testId}
    >
      Day {round}
    </div>
  );
}

// Combo counter — glows on x2+ tiers
export function ComboMeter({ combo, multiplier, testId = "combo-meter" }) {
  if (combo < 2) return null;
  const tier =
    multiplier >= 2.0 ? "MEGA" : multiplier >= 1.5 ? "SUPER" : "COMBO";
  const bg =
    multiplier >= 2.0
      ? "#F44336"
      : multiplier >= 1.5
      ? "#F57C00"
      : "#4CAF50";
  return (
    <div
      key={combo}
      className="tick-pop px-3 py-1 border-[3px] border-[#2C1A0F] font-heading text-[10px] md:text-xs text-[#FFF8E7]"
      style={{
        background: bg,
        boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)",
        textShadow: "2px 2px 0 rgba(0,0,0,0.55)",
      }}
      data-testid={testId}
    >
      x{combo} {tier} ×{multiplier.toFixed(2)}
    </div>
  );
}

// Daily challenge banner — small star badge for the flagged case
export function DailyChallengeBadge({ testId = "daily-challenge-badge" }) {
  return (
    <div
      className="px-2 py-1 border-[3px] border-[#2C1A0F] bg-[#FFD700] text-[#2C1A0F] font-heading text-[8px] md:text-[10px]"
      style={{ boxShadow: "3px 3px 0 0 rgba(0,0,0,0.4)" }}
      data-testid={testId}
    >
      ★ DAILY CHALLENGE
    </div>
  );
}
