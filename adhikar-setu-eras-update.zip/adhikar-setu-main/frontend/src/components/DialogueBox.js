import React, { useEffect, useRef, useState } from "react";
import PixelFrame from "@/components/PixelFrame";
import { HumanoidSprite } from "@/components/PixelSprite";
import { BookIcon } from "@/components/PixelIcons";
import RetroButton from "@/components/RetroButton";
import { SFX } from "@/game/audio";
import { useProfile } from "@/game/useProfile";

// RPG-style bottom dialogue box with portrait + typewriter text + Learn More toggle
export default function DialogueBox({
  scenario,
  onProceed,
  actions,
  testId = "dialogue-box",
}) {
  const [showFull, setShowFull] = useState(false);
  const [typed, setTyped] = useState("");
  const [done, setDone] = useState(false);
  const { settings } = useProfile();

  const targetText = showFull ? scenario.fullText : scenario.shortText;
  const textIndexRef = useRef(0);
  const timerRef = useRef(null);

  // Typewriter effect
  useEffect(() => {
    textIndexRef.current = 0;
    setTyped("");
    setDone(false);
    if (timerRef.current) clearInterval(timerRef.current);
    let blipCounter = 0;
    timerRef.current = setInterval(() => {
      const i = textIndexRef.current;
      if (i >= targetText.length) {
        clearInterval(timerRef.current);
        setDone(true);
        return;
      }
      textIndexRef.current = i + 1;
      setTyped(targetText.slice(0, i + 1));
      blipCounter++;
      if (blipCounter % 3 === 0) SFX.textBlip();
    }, 22);
    return () => clearInterval(timerRef.current);
  }, [targetText]);

  const skipTypewriter = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setTyped(targetText);
    setDone(true);
  };

  const bodyFont = settings.useAccessibleFont ? "font-access" : "font-body";
  const bodySize = settings.useAccessibleFont
    ? "text-base md:text-lg"
    : "text-xl md:text-2xl";

  return (
    <div className="w-full" data-testid={testId}>
      <PixelFrame className="p-4 md:p-6" bg="#F5E6D3">
        <div className="flex flex-col md:flex-row gap-4 md:gap-6">
          {/* Portrait */}
          <div
            className="shrink-0 self-center md:self-start"
            style={{
              width: "88px",
              height: "auto",
              border: "3px solid #2C1A0F",
              boxShadow: "4px 4px 0 0 rgba(0,0,0,0.35)",
              background: "#FFF8E7",
              padding: "6px",
            }}
            data-testid="dialogue-portrait"
          >
            <div className="flex items-end justify-center" style={{ height: "104px" }}>
              <HumanoidSprite
                palette={scenario.palette}
                accessories={scenario.accessories || []}
                size={4}
                animation="idle"
              />
            </div>
          </div>

          {/* Text */}
          <div className="flex-1 min-w-0 flex flex-col">
            <div className="flex items-center justify-between gap-3 mb-2">
              <div className="font-heading text-[10px] md:text-xs text-[#2C1A0F] uppercase">
                {scenario.clientName}
                <span className="opacity-60"> — {scenario.clientRole}</span>
              </div>
              <button
                onClick={() => {
                  SFX.click();
                  setShowFull((v) => !v);
                }}
                className="flex items-center gap-2 border-2 border-[#2C1A0F] px-2 py-1 bg-[#FFF8E7] hover:bg-[#FFE8A6] active:translate-y-[2px]"
                data-testid="btn-learn-more"
                title={showFull ? "Show simple version" : "Show full legal framing"}
              >
                <BookIcon size={2} />
                <span className="font-heading text-[8px] md:text-[10px]">
                  {showFull ? "Simple" : "Learn More"}
                </span>
              </button>
            </div>

            <div
              onClick={skipTypewriter}
              className={`${bodyFont} ${bodySize} text-[#2C1A0F] leading-snug whitespace-pre-wrap min-h-[80px] md:min-h-[96px] cursor-pointer`}
              data-testid="dialogue-text"
            >
              &ldquo;{typed}
              {!done && <span className="opacity-70">▌</span>}&rdquo;
            </div>

            {done && (
              <div className="mt-4 flex flex-wrap gap-3 md:justify-end text-appear">
                {actions ? (
                  actions
                ) : (
                  <RetroButton variant="gold" onClick={onProceed} testId="btn-dialogue-next">
                    Next ▸
                  </RetroButton>
                )}
              </div>
            )}
          </div>
        </div>
      </PixelFrame>
    </div>
  );
}
