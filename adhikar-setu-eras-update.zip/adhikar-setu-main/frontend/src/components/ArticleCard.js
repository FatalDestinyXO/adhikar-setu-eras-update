import React, { useEffect, useState } from "react";
import PixelFrame from "@/components/PixelFrame";
import { HumanoidSprite } from "@/components/PixelSprite";
import { ScrollIcon, GavelIcon } from "@/components/PixelIcons";
import RetroButton from "@/components/RetroButton";
import { SFX } from "@/game/audio";
import { ADVOCATES, getAdvocateById } from "@/game/advocates";

// Article scroll reveal + Advocate selection
// If scenario.correct === 'no', shows "Adhikar Nahi Hai" stamp + no advocate needed
// Else shows article scroll + player must click the correct advocate to win the case
export default function ArticleCard({
  scenario,
  playerAnswerCorrect,
  onDone,
}) {
  const [stampShown, setStampShown] = useState(false);
  const [pickedAdvocateId, setPickedAdvocateId] = useState(null);
  const [pickError, setPickError] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => {
      SFX.stamp();
      setStampShown(true);
    }, 400);
    return () => clearTimeout(t);
  }, []);

  const isWrong = !playerAnswerCorrect;
  const hasRight = scenario.correct === "yes";

  // If the player was wrong, we show the correct answer + explanation, then Continue.
  // If the player was right AND there is no right (correct === 'no'), skip advocate pick.
  const needsAdvocatePick = playerAnswerCorrect && hasRight;

  const handlePick = (advocateId) => {
    if (advocateId === scenario.advocateId) {
      SFX.correct();
      setPickedAdvocateId(advocateId);
      setTimeout(() => onDone({ advocateBonus: true }), 900);
    } else {
      SFX.wrong();
      setPickError(advocateId);
      setTimeout(() => setPickError(null), 700);
    }
  };

  const correctAdvocate = getAdvocateById(scenario.advocateId);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70"
      data-testid="article-card-overlay"
    >
      <div className="w-full max-w-3xl relative">
        {/* Big stamp */}
        {stampShown && (
          <div
            className="absolute -top-8 md:-top-10 -right-4 md:right-4 z-10"
            style={{ transform: "rotate(-14deg)" }}
            data-testid="stamp"
          >
            <div
              className="stamp-thud font-heading text-lg md:text-3xl px-4 py-3 border-4"
              style={{
                borderColor: isWrong ? "#8E0E3B" : "#2E7D32",
                color: isWrong ? "#8E0E3B" : "#2E7D32",
                background: isWrong ? "#FFE1E1" : "#E6FFE1",
                boxShadow: "6px 6px 0 0 rgba(0,0,0,0.5)",
              }}
            >
              {isWrong
                ? "Galat!"
                : hasRight
                ? "Adhikar Hai!"
                : "Sahi Faisla!"}
            </div>
          </div>
        )}

        <PixelFrame bg={hasRight ? "#FFF8E7" : "#F5E6D3"} className="card-unfurl p-5 md:p-8">
          <div className="flex items-center gap-3 mb-4">
            <ScrollIcon size={4} />
            <h2 className="font-heading text-sm md:text-lg text-[#2C1A0F] uppercase">
              {hasRight ? scenario.article : "No Article Applies"}
            </h2>
          </div>

          {hasRight && (
            <div className="mb-4">
              <div className="font-heading text-[10px] md:text-xs text-[#5C4033] uppercase mb-2">
                {scenario.articleTitle}
              </div>
              <p className="font-body text-lg md:text-2xl text-[#2C1A0F] leading-snug">
                {scenario.articleSummary}
              </p>
            </div>
          )}

          {!hasRight && (
            <p className="font-body text-lg md:text-2xl text-[#2C1A0F] leading-snug mb-4">
              {scenario.articleSummary || scenario.oneLiner}
            </p>
          )}

          <div className="mt-2 mb-4 px-3 py-2 border-l-4 border-[#F57C00] bg-[#FFF3E0]">
            <div className="font-heading text-[8px] md:text-[10px] uppercase text-[#F57C00] mb-1">
              In one line
            </div>
            <div className="font-body text-base md:text-xl text-[#2C1A0F]">
              {scenario.oneLiner}
            </div>
          </div>

          {/* Wrong answer path — just show a Continue */}
          {isWrong && (
            <div className="flex justify-end mt-4">
              <RetroButton
                variant="gold"
                onClick={() => onDone({ advocateBonus: false })}
                testId="btn-article-continue"
              >
                Continue ▸
              </RetroButton>
            </div>
          )}

          {/* Right answer, no advocate needed */}
          {!isWrong && !needsAdvocatePick && (
            <div className="flex justify-end mt-4">
              <RetroButton
                variant="gold"
                onClick={() => onDone({ advocateBonus: false })}
                testId="btn-article-continue"
              >
                Continue ▸
              </RetroButton>
            </div>
          )}

          {/* Right answer + needs advocate pick */}
          {needsAdvocatePick && (
            <div className="mt-4">
              <div className="flex items-center gap-2 mb-3">
                <GavelIcon size={2} />
                <div className="font-heading text-[10px] md:text-xs uppercase text-[#2C1A0F]">
                  Assign the right Advocate
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {ADVOCATES.map((adv) => {
                  const picked = pickedAdvocateId === adv.id;
                  const errored = pickError === adv.id;
                  return (
                    <button
                      key={adv.id}
                      onClick={() => handlePick(adv.id)}
                      className={`border-4 p-2 flex flex-col items-center gap-1 bg-white active:translate-y-[2px] ${
                        errored ? "screen-shake" : ""
                      }`}
                      style={{
                        borderColor: picked ? "#2E7D32" : errored ? "#C62828" : "#2C1A0F",
                        boxShadow: "4px 4px 0 0 rgba(0,0,0,0.35)",
                      }}
                      data-testid={`advocate-pick-${adv.id}`}
                    >
                      <HumanoidSprite
                        palette={adv.palette}
                        accessories={adv.accessories}
                        size={3}
                        animation="idle"
                      />
                      <div className="font-heading text-[7px] md:text-[8px] text-[#2C1A0F] text-center leading-tight">
                        {adv.name}
                      </div>
                      <div className="font-body text-xs md:text-sm text-[#5C4033] text-center leading-tight">
                        {adv.title}
                      </div>
                    </button>
                  );
                })}
              </div>

              {correctAdvocate && (
                <div className="mt-3 font-body text-sm md:text-base text-[#5C4033]">
                  Hint: this case involves <b>{scenario.article}</b> — think about who specializes there.
                </div>
              )}

              <div className="flex justify-end mt-4">
                <RetroButton
                  variant="neutral"
                  size="sm"
                  onClick={() => onDone({ advocateBonus: false })}
                  testId="btn-article-skip-pick"
                >
                  Skip Pick ✕
                </RetroButton>
              </div>
            </div>
          )}
        </PixelFrame>
      </div>
    </div>
  );
}
